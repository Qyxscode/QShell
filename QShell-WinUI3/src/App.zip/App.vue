<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from "vue";
import { Terminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { open as openFileDialog, save as saveFileDialog } from "@tauri-apps/plugin-dialog";
import Icons from "./components/Icons.vue";
import CustomSelect from "./components/CustomSelect.vue";
import CustomNumberStepper from "./components/CustomNumberStepper.vue";
import CustomDateTimePicker from "./components/CustomDateTimePicker.vue";

// --- 界面状态 ---
const currentView = ref<"workspace" | "mgmt">("workspace");
const isRightPanelOpen = ref(true);
const rightPanelTab = ref<"sftp" | "memo">("memo");

// 主机管理大盘：每行卡片数 (1 - 3 列，支持持久化)
const savedMgmtCols = typeof localStorage !== "undefined" ? Number(localStorage.getItem("qshell_mgmt_cols")) || 3 : 3;
const mgmtGridColumns = ref<number>(Math.max(1, Math.min(3, savedMgmtCols)));
function setMgmtGridColumns(cols: number) {
  mgmtGridColumns.value = Math.max(1, Math.min(3, cols));
  try {
    localStorage.setItem("qshell_mgmt_cols", String(mgmtGridColumns.value));
  } catch (e) {}
}

// 计算主机流量百分比 (0 - 100)
function getTrafficProgress(h: HostItem): number {
  if (!h.details || h.details.traffic_total_infinite) return 0;
  const used = parseFloat(h.details.traffic_used || "0");
  const total = parseFloat(h.details.traffic_total || "0");
  if (isNaN(used) || isNaN(total) || total <= 0) return 0;

  // 统一换算为 MB 比较
  const getMultiplier = (unit?: string) => {
    const u = (unit || "GB").toUpperCase();
    if (u.includes("TB")) return 1024 * 1024;
    if (u.includes("GB")) return 1024;
    if (u.includes("MB")) return 1;
    if (u.includes("KB")) return 1 / 1024;
    return 1024;
  };
  const usedMB = used * getMultiplier(h.details.traffic_used_unit);
  const totalMB = total * getMultiplier(h.details.traffic_total_unit);
  const pct = (usedMB / totalMB) * 100;
  return Math.max(0, Math.min(100, pct));
}

// 从 localStorage 读取保存的主题模式，默认为 dark，并立即挂载 data-theme 属性到 document
const savedTheme = (typeof localStorage !== "undefined" && (localStorage.getItem("qshell_theme_mode") as "dark" | "light")) || "dark";
const themeMode = ref<"dark" | "light">(savedTheme);
if (typeof document !== "undefined") {
  document.documentElement.setAttribute("data-theme", savedTheme);
}

// 左右侧边栏可调节宽度 (原版开阔黄金比例: 左286px, 右280px)
const leftPanelWidth = ref(286);
const rightPanelWidth = ref(280);

// 主机卡片自由拖拽排序
const draggingHostIndex = ref<number | null>(null);
const dragOverHostIndex = ref<number | null>(null);

function handleCardDragStart(index: number, e: DragEvent) {
  draggingHostIndex.value = index;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", String(index));
  }
}

function handleCardDragOver(index: number, e: DragEvent) {
  e.preventDefault();
  if (e.dataTransfer) {
    e.dataTransfer.dropEffect = "move";
  }
  if (dragOverHostIndex.value !== index) {
    dragOverHostIndex.value = index;
  }
}

function handleCardDragLeave(index: number) {
  if (dragOverHostIndex.value === index) {
    dragOverHostIndex.value = null;
  }
}

async function handleCardDrop(index: number, e: DragEvent) {
  e.preventDefault();
  if (draggingHostIndex.value !== null && draggingHostIndex.value !== index) {
    const list = [...configData.value.managed_hosts];
    const [moved] = list.splice(draggingHostIndex.value, 1);
    list.splice(index, 0, moved);
    configData.value.managed_hosts = list;
    await invoke("save_hosts_config", { config: configData.value });
  }
  draggingHostIndex.value = null;
  dragOverHostIndex.value = null;
}

function handleCardDragEnd() {
  draggingHostIndex.value = null;
  dragOverHostIndex.value = null;
}

// 终端标签页拖拽排序
const draggingTabIndex = ref<number | null>(null);
const dragOverTabIndex = ref<number | null>(null);

function handleTabDragStart(index: number, e: DragEvent) {
  draggingTabIndex.value = index;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", String(index));
  }
}

function handleTabDragOver(index: number, e: DragEvent) {
  e.preventDefault();
  if (e.dataTransfer) {
    e.dataTransfer.dropEffect = "move";
  }
  if (dragOverTabIndex.value !== index) {
    dragOverTabIndex.value = index;
  }
}

function handleTabDragLeave(index: number) {
  if (dragOverTabIndex.value === index) {
    dragOverTabIndex.value = null;
  }
}

function handleTabDrop(index: number, e: DragEvent) {
  e.preventDefault();
  if (draggingTabIndex.value !== null && draggingTabIndex.value !== index) {
    const list = [...sessions.value];
    const [moved] = list.splice(draggingTabIndex.value, 1);
    list.splice(index, 0, moved);
    sessions.value = list;
  }
  draggingTabIndex.value = null;
  dragOverTabIndex.value = null;
}

function handleTabDragEnd() {
  draggingTabIndex.value = null;
  dragOverTabIndex.value = null;
}
const leftMonitorCardHeight = ref(265); // 初始监控卡片高度 (紧凑去留白，精致黄金尺寸)
let isDraggingLeftSplitter = false;
let isDraggingRightSplitter = false;
let isDraggingLeftVerticalSplitter = false;

function onLeftSplitterDown(e: MouseEvent) {
  isDraggingLeftSplitter = true;
  document.addEventListener("mousemove", onSplitterMove);
  document.addEventListener("mouseup", onSplitterUp);
  e.preventDefault();
}

function onLeftVerticalSplitterDown(e: MouseEvent) {
  isDraggingLeftVerticalSplitter = true;
  document.addEventListener("mousemove", onSplitterMove);
  document.addEventListener("mouseup", onSplitterUp);
  e.preventDefault();
}

function onRightSplitterDown(e: MouseEvent) {
  isDraggingRightSplitter = true;
  document.addEventListener("mousemove", onSplitterMove);
  document.addEventListener("mouseup", onSplitterUp);
  e.preventDefault();
}

function onSplitterMove(e: MouseEvent) {
  if (isDraggingLeftSplitter) {
    const newWidth = e.clientX - 12;
    if (newWidth >= 260 && newWidth <= 480) {
      leftPanelWidth.value = newWidth;
    }
  } else if (isDraggingLeftVerticalSplitter) {
    // 垂直拖拽：紧凑留白后卡片自然内容高度约 258px，最小高度锁定 260px，既极致紧凑又绝不裁切
    const newHeight = e.clientY - 44 - 10;
    if (newHeight >= 260 && newHeight <= 480) {
      leftMonitorCardHeight.value = newHeight;
    }
  } else if (isDraggingRightSplitter) {
    const newWidth = window.innerWidth - e.clientX - 12;
    if (newWidth >= 250 && newWidth <= 520) {
      rightPanelWidth.value = newWidth;
    }
  }
}

function onSplitterUp() {
  isDraggingLeftSplitter = false;
  isDraggingLeftVerticalSplitter = false;
  isDraggingRightSplitter = false;
  isDraggingSftpCol = null;
  document.removeEventListener("mousemove", onSplitterMove);
  document.removeEventListener("mouseup", onSplitterUp);
}

// SFTP 列宽拖拽调节状态与默认列宽 (名称列默认收短1/3左右, 赋予更多紧凑展示空间)
const sftpColWidths = ref({
  name: 120, // 初始默认由 180px 缩短 1/3 至 120px
  size: 55,
  perm: 55
});
let isDraggingSftpCol: 'name' | 'size' | null = null;
let sftpDragStartX = 0;
let sftpDragStartWidth = 0;

function onSftpColResizeDown(col: 'name' | 'size', e: MouseEvent) {
  isDraggingSftpCol = col;
  sftpDragStartX = e.clientX;
  sftpDragStartWidth = sftpColWidths.value[col];
  document.addEventListener("mousemove", onSftpColResizeMove);
  document.addEventListener("mouseup", onSftpColResizeUp);
  e.preventDefault();
  e.stopPropagation();
}

function onSftpColResizeMove(e: MouseEvent) {
  if (!isDraggingSftpCol) return;
  const delta = e.clientX - sftpDragStartX;
  if (isDraggingSftpCol === 'name') {
    sftpColWidths.value.name = Math.max(50, Math.min(350, sftpDragStartWidth + delta));
  } else if (isDraggingSftpCol === 'size') {
    sftpColWidths.value.size = Math.max(40, Math.min(150, sftpDragStartWidth + delta));
  }
}

function onSftpColResizeUp() {
  isDraggingSftpCol = null;
  document.removeEventListener("mousemove", onSftpColResizeMove);
  document.removeEventListener("mouseup", onSftpColResizeUp);
}

function executeThemeChange() {
  const newTheme = themeMode.value === "dark" ? "light" : "dark";
  themeMode.value = newTheme;
  document.documentElement.setAttribute("data-theme", newTheme);
  try {
    localStorage.setItem("qshell_theme_mode", newTheme);
  } catch (e) {}

  // 终端默认跟随全局日夜模式联动：
  const isDark = newTheme === "dark";
  const darkPreset = "#81C995";
  const lightPreset = "#111318";
  const prevMode = terminalSettings.value.term_bg_mode || "dark";
  const prevFg = (terminalSettings.value.terminal_fg_color || "").trim().toLowerCase();
  const presetPrev = (prevMode === "dark" ? darkPreset : lightPreset).toLowerCase();

  terminalSettings.value.term_bg_mode = isDark ? "dark" : "light";
  terminalSettings.value.terminal_bg_color = isDark ? "#0A0B0E" : "#F4F5F7";

  if (!prevFg || prevFg === presetPrev) {
    terminalSettings.value.terminal_fg_color = isDark ? darkPreset : lightPreset;
  }

  applyTerminalSettings(false); // 同步终端外观，但不关闭偏好弹窗
}

// 现代化圆形扩散亮暗切换动画 (从右下角/点击按钮源向全屏水波涟漪扩大)
function toggleTheme(event?: MouseEvent) {
  // 如果浏览器/平台不支持 View Transitions API，则直接平滑切换
  if (!document.startViewTransition) {
    executeThemeChange();
    return;
  }

  // 计算扩散圆心：优先取点击事件坐标，若无则默认取屏幕右下角
  const x = event ? event.clientX : window.innerWidth;
  const y = event ? event.clientY : window.innerHeight;
  const endRadius = Math.hypot(
    Math.max(x, window.innerWidth - x),
    Math.max(y, window.innerHeight - y)
  );

  const transition = document.startViewTransition(() => {
    executeThemeChange();
  });

  transition.ready.then(() => {
    const clipPath = [
      `circle(0px at ${x}px ${y}px)`,
      `circle(${endRadius}px at ${x}px ${y}px)`
    ];
    document.documentElement.animate(
      {
        clipPath: clipPath,
      },
      {
        duration: 700,
        easing: "cubic-bezier(0.25, 1, 0.5, 1)",
        pseudoElement: "::view-transition-new(root)",
      }
    );
  });
}

// --- 窗口控制 (兼容浏览器直接运行与 Tauri 原生环境) ---
const isTauri = typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;
const appWindow = isTauri ? getCurrentWindow() : null;
function startDragging(e: MouseEvent) {
  if (appWindow && e.button === 0 && !(e.target as HTMLElement).closest("button, input, select, textarea, .context-menu, .modal-card")) {
    appWindow.startDragging();
  }
}
function minimizeWindow() { appWindow?.minimize(); }
function toggleMaximizeWindow() { appWindow?.toggleMaximize(); }
function closeWindow() { appWindow?.close(); }

// --- 数据模型 ---
interface HostDetails {
  memo?: string;
  expire_date?: string;
  price?: string;
  currency?: string;
  traffic_total?: string;
  traffic_total_unit?: string;
  traffic_total_infinite?: boolean;
  traffic_used?: string;
  traffic_used_unit?: string;
  reset_day?: number;
  reset_hour?: number;
  reset_min?: number;
  traffic_direction?: string;
  target_interface?: string;
  traffic_price?: string;
  traffic_currency?: string;
  traffic_cycle_used_bytes?: number;
  traffic_source?: string;
  traffic_custom_command?: string;
  traffic_source_effective?: string;
  traffic_source_error?: string;
  traffic_last_sync_ts?: number;
  traffic_delta_bytes?: number;
  last_raw_bytes?: number;
  traffic_counter_sig?: string;
  traffic_boot_id?: string;
  last_reset_timestamp?: number;
  traffic_manual_override?: boolean;
  traffic_iface_baseline?: string;
}

interface TrafficAuditResult {
  traffic_cycle_used_bytes: number;
  traffic_delta_bytes: number;
  traffic_used: string;
  traffic_used_unit: string;
  last_raw_bytes: number;
  traffic_counter_sig: string;
  traffic_boot_id: string;
  last_reset_timestamp: number;
  traffic_source_effective: string;
  traffic_source_error: string;
  traffic_last_sync_ts: number;
  traffic_iface_baseline: string;
}

interface HostItem {
  name: string;
  host: string;
  port: number;
  user: string;
  pwd?: string;
  key_path?: string;
  passphrase?: string;
  details?: HostDetails;
  latency_text?: string;
}

interface DeviceGroup {
  group: string;
  hosts: HostItem[];
  collapsed?: boolean;
}

interface MemoItem {
  name: string;
  cmd: string;
}

interface MemoGroup {
  group: string;
  items: MemoItem[];
  collapsed?: boolean;
}

interface AppConfig {
  version?: string;
  devices: DeviceGroup[];
  managed_hosts: HostItem[];
  memos?: MemoGroup[];
  settings?: any;
}

const configData = ref<AppConfig>({ devices: [], managed_hosts: [], memos: [] });

// --- 会话与多标签页体系 ---
interface SessionTab {
  id: string;
  name: string;
  host: HostItem;
  termInstance?: Terminal;
  fitInstance?: FitAddon;
  resizeObserver?: ResizeObserver;
  unlisten?: UnlistenFn;
  alive: boolean;
  is_connecting?: boolean;
  is_locked?: boolean;
  latency?: number;
}

const sessions = ref<SessionTab[]>([]);
const activeSessionId = ref<string>("");
const activeSession = computed(() => sessions.value.find(s => s.id === activeSessionId.value));

function toggleTabLock(tab: SessionTab) {
  tab.is_locked = !tab.is_locked;
}

// --- 系统实时监控 (未连接时默认为 0，连接后随活动终端实时采样) ---
const monitorStats = ref({
  cpu: 0,
  mem: 0,
  disk: 0,
  net_up: "0 KB/s",
  net_down: "0 KB/s",
  net_if: "",
  latency: 0,
});

const TOTAL_LEDS = 90; // 6行 x 15列 高密圆角矩形灯阵 (多增加两排)

function calculateLedActiveCount(speedStr: string): number {
  if (!speedStr || sessions.value.length === 0) return 0;
  const s = speedStr.trim().toUpperCase();
  const m = s.match(/([0-9]+(?:\.[0-9]+)?)\s*([A-Z\/]+)/);
  if (!m) return 0;
  const val = parseFloat(m[1]);
  const unit = m[2];
  if (val <= 0) return 0;

  // 统一换算为 KB/s
  let kbps = 0;
  if (unit.includes("GB")) {
    kbps = val * 1024.0 * 1024.0;
  } else if (unit.includes("MB")) {
    kbps = val * 1024.0;
  } else if (unit.includes("KB")) {
    kbps = val;
  } else {
    kbps = val / 1024.0;
  }

  // 科学真实网络刻度（共 90 颗灯珠，每排 15 颗）：
  // - 10 KB/s 以下（心跳/闲置）：1 ~ 2 颗
  // - 100 KB/s：~4 颗（仅第一排起头）
  // - 500 KB/s：~10 颗（第一排大部分）
  // - 1 MB/s (1024 KB/s)：15 颗（刚满第 1 排）
  // - 5 MB/s：~30 颗（第 2 排满）
  // - 15 MB/s（百兆宽带满载）：~45 颗（第 3 排满，正好一半）
  // - 50 MB/s：~60 颗（第 4 排满）
  // - 100 MB/s（千兆跑满）：90 颗（6 排全满）
  let count = 0;
  if (kbps < 1.0) {
    count = 1;
  } else if (kbps <= 1024.0) {
    // 1 KB/s ~ 1024 KB/s: 映射到 1 ~ 15 颗 (第一排范围)
    const logRatio = Math.log10(kbps) / Math.log10(1024.0); // 0 ~ 1
    count = Math.max(1, Math.round(1 + logRatio * 14));
  } else if (kbps <= 102400.0) {
    // 1 MB/s ~ 100 MB/s: 映射到 16 ~ 90 颗 (第 2 ~ 6 排范围)
    const logRatio = Math.log10(kbps / 1024.0) / Math.log10(100.0); // 0 ~ 1
    count = Math.round(15 + logRatio * 75);
  } else {
    count = TOTAL_LEDS;
  }
  return Math.max(1, Math.min(TOTAL_LEDS, count));
}

const activeUpLedCount = computed(() => calculateLedActiveCount(monitorStats.value.net_up));
const activeDownLedCount = computed(() => calculateLedActiveCount(monitorStats.value.net_down));

// 终端连接与延迟指示器状态色判断
// 离线/未连接=红色；低于150ms=绿色；150ms~250ms=黄色；高于250ms=橙色；连接中/刚连接测速中=浅蓝
const latencyStatusClass = computed(() => {
  const sess = activeSession.value;
  if (!sess) return 'status-offline';

  // 延迟值优先取 monitorStats.latency，若切标签尚未出结果则回退到该标签已缓存的 latency
  const lat = monitorStats.value.latency > 0 ? monitorStats.value.latency : (sess.latency || 0);

  // 1. 如果已有有效测速值（说明主机连通，绝对不能显示为离线红色！）
  if (lat > 0) {
    if (lat < 150) return 'status-green';       // < 150ms: 绿色
    if (lat <= 250) return 'status-yellow';     // 150ms ~ 250ms: 黄色
    return 'status-orange';                    // > 250ms: 橙色
  }

  // 2. 处于连接中，或已连上存活但首个 ping 仍在回包中 -> 浅蓝测速中
  if (sess.is_connecting || sess.alive) {
    return 'status-measuring';
  }

  // 3. 既无测速结果、也未处于连接/存活状态 -> 离线红色
  return 'status-offline';
});

// 指示器展示文字计算属性
const latencyDisplayText = computed(() => {
  const sess = activeSession.value;
  if (!sess) return '离线';
  const lat = monitorStats.value.latency > 0 ? monitorStats.value.latency : (sess.latency || 0);
  if (lat > 0) return `在线 ${lat} ms`;
  if (sess.is_connecting || sess.alive) return '测速中';
  return '离线';
});

// 单颗灯珠高亮流光游标与后随 3 颗渐变尾焰：通过定时器顺序逐颗推进
const upRunnerIdx = ref(0);
const downRunnerIdx = ref(0);
let upRunnerTimer: number | null = null;
let downRunnerTimer: number | null = null;

// 游标流动的单步间隔时间：严格设定为 0.7 秒 (700ms) 跳一格
const RUNNER_INTERVAL_MS = 700;

// 计算灯珠在彗星流光中的身份：0=头部高亮, 1=尾焰第1级, 2=尾焰第2级, 3=尾焰第3级, -1=普通背景
function getRunnerLevel(idx: number, runnerHead: number, maxCount: number): number {
  if (runnerHead <= 0 || maxCount <= 0 || idx > maxCount) return -1;
  const diff = runnerHead - idx;
  // 严格只有在游标身后的 3 颗才作为尾焰 (diff: 0, 1, 2, 3)
  if (diff >= 0 && diff <= 3) return diff;
  return -1;
}

watch(activeUpLedCount, (count) => {
  if (upRunnerTimer) {
    clearInterval(upRunnerTimer);
    upRunnerTimer = null;
  }
  if (count <= 0) {
    upRunnerIdx.value = 0;
    return;
  }
  // 步长上限扩展为 count + 4，保证最后一颗灯珠的尾焰完全淡出消失后，经过一个完整的静默拍，再从第 1 颗重新开始
  const maxStep = count + 4;
  if (upRunnerIdx.value > maxStep) upRunnerIdx.value = 1;
  upRunnerTimer = window.setInterval(() => {
    upRunnerIdx.value = (upRunnerIdx.value % maxStep) + 1;
  }, RUNNER_INTERVAL_MS);
}, { immediate: true });

watch(activeDownLedCount, (count) => {
  if (downRunnerTimer) {
    clearInterval(downRunnerTimer);
    downRunnerTimer = null;
  }
  if (count <= 0) {
    downRunnerIdx.value = 0;
    return;
  }
  const maxStep = count + 4;
  if (downRunnerIdx.value > maxStep) downRunnerIdx.value = 1;
  downRunnerTimer = window.setInterval(() => {
    downRunnerIdx.value = (downRunnerIdx.value % maxStep) + 1;
  }, RUNNER_INTERVAL_MS);
}, { immediate: true });

// 监听视图切换：当从“主机管理”返回“工作区”时，重新计算终端尺寸并触发重绘，彻底解决切页后吞字、文字重叠的问题
watch(currentView, (val) => {
  if (val === "workspace") {
    nextTick(() => {
      // 延时双重触发，保证 CSS display: flex 容器完成几何尺寸恢复
      const refitTerminals = () => {
        sessions.value.forEach(tab => {
          if (tab.termInstance && tab.fitInstance && tab.alive) {
            try {
              tab.fitInstance.fit();
              if (tab.termInstance.cols > 0 && tab.termInstance.rows > 0) {
                invoke("resize_ssh_session", {
                  sessionId: tab.id,
                  cols: tab.termInstance.cols,
                  rows: tab.termInstance.rows,
                });
              }
              // 触发 xterm 缓冲区刷新重绘
              tab.termInstance.refresh(0, tab.termInstance.rows - 1);
            } catch (_) {}
          }
        });
        const activeTab = sessions.value.find(s => s.id === activeSessionId.value);
        if (activeTab?.termInstance) {
          try {
            activeTab.termInstance.focus();
          } catch (_) {}
        }
      };

      refitTerminals();
      setTimeout(refitTerminals, 60);
      setTimeout(refitTerminals, 180);
    });
  }
});

let monitorInterval: number | null = null;

function resetMonitorStats() {
  if (latencyInterval) { clearInterval(latencyInterval); latencyInterval = null; }
  monitorStats.value = {
    cpu: 0,
    mem: 0,
    disk: 0,
    net_up: "0 KB/s",
    net_down: "0 KB/s",
    net_if: "",
    latency: 0,
  };
  upRunnerIdx.value = 0;
  downRunnerIdx.value = 0;
}

// --- SFTP 数据模型与状态 ---
interface SftpFileItem {
  name: string;
  is_dir: boolean;
  size: string;
  size_bytes: number;
  mode_str: string;
  mode_oct: string;
  mtime: number;
}

interface TransferTask {
  task_id: string;
  filename: string;
  is_upload: boolean;
  transferred: number;
  total: number;
  speed_bps: number;
  status: "running" | "completed" | "failed";
  error?: string;
}

const currentSftpPath = ref("/");
const sftpFiles = ref<SftpFileItem[]>([]);
const selectedSftpFile = ref<SftpFileItem | null>(null);
const isSftpLoading = ref(false);
const activeTransfers = ref<TransferTask[]>([]);
const showTransferMonitor = ref(false);

// --- 搜索过滤 ---
const searchKeyword = ref("");

// --- 主机到期与超额流量预警机制 ---
interface HostAlertInfo {
  hostName: string;
  type: "expire" | "traffic";
  msg: string;
  hostItem?: HostItem;
}

const hostAlertList = ref<HostAlertInfo[]>([]);
const showAlertPopover = ref(false);

const alertPopoverTargetRight = ref(120);
const transferPopoverTargetRight = ref(85);

function toggleAlertPopover(e?: MouseEvent) {
  if (showTransferMonitor.value) {
    showTransferMonitor.value = false;
  }
  if (!showAlertPopover.value && e?.currentTarget) {
    const btn = e.currentTarget as HTMLElement;
    const rect = btn.getBoundingClientRect();
    const btnCenterX = rect.left + rect.width / 2;
    // 气泡固定 right: 15px，气泡宽度 360px
    // 气泡右边界距离窗口右侧为 15px，所以小三角相对于气泡右边界的距离为：
    const popoverRightEdge = window.innerWidth - 15;
    alertPopoverTargetRight.value = Math.max(16, Math.min(340, popoverRightEdge - btnCenterX));
  }
  showAlertPopover.value = !showAlertPopover.value;
}

function toggleTransferMonitor(e?: MouseEvent) {
  if (showAlertPopover.value) {
    showAlertPopover.value = false;
  }
  if (!showTransferMonitor.value && e?.currentTarget) {
    const btn = e.currentTarget as HTMLElement;
    const rect = btn.getBoundingClientRect();
    const btnCenterX = rect.left + rect.width / 2;
    // 气泡固定 right: 15px，气泡宽度 320px
    const popoverRightEdge = window.innerWidth - 15;
    transferPopoverTargetRight.value = Math.max(16, Math.min(300, popoverRightEdge - btnCenterX));
  }
  showTransferMonitor.value = !showTransferMonitor.value;
}

function handleGlobalClick(e: MouseEvent) {
  closeContextMenu();
  const target = e.target as HTMLElement | null;
  if (!target) return;

  // 点击非通知气泡及非通知按钮区域时，自动收起通知气泡
  if (showAlertPopover.value) {
    if (!target.closest(".alert-popover") && !target.closest(".btn-toggle-alert")) {
      showAlertPopover.value = false;
    }
  }

  // 点击非传输气泡及非传输按钮区域时，自动收起传输气泡
  if (showTransferMonitor.value) {
    if (!target.closest(".transfer-monitor-popover:not(.alert-popover)") && !target.closest(".btn-toggle-transfer")) {
      showTransferMonitor.value = false;
    }
  }
}

function clearAllAlerts() {
  hostAlertList.value = [];
  showAlertPopover.value = false;
}

function clearTransferHistory() {
  // 过滤掉已完成和失败的历史任务，保留仍在进行中的任务
  const ongoing = activeTransfers.value.filter(t => t.status !== 'completed' && t.status !== 'failed');
  if (ongoing.length === activeTransfers.value.length) {
    // 如果没有明确完成状态但用户点击清除，直接清空
    activeTransfers.value = [];
  } else {
    activeTransfers.value = ongoing;
  }
}

const highlightedHostKey = ref<string | null>(null);
let highlightTimer: any = null;

function handleAlertClick(al: HostAlertInfo) {
  showAlertPopover.value = false;
  if (al.hostItem) {
    currentView.value = "mgmt";
    // 聚焦并高亮指定主机卡片
    const key = `${al.hostItem.host}:${al.hostItem.port}`;
    highlightedHostKey.value = key;
    if (highlightTimer) clearTimeout(highlightTimer);

    // 延时滚动到可视区域
    setTimeout(() => {
      const el = document.getElementById(`host-card-${al.hostItem?.host}-${al.hostItem?.port}`);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }, 50);

    // 平缓呼吸 3 次，每次 1.6 秒，总共 4.8 秒后自动移除类
    highlightTimer = setTimeout(() => {
      if (highlightedHostKey.value === key) {
        highlightedHostKey.value = null;
      }
    }, 4800);
  }
}

function evaluateHostAlerts() {
  const alerts: HostAlertInfo[] = [];
  const now = new Date();
  configData.value.managed_hosts.forEach(h => {
    // 1. 到期检测
    if (h.details?.expire_date && h.details.expire_date !== "无限") {
      const expDate = new Date(h.details.expire_date.replace(/-/g, "/"));
      if (!isNaN(expDate.getTime())) {
        const diffDays = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 3600 * 24));
        if (diffDays <= 3) {
          alerts.push({
            hostName: h.name,
            type: "expire",
            msg: diffDays <= 0 ? `已于 ${h.details.expire_date} 到期！` : `将在 ${diffDays} 天后 (${h.details.expire_date}) 到期`,
            hostItem: h,
          });
        }
      }
    }
    // 2. 超额流量检测
    if (h.details && !h.details.traffic_total_infinite && h.details.traffic_total && h.details.traffic_used) {
      const total = parseFloat(h.details.traffic_total);
      const used = parseFloat(h.details.traffic_used);
      if (total > 0 && used / total >= 0.9) {
        alerts.push({
          hostName: h.name,
          type: "traffic",
          msg: `流量使用率达 ${Math.round((used / total) * 100)}% (${used}/${total}${h.details.traffic_total_unit || 'GB'})`,
          hostItem: h,
        });
      }
    }
  });
  hostAlertList.value = alerts;
}

// --- 全局右键菜单系统 ---
const contextMenu = ref({
  show: false,
  x: 0,
  y: 0,
  targetType: "" as "host" | "group" | "tab" | "terminal" | "sftp_item" | "sftp_bg" | "memo_item" | "memo_group" | "memo_bg" | "",
  targetHost: null as HostItem | null,
  targetGroup: null as DeviceGroup | null,
  targetTab: null as SessionTab | null,
  targetSftpItem: null as SftpFileItem | null,
  targetMemoGroupIdx: null as number | null,
  targetMemoItemIdx: null as number | null,
  targetMemoItem: null as MemoItem | null,
});

function openContextMenu(
  e: MouseEvent,
  type: "host" | "group" | "tab" | "terminal" | "sftp_item" | "sftp_bg" | "memo_item" | "memo_group" | "memo_bg",
  host?: HostItem,
  group?: DeviceGroup,
  sftpItem?: SftpFileItem,
  memoGroupIdx?: number,
  memoItemIdx?: number,
  memoItem?: MemoItem,
  tab?: SessionTab
) {
  e.preventDefault();
  e.stopPropagation();
  // 菜单实际高度通常仅为 120px~150px 左右，只有在紧贴底部不足 150px 时才做贴边限制
  const menuEstimatedHeight = 150;
  const menuEstimatedWidth = 180;
  const targetX = e.clientX + menuEstimatedWidth > window.innerWidth ? Math.max(10, window.innerWidth - menuEstimatedWidth - 10) : e.clientX;
  const targetY = e.clientY + menuEstimatedHeight > window.innerHeight ? Math.max(10, window.innerHeight - menuEstimatedHeight - 10) : e.clientY;

  contextMenu.value = {
    show: true,
    x: targetX,
    y: targetY,
    targetType: type,
    targetHost: host || null,
    targetGroup: group || null,
    targetTab: tab || null,
    targetSftpItem: sftpItem || null,
    targetMemoGroupIdx: memoGroupIdx !== undefined ? memoGroupIdx : null,
    targetMemoItemIdx: memoItemIdx !== undefined ? memoItemIdx : null,
    targetMemoItem: memoItem || null,
  };
}

function closeContextMenu() {
  contextMenu.value.show = false;
}

// --- 弹窗体系 ---

// 1. 主机添加/编辑模态框
const hostModal = ref({
  show: false,
  isEdit: false,
  mode: 'all' as 'all' | 'connection' | 'asset',
  form: {
    name: "",
    host: "",
    port: 22,
    user: "root",
    pwd: "",
    key_path: "",
    passphrase: "",
    memo: "",
    expire_date: "无限",
    expire_infinite: true,
    price: "0.00",
    currency: "CNY",
    traffic_total: "1000",
    traffic_total_unit: "GB",
    traffic_total_infinite: true,
    traffic_used: "0",
    traffic_used_unit: "GB",
    reset_day: 1,
    reset_hour: 0,
    reset_min: 0,
    traffic_direction: "both",
    target_interface: "",
    traffic_price: "0.00",
    traffic_currency: "CNY",
  },
  originalHost: null as HostItem | null,
  targetGroup: null as DeviceGroup | null,
});

// 2. 流量统计与校准模态框 (原版 TrafficStatsDialog)
const trafficStatsModal = ref({
  show: false,
  host: null as HostItem | null,
  source: "auto",
  customCommand: "",
  calibUsed: "",
  calibUnit: "GB",
  resetDay: 1,
  isSyncing: false,
  syncMessage: "",
  syncError: false,
  manualOverride: false,
});

// 3. SFTP 属性模态框 (原版 SFTPPropertiesDialog)
const sftpPropsModal = ref({
  show: false,
  name: "",
  full_path: "",
  is_dir: false,
  size_bytes: 0,
  mode_str: "",
  mode_oct: "",
  mtime_str: "",
});

// 4. SFTP 权限修改 (chmod) 模态框 (原版 SFTPChmodDialog)
const sftpChmodModal = ref({
  show: false,
  filePath: "",
  fileName: "",
  // 9个复选框矩阵
  u_r: true, u_w: true, u_x: true,
  g_r: true, g_w: false, g_x: true,
  o_r: true, o_w: false, o_x: true,
});

// 5. 新建文件夹 / 重命名 简单输入弹窗
const promptModal = ref({
  show: false,
  title: "",
  label: "",
  value: "",
  action: "" as "new_folder" | "rename_file" | "new_device_group" | "rename_device_group" | "new_memo_group" | "rename_memo_group",
  payload: null as any,
});

// 通用 Material 确认弹窗
const customConfirmModal = ref({
  show: false,
  title: "操作确认",
  message: "",
  danger: true,
  confirmText: "确定移除",
  onConfirm: () => {},
});

// 6. 快捷指令编辑模态框
const memoEditModal = ref({
  show: false,
  isEdit: false,
  groupIndex: 0,
  itemIndex: -1,
  form: {
    name: "",
    cmd: "",
  }
});

// 7. 终端偏好与备份设置模态框 (1:1 严格对标 ssh8.py TerminalSettingsDialog)
const defaultGlobalFont = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", sans-serif';
const appFontFamily = ref(defaultGlobalFont);
const terminalSettings = ref({
  font_family: "Consolas",
  font_size: 13,
  is_bold: false,
  cursor_style: "block" as "block" | "bar" | "underline",
  cursor_blink: true,
  blink_interval: 530,
  term_bg_mode: "dark" as "dark" | "light",
  terminal_fg_color: "#81C995",
  terminal_bg_color: "#0A0B0E",
  custom_bg_image: "",
  minimize_to_tray: true,
});
const showTerminalSettingsModal = ref(false);

// 全局界面字体选择模态框
const showFontSelectorModal = ref(false);
const includeSystemFonts = ref(false);
const systemFontList = ref<string[]>([]);
const isReadingSystemFonts = ref(false);
const presetUiFonts = [
  { name: "系统推荐默认", value: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", sans-serif' },
  { name: "微软雅黑 (Microsoft YaHei)", value: '"Microsoft YaHei", sans-serif' },
  { name: "苹方 / 华文细黑 (PingFang SC)", value: '"PingFang SC", "Heiti SC", sans-serif' },
  { name: "Segoe UI", value: '"Segoe UI", sans-serif' },
  { name: "鸿蒙字体 (HarmonyOS Sans SC)", value: '"HarmonyOS Sans SC", "Microsoft YaHei", sans-serif' },
  { name: "OPPO Sans", value: '"OPPO Sans", "Microsoft YaHei", sans-serif' },
  { name: "MiSans (小米兰亭)", value: '"MiSans", "Microsoft YaHei", sans-serif' },
  { name: "思源黑体 (Source Han Sans SC)", value: '"Source Han Sans SC", "Noto Sans SC", sans-serif' },
  { name: "宋体 / 明朝 (SimSun)", value: 'SimSun, "Songti SC", serif' },
  { name: "楷体 (KaiTi)", value: 'KaiTi, "Kaiti SC", serif' },
];

function getDisplayFontName(fontStr: string) {
  if (!fontStr || fontStr.includes("-apple-system") || fontStr === defaultGlobalFont) {
    return "系统推荐默认";
  }
  const match = presetUiFonts.find(p => p.value === fontStr);
  if (match) return match.name;
  return fontStr.split(',')[0].replace(/['"]/g, '').trim();
}

function applyAppFont(font: string) {
  appFontFamily.value = font || defaultGlobalFont;
  document.documentElement.style.setProperty("--app-font-family", appFontFamily.value);
}

// 常见备选系统字体检测表 (含各类中英文常用字族)
const candidateSystemFonts = [
  "Arial", "Calibri", "Cambria", "Century Gothic", "Comic Sans MS", "Consolas",
  "Constantia", "Corbel", "Courier New", "Franklin Gothic Medium", "Georgia",
  "Impact", "Lucida Console", "Lucida Sans", "Malgun Gothic", "Meiryo",
  "Microsoft JhengHei", "Microsoft YaHei", "Microsoft YaHei UI", "MingLiU",
  "MS Gothic", "MS Mincho", "MS PGothic", "MS Sans Serif", "MS Serif",
  "Palatino Linotype", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Emoji",
  "Segoe UI Historic", "Segoe UI Symbol", "Segoe UI Variable Display", "Segoe UI Variable Small", "Segoe UI Variable Text",
  "SimHei", "SimSun", "NSimSun", "FangSong", "KaiTi", "Sylfaen", "Tahoma",
  "Times New Roman", "Trebuchet MS", "Verdana", "Yu Gothic", "Yu Mincho",
  "PingFang SC", "Heiti SC", "Songti SC", "Kaiti SC", "Apple Color Emoji",
  "HarmonyOS Sans SC", "MiSans", "OPPO Sans", "Source Han Sans SC", "Source Han Serif SC"
];

async function handleToggleSystemFonts() {
  if (!includeSystemFonts.value) {
    return;
  }
  if (systemFontList.value.length > 0) {
    return;
  }
  isReadingSystemFonts.value = true;
  try {
    // 优先通过标准 Local Font Access API 读取真实系统字体列表
    if ("queryLocalFonts" in window && typeof (window as any).queryLocalFonts === "function") {
      const fonts = await (window as any).queryLocalFonts();
      const set = new Set<string>();
      for (const f of fonts) {
        if (f.family) set.add(f.family);
      }
      systemFontList.value = Array.from(set).sort((a, b) => a.localeCompare(b));
    } else {
      // 降级使用 document.fonts.check 智能探针检测系统已安装字体
      const available: string[] = [];
      for (const name of candidateSystemFonts) {
        if (document.fonts && document.fonts.check(`12px "${name}"`)) {
          available.push(name);
        }
      }
      systemFontList.value = available.length > 0 ? available : candidateSystemFonts.slice(0, 20);
    }
  } catch (err) {
    console.warn("读取系统字体失败，启用探针列表:", err);
    systemFontList.value = candidateSystemFonts.slice(0, 25);
  } finally {
    isReadingSystemFonts.value = false;
  }
}

// 8. 备份与云同步管理模态框 (原版 BackupManagementDialog)
const backupModal = ref({
  show: false,
  webdav_url: "",
  webdav_user: "",
  webdav_pwd: "",
  webdav_path: "/qshell_backup.json",
  status_msg: "",
  is_busy: false,
});

// 9. 从设备列表导入主机选择模态框 (原版 HostImportSelectionDialog)
const importSelectModal = ref({
  show: false,
  candidates: [] as HostItem[],
  selectedIndexes: [] as number[],
});

// --- 主机管理操作 ---
function openAddHostModal(modeOrEvent?: 'all' | 'connection' | Event, targetGroup?: DeviceGroup | null) {
  const mode = typeof modeOrEvent === 'string' ? modeOrEvent : 'connection';
  const group = targetGroup || (contextMenu.value.targetGroup || null);
  hostModal.value = {
    show: true,
    isEdit: false,
    mode: mode,
    form: {
      name: "新服务器",
      host: "127.0.0.1",
      port: 22,
      user: "root",
      pwd: "",
      key_path: "",
      passphrase: "",
      memo: "",
      expire_date: "",
      expire_infinite: true,
      price: "0.00",
      currency: "CNY",
      traffic_total: "1000",
      traffic_total_unit: "GB",
      traffic_total_infinite: true,
      traffic_used: "0",
      traffic_used_unit: "GB",
      reset_day: 1,
      reset_hour: 0,
      reset_min: 0,
      traffic_direction: "both",
      target_interface: "",
      traffic_price: "0.00",
      traffic_currency: "CNY",
    },
    originalHost: null,
    targetGroup: group,
  };
  closeContextMenu();
}

function openEditHostModal(h: HostItem, mode: 'all' | 'connection' | 'asset' = 'all') {
  const exp = h.details?.expire_date || "无限";
  const isExpInf = exp === "无限" || !exp;
  hostModal.value = {
    show: true,
    isEdit: true,
    mode: mode,
    form: {
      name: h.name,
      host: h.host,
      port: h.port,
      user: h.user,
      pwd: h.pwd || "",
      key_path: h.key_path || "",
      passphrase: h.passphrase || "",
      memo: h.details?.memo || "",
      expire_date: isExpInf ? "" : exp,
      expire_infinite: isExpInf,
      price: h.details?.price || "0.00",
      currency: h.details?.currency || "CNY",
      traffic_total: h.details?.traffic_total || "1000",
      traffic_total_unit: h.details?.traffic_total_unit || "GB",
      traffic_total_infinite: h.details?.traffic_total_infinite ?? true,
      traffic_used: h.details?.traffic_used || "0",
      traffic_used_unit: h.details?.traffic_used_unit || "GB",
      reset_day: h.details?.reset_day || 1,
      reset_hour: h.details?.reset_hour ?? 0,
      reset_min: h.details?.reset_min ?? 0,
      traffic_direction: h.details?.traffic_direction || "both",
      target_interface: h.details?.target_interface || "",
      traffic_price: h.details?.traffic_price || "0.00",
      traffic_currency: h.details?.traffic_currency || "CNY",
    },
    originalHost: h,
    targetGroup: null,
  };
  closeContextMenu();
}

async function browseKeyFile() {
  const selected = await openFileDialog({
    multiple: false,
    title: "选择 SSH 私钥文件 (.pem, id_rsa)",
  });
  if (selected) {
    hostModal.value.form.key_path = typeof selected === "string" ? selected : selected[0];
  }
}

async function saveHostForm() {
  const f = hostModal.value.form;
  if (!f.name || !f.host) return;

  const finalExpireDate = f.expire_infinite ? "无限" : (f.expire_date || "无限");
  const prevUsed = hostModal.value.originalHost?.details?.traffic_used;
  const prevUsedUnit = hostModal.value.originalHost?.details?.traffic_used_unit;

  if (hostModal.value.isEdit && hostModal.value.originalHost) {
    const orig = hostModal.value.originalHost;
    if (hostModal.value.mode === 'asset') {
      // 仅编辑资产与流量配额 + 备注说明
      orig.details = {
        ...orig.details,
        memo: f.memo,
        expire_date: finalExpireDate,
        price: f.price,
        currency: f.currency,
        traffic_total: f.traffic_total,
        traffic_total_unit: f.traffic_total_unit,
        traffic_total_infinite: f.traffic_total_infinite,
        traffic_used: f.traffic_used,
        traffic_used_unit: f.traffic_used_unit,
        reset_day: Number(f.reset_day) || 1,
        reset_hour: Number(f.reset_hour) || 0,
        reset_min: Number(f.reset_min) || 0,
        traffic_direction: f.traffic_direction,
        target_interface: f.target_interface || "",
        traffic_price: f.traffic_price,
        traffic_currency: f.traffic_currency,
      };
    } else if (hostModal.value.mode === 'connection') {
      // 仅编辑连接与认证
      orig.name = f.name;
      orig.host = f.host;
      orig.port = Number(f.port) || 22;
      orig.user = f.user;
      orig.pwd = f.pwd || undefined;
      orig.key_path = f.key_path || undefined;
      orig.passphrase = f.passphrase || undefined;
    } else {
      // 全部
      orig.name = f.name;
      orig.host = f.host;
      orig.port = Number(f.port) || 22;
      orig.user = f.user;
      orig.pwd = f.pwd || undefined;
      orig.key_path = f.key_path || undefined;
      orig.passphrase = f.passphrase || undefined;
      orig.details = {
        ...orig.details,
        memo: f.memo,
        expire_date: finalExpireDate,
        price: f.price,
        currency: f.currency,
        traffic_total: f.traffic_total,
        traffic_total_unit: f.traffic_total_unit,
        traffic_total_infinite: f.traffic_total_infinite,
        traffic_used: f.traffic_used,
        traffic_used_unit: f.traffic_used_unit,
        reset_day: Number(f.reset_day) || 1,
        reset_hour: Number(f.reset_hour) || 0,
        reset_min: Number(f.reset_min) || 0,
        traffic_direction: f.traffic_direction,
        target_interface: f.target_interface || "",
        traffic_price: f.traffic_price,
        traffic_currency: f.traffic_currency,
      };
    }

    // 在资产表单里手工改过“已用流量”时，同步周期字节并视为手动校准
    if (hostModal.value.mode !== 'connection' && orig.details) {
      const usedChanged =
        String(prevUsed ?? "") !== String(f.traffic_used ?? "") ||
        String(prevUsedUnit ?? "") !== String(f.traffic_used_unit ?? "");
      if (usedChanged) {
        const usedValue = Number(f.traffic_used) || 0;
        orig.details.traffic_cycle_used_bytes = Math.max(
          0,
          Math.round(usedValue * trafficUnitMultiplier(f.traffic_used_unit))
        );
        orig.details.traffic_delta_bytes = 0;
        orig.details.last_raw_bytes = 0;
        orig.details.traffic_counter_sig = "";
        orig.details.traffic_boot_id = "";
        orig.details.traffic_iface_baseline = "";
        orig.details.traffic_manual_override = true;
      }
    }

    // 跨列表同步（确保设备列表与主机管理列表一致）
    const syncHostInList = (list: HostItem[]) => {
      const found = list.find(x => x !== orig && (x.host === orig.host || x.name === orig.name));
      if (found) {
        if (hostModal.value.mode === 'asset') {
          found.details = orig.details;
        } else if (hostModal.value.mode === 'connection') {
          found.name = orig.name;
          found.host = orig.host;
          found.port = orig.port;
          found.user = orig.user;
          found.pwd = orig.pwd;
          found.key_path = orig.key_path;
          found.passphrase = orig.passphrase;
        } else {
          found.name = orig.name;
          found.host = orig.host;
          found.port = orig.port;
          found.user = orig.user;
          found.pwd = orig.pwd;
          found.key_path = orig.key_path;
          found.passphrase = orig.passphrase;
          found.details = orig.details;
        }
      }
    };
    configData.value.managed_hosts && syncHostInList(configData.value.managed_hosts);
    configData.value.devices.forEach(g => syncHostInList(g.hosts));
  } else {
    const targetHost: HostItem = {
      name: f.name,
      host: f.host,
      port: Number(f.port) || 22,
      user: f.user,
      pwd: f.pwd || undefined,
      key_path: f.key_path || undefined,
      passphrase: f.passphrase || undefined,
      details: {
        memo: f.memo,
        expire_date: finalExpireDate,
        price: f.price,
        currency: f.currency,
        traffic_total: f.traffic_total,
        traffic_total_unit: f.traffic_total_unit,
        traffic_total_infinite: f.traffic_total_infinite,
        traffic_used: f.traffic_used,
        traffic_used_unit: f.traffic_used_unit,
        reset_day: Number(f.reset_day) || 1,
        reset_hour: Number(f.reset_hour) || 0,
        reset_min: Number(f.reset_min) || 0,
        traffic_direction: f.traffic_direction,
        target_interface: f.target_interface || "",
        traffic_price: f.traffic_price,
        traffic_currency: f.traffic_currency,
      },
    };
    if (configData.value.devices.length === 0) {
      configData.value.devices.push({ group: "默认分组", hosts: [] });
    }
    const destGroup = hostModal.value.targetGroup 
      ? configData.value.devices.find(g => g === hostModal.value.targetGroup || g.group === hostModal.value.targetGroup?.group) || configData.value.devices[0]
      : configData.value.devices[0];
    destGroup.hosts.push(targetHost);
    
    // 同步到主机管理
    if (!configData.value.managed_hosts) {
      configData.value.managed_hosts = [];
    }
    if (!configData.value.managed_hosts.some(x => x.host === targetHost.host && x.port === targetHost.port)) {
      configData.value.managed_hosts.push(targetHost);
    }
  }

  evaluateHostAlerts();
  await invoke("save_hosts_config", { config: configData.value });
  hostModal.value.show = false;
}

// 从设备列表中删除主机 (左侧设备树右键)
async function deleteHost(h: HostItem) {
  closeContextMenu();
  configData.value.devices.forEach(g => {
    g.hosts = g.hosts.filter(item => item !== h && !(item.host === h.host && item.port === h.port));
  });
  await invoke("save_hosts_config", { config: configData.value });
}

// 从主机管理列表中删除主机 (仅移除卡片，不影响设备列表)
async function deleteManagedHost(h: HostItem) {
  configData.value.managed_hosts = configData.value.managed_hosts.filter(
    item => item !== h && !(item.host === h.host && item.port === h.port)
  );
  evaluateHostAlerts();
  await invoke("save_hosts_config", { config: configData.value });
}

function confirmDeleteHost(h: HostItem) {
  customConfirmModal.value = {
    show: true,
    title: "移除主机卡片",
    message: `确定要从主机管理中移除 "${h.name}" 吗？此操作不会删除设备列表中的主机。`,
    danger: true,
    confirmText: "确定移除",
    onConfirm: () => {
      deleteManagedHost(h);
      customConfirmModal.value.show = false;
    },
  };
}

// 流量统计弹窗 (TrafficStatsDialog)
function trafficUnitMultiplier(unit?: string): number {
  const u = String(unit || "GB").toUpperCase();
  if (u === "B" || u === "BYTES") return 1;
  if (u.includes("KB")) return 1024;
  if (u.includes("MB")) return 1024 ** 2;
  if (u.includes("TB")) return 1024 ** 4;
  return 1024 ** 3;
}

function trafficSourceLabel(source?: string): string {
  switch (source) {
    case "auto": return "自动 (vnstat → 本地计数器)";
    case "vnstat": return "vnstat";
    case "proc": return "本地计数器 (/proc/net/dev)";
    case "custom": return "自定义命令";
    case "none": return "未同步";
    default: return source || "尚未同步";
  }
}

function formatTrafficSyncTime(ts?: number): string {
  if (!ts || ts <= 0) return "-";
  const d = new Date(ts * 1000);
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleString("zh-CN", { hour12: false });
}

function openTrafficStatsModal(h: HostItem) {
  closeContextMenu();
  const err = String(h.details?.traffic_source_error || "").trim();
  const effective = h.details?.traffic_source_effective || "";
  const lastTs = h.details?.traffic_last_sync_ts || 0;
  let message = "";
  if (lastTs > 0) {
    message = `上次同步: ${formatTrafficSyncTime(lastTs)} · 来源: ${trafficSourceLabel(effective)}`;
  }
  if (err) {
    message += (message ? " · " : "") + err;
  }
  trafficStatsModal.value = {
    show: true,
    host: h,
    source: h.details?.traffic_source || "auto",
    customCommand: h.details?.traffic_custom_command || "",
    calibUsed: h.details?.traffic_used || "0",
    calibUnit: h.details?.traffic_used_unit || "GB",
    resetDay: h.details?.reset_day || 1,
    isSyncing: false,
    syncMessage: message,
    syncError: !!(err && effective === "none"),
    manualOverride: !!h.details?.traffic_manual_override,
  };
}

async function saveTrafficStats() {
  const m = trafficStatsModal.value;
  if (!m.host) return;

  if (m.source === "custom" && !m.customCommand.trim()) {
    m.syncError = true;
    m.syncMessage = "选择自定义命令时，请填写远程执行命令。";
    return;
  }
  const calibValue = parseFloat(m.calibUsed);
  if (m.calibUsed.trim() !== "" && (isNaN(calibValue) || calibValue < 0)) {
    m.syncError = true;
    m.syncMessage = "请输入有效的已用流量数字。";
    return;
  }

  if (!m.host.details) m.host.details = {};
  const d = m.host.details;
  d.traffic_source = m.source;
  d.traffic_custom_command = m.customCommand;
  d.reset_day = m.resetDay;
  d.traffic_used = m.calibUsed.trim() || "0";
  d.traffic_used_unit = m.calibUnit;
  d.traffic_cycle_used_bytes = Math.max(0, Math.round((isNaN(calibValue) ? 0 : calibValue) * trafficUnitMultiplier(m.calibUnit)));
  d.traffic_delta_bytes = 0;
  d.last_raw_bytes = 0;
  d.traffic_counter_sig = "";
  d.traffic_boot_id = "";
  d.traffic_iface_baseline = "";
  d.traffic_source_error = "";
  d.traffic_manual_override = m.manualOverride;
  trafficAuditFailures.delete(trafficAuditKey(m.host));
  trafficAuditNextAt.set(trafficAuditKey(m.host), Date.now() + trafficAuditIntervalFor(m.host));

  await persistTrafficConfig();
  evaluateHostAlerts();
  m.show = false;
}

// =========================================================================
// 流量审计调度：定时、串行保存、并发限制、失败退避
// =========================================================================
const TRAFFIC_AUDIT_TICK_MS = 5_000;
const TRAFFIC_AUDIT_INTERVAL_MS = 5 * 60_000;
const TRAFFIC_AUDIT_ACTIVE_INTERVAL_MS = 60_000;
const TRAFFIC_AUDIT_MAX_CONCURRENCY = 3;
const TRAFFIC_AUDIT_STARTUP_JITTER_MS = 30_000;
const TRAFFIC_AUDIT_BACKOFF_BASE_MS = 30_000;
const TRAFFIC_AUDIT_BACKOFF_MAX_MS = 30 * 60_000;

let trafficAuditTimer: number | null = null;
let trafficAuditSchedulerBusy = false;
let trafficAuditSchedulerStarted = false;
let trafficConfigSaveChain: Promise<void> = Promise.resolve();
const trafficAuditInFlight = new Map<string, Promise<TrafficAuditResult>>();
const trafficAuditNextAt = new Map<string, number>();
const trafficAuditFailures = new Map<string, number>();

function trafficAuditKey(h: HostItem): string {
  return [h.name, h.host, h.port, h.user].join("|");
}

function ensureHostDetails(h: HostItem): HostDetails {
  if (!h.details) h.details = {};
  return h.details;
}

function buildTrafficAuditParams(h: HostItem, source: string, customCommand: string) {
  const d = ensureHostDetails(h);
  return {
    host: h.host,
    port: h.port,
    username: h.user,
    password: h.pwd || null,
    private_key: h.key_path || null,
    passphrase: h.passphrase || null,
    source,
    custom_command: customCommand,
    reset_day: d.reset_day ?? 1,
    reset_hour: d.reset_hour ?? 0,
    reset_minute: d.reset_min ?? 0,
    direction: d.traffic_direction || "both",
    target_interface: d.target_interface || "",
    traffic_used: d.traffic_used || "0",
    traffic_used_unit: d.traffic_used_unit || "GB",
    traffic_cycle_used_bytes: d.traffic_cycle_used_bytes ?? null,
    traffic_delta_bytes: d.traffic_delta_bytes ?? 0,
    last_raw_bytes: d.last_raw_bytes ?? 0,
    traffic_counter_sig: d.traffic_counter_sig || "",
    traffic_boot_id: d.traffic_boot_id || "",
    last_reset_timestamp: d.last_reset_timestamp ?? 0,
    traffic_iface_baseline: d.traffic_iface_baseline || "",
  };
}

function applyTrafficAuditResult(h: HostItem, res: TrafficAuditResult) {
  const d = ensureHostDetails(h);
  const manual = !!d.traffic_manual_override;
  const previousUsed = d.traffic_used;
  const previousUnit = d.traffic_used_unit;
  const previousCycle = d.traffic_cycle_used_bytes;

  d.traffic_delta_bytes = res.traffic_delta_bytes;
  d.last_raw_bytes = res.last_raw_bytes;
  d.traffic_counter_sig = res.traffic_counter_sig;
  d.traffic_boot_id = res.traffic_boot_id;
  d.traffic_iface_baseline = res.traffic_iface_baseline;
  d.last_reset_timestamp = res.last_reset_timestamp;
  d.traffic_source_effective = res.traffic_source_effective;
  d.traffic_last_sync_ts = res.traffic_last_sync_ts;

  if (manual) {
    // 用户手工填写的已用流量优先级最高：只更新计数器基线，不改写展示值
    d.traffic_used = previousUsed;
    d.traffic_used_unit = previousUnit;
    d.traffic_cycle_used_bytes = previousCycle;
    if (!res.traffic_source_error || res.traffic_source_error.includes("低于本地记录")) {
      d.traffic_source_error = "手动校准优先，自动审计未覆盖已用流量";
    } else {
      d.traffic_source_error = res.traffic_source_error;
    }
  } else {
    d.traffic_cycle_used_bytes = res.traffic_cycle_used_bytes;
    d.traffic_used = res.traffic_used;
    d.traffic_used_unit = res.traffic_used_unit;
    d.traffic_source_error = res.traffic_source_error;
  }
}

// 同一个主机在同一时刻只允许一个审计任务，避免手动点击和定时任务并发
function runHostTrafficAudit(h: HostItem): Promise<TrafficAuditResult> {
  const key = trafficAuditKey(h);
  const existing = trafficAuditInFlight.get(key);
  if (existing) return existing;

  const d = ensureHostDetails(h);
  const source = d.traffic_source || "auto";
  const customCommand = d.traffic_custom_command || "";
  const tracked = invoke<TrafficAuditResult>("audit_host_traffic", {
    params: buildTrafficAuditParams(h, source, customCommand),
  }).finally(() => {
    trafficAuditInFlight.delete(key);
  });
  trafficAuditInFlight.set(key, tracked);
  return tracked;
}

// 串行写配置，避免 100 台主机同时回写造成文件竞争
function persistTrafficConfig(): Promise<void> {
  if (!isTauri) return Promise.resolve();
  trafficConfigSaveChain = trafficConfigSaveChain
    .catch(() => {})
    .then(async () => {
      await invoke("save_hosts_config", { config: configData.value });
    })
    .catch((err) => {
      console.warn("[traffic-audit] 保存配置失败:", err);
    });
  return trafficConfigSaveChain;
}

function trafficAuditIntervalFor(h: HostItem): number {
  const active = activeSession.value?.host;
  if (
    active &&
    active.host === h.host &&
    active.port === h.port &&
    (active.user || "") === (h.user || "")
  ) {
    return TRAFFIC_AUDIT_ACTIVE_INTERVAL_MS;
  }
  return TRAFFIC_AUDIT_INTERVAL_MS;
}

function trafficAuditBackoff(failures: number): number {
  const capped = Math.min(Math.max(failures, 1), 8);
  return Math.min(
    TRAFFIC_AUDIT_BACKOFF_MAX_MS,
    TRAFFIC_AUDIT_BACKOFF_BASE_MS * Math.pow(2, capped - 1)
  );
}

function markTrafficAuditOutcome(h: HostItem, res: TrafficAuditResult) {
  const key = trafficAuditKey(h);
  if (res.traffic_source_effective === "none") {
    const failures = (trafficAuditFailures.get(key) || 0) + 1;
    trafficAuditFailures.set(key, failures);
    trafficAuditNextAt.set(key, Date.now() + trafficAuditBackoff(failures));
  } else {
    trafficAuditFailures.delete(key);
    trafficAuditNextAt.set(key, Date.now() + trafficAuditIntervalFor(h));
  }
}

function dispatchScheduledTrafficAudit(h: HostItem) {
  const key = trafficAuditKey(h);
  if (trafficAuditInFlight.has(key)) return;

  trafficAuditNextAt.set(key, Date.now() + trafficAuditIntervalFor(h));
  runHostTrafficAudit(h)
    .then((res) => {
      applyTrafficAuditResult(h, res);
      markTrafficAuditOutcome(h, res);
      evaluateHostAlerts();
      void persistTrafficConfig();
    })
    .catch((err) => {
      const failures = (trafficAuditFailures.get(key) || 0) + 1;
      trafficAuditFailures.set(key, failures);
      trafficAuditNextAt.set(key, Date.now() + trafficAuditBackoff(failures));
      console.warn(`[traffic-audit] ${h.name} 审计失败:`, err);
    });
}

async function runTrafficAuditScheduler() {
  if (!trafficAuditSchedulerStarted || trafficAuditSchedulerBusy) return;
  trafficAuditSchedulerBusy = true;
  try {
    const hosts = configData.value.managed_hosts || [];
    const now = Date.now();
    const liveKeys = new Set(hosts.map(trafficAuditKey));

    for (const key of Array.from(trafficAuditNextAt.keys())) {
      if (!liveKeys.has(key)) {
        trafficAuditNextAt.delete(key);
        trafficAuditFailures.delete(key);
      }
    }

    for (const h of hosts) {
      const key = trafficAuditKey(h);
      if (!trafficAuditNextAt.has(key)) {
        trafficAuditNextAt.set(
          key,
          now + Math.floor(Math.random() * TRAFFIC_AUDIT_STARTUP_JITTER_MS)
        );
      }
    }

    if (trafficAuditInFlight.size >= TRAFFIC_AUDIT_MAX_CONCURRENCY) return;

    const dueHosts = hosts
      .filter((h) => {
        const key = trafficAuditKey(h);
        return (
          !trafficAuditInFlight.has(key) &&
          (trafficAuditNextAt.get(key) ?? 0) <= now
        );
      })
      .sort(
        (a, b) =>
          (a.details?.traffic_last_sync_ts || 0) -
          (b.details?.traffic_last_sync_ts || 0)
      );

    for (const h of dueHosts) {
      if (trafficAuditInFlight.size >= TRAFFIC_AUDIT_MAX_CONCURRENCY) break;
      dispatchScheduledTrafficAudit(h);
    }
  } finally {
    trafficAuditSchedulerBusy = false;
  }
}

function startTrafficAuditScheduler() {
  if (!isTauri || trafficAuditSchedulerStarted) return;
  trafficAuditSchedulerStarted = true;
  const now = Date.now();
  for (const h of configData.value.managed_hosts || []) {
    trafficAuditNextAt.set(
      trafficAuditKey(h),
      now + Math.floor(Math.random() * TRAFFIC_AUDIT_STARTUP_JITTER_MS)
    );
  }
  trafficAuditTimer = window.setInterval(() => {
    void runTrafficAuditScheduler();
  }, TRAFFIC_AUDIT_TICK_MS);
  window.setTimeout(() => {
    void runTrafficAuditScheduler();
  }, 1_200);
}

function stopTrafficAuditScheduler() {
  if (trafficAuditTimer !== null) {
    clearInterval(trafficAuditTimer);
    trafficAuditTimer = null;
  }
  trafficAuditSchedulerStarted = false;
}

function handleTrafficSchedulerWake() {
  if (document.visibilityState === "hidden") return;
  void runTrafficAuditScheduler();
}

async function syncTrafficStatsNow() {
  const m = trafficStatsModal.value;
  const h = m.host;
  if (!h || m.isSyncing) return;

  if (m.source === "custom" && !m.customCommand.trim()) {
    m.syncError = true;
    m.syncMessage = "选择自定义命令时，请填写远程执行命令。";
    return;
  }

  const d = ensureHostDetails(h);
  d.traffic_source = m.source;
  d.traffic_custom_command = m.customCommand;
  d.reset_day = m.resetDay;

  m.isSyncing = true;
  m.syncError = false;
  m.syncMessage = "正在连接服务器，获取流量数据...";

  try {
    const res = await runHostTrafficAudit(h);
    applyTrafficAuditResult(h, res);
    markTrafficAuditOutcome(h, res);
    m.calibUsed = ((d.traffic_cycle_used_bytes ?? res.traffic_cycle_used_bytes) / trafficUnitMultiplier(m.calibUnit)).toFixed(2);

    if (res.traffic_source_effective === "none") {
      m.syncError = true;
      m.syncMessage = res.traffic_source_error || "获取失败，未收到有效的流量数据。";
    } else {
      m.syncMessage = `获取成功 · 来源: ${trafficSourceLabel(res.traffic_source_effective)} · 当前周期已用 ${d.traffic_used || "0"}${d.traffic_used_unit || "GB"}`;
      if (res.traffic_source_error) {
        m.syncMessage += ` · ${res.traffic_source_error}`;
      }
    }

    await persistTrafficConfig();
    evaluateHostAlerts();
  } catch (err) {
    const failures = (trafficAuditFailures.get(trafficAuditKey(h)) || 0) + 1;
    trafficAuditFailures.set(trafficAuditKey(h), failures);
    trafficAuditNextAt.set(trafficAuditKey(h), Date.now() + trafficAuditBackoff(failures));
    m.syncError = true;
    m.syncMessage = `获取失败: ${String(err)}`;
  } finally {
    m.isSyncing = false;
  }
}

// 复制文本到剪贴板
function copyText(str: string) {
  if (navigator?.clipboard) {
    navigator.clipboard.writeText(str);
  }
  closeContextMenu();
}

// 重置流量为 0 (供主机管理大盘面板调用)
async function resetTrafficCounter(h: HostItem) {
  const d = ensureHostDetails(h);
  d.traffic_used = "0";
  d.traffic_cycle_used_bytes = 0;
  d.traffic_delta_bytes = 0;
  d.last_raw_bytes = 0;
  d.traffic_counter_sig = "";
  d.traffic_boot_id = "";
  d.traffic_iface_baseline = "";
  d.traffic_source_error = "";
  d.traffic_manual_override = false;
  trafficAuditFailures.delete(trafficAuditKey(h));
  trafficAuditNextAt.set(trafficAuditKey(h), Date.now() + trafficAuditIntervalFor(h));
  await persistTrafficConfig();
  evaluateHostAlerts();
  closeContextMenu();
}

// --- 设备列表与命令备忘录拖拽排序核心逻辑 ---
interface DragState {
  type: 'host' | 'device_group' | 'memo_item' | 'memo_group' | null;
  sourceGroupIdx: number | null;
  sourceItemIdx: number | null;
  targetGroupIdx: number | null;
  targetItemIdx: number | null;
  targetPosition: 'before' | 'after' | 'inside' | null;
}

const dragState = ref<DragState>({
  type: null,
  sourceGroupIdx: null,
  sourceItemIdx: null,
  targetGroupIdx: null,
  targetItemIdx: null,
  targetPosition: null,
});

function resetDragState() {
  dragState.value = {
    type: null,
    sourceGroupIdx: null,
    sourceItemIdx: null,
    targetGroupIdx: null,
    targetItemIdx: null,
    targetPosition: null,
  };
}

// 1. 设备主机拖拽
function onHostDragStart(gIdx: number, hIdx: number, e: DragEvent) {
  dragState.value.type = 'host';
  dragState.value.sourceGroupIdx = gIdx;
  dragState.value.sourceItemIdx = hIdx;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `host:${gIdx}:${hIdx}`);
  }
}

function onHostDragOver(gIdx: number, hIdx: number, e: DragEvent) {
  if (dragState.value.type !== 'host') return;
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';

  const target = e.currentTarget as HTMLElement | null;
  if (!target) return;
  const rect = target.getBoundingClientRect();
  const relY = e.clientY - rect.top;
  const pos: 'before' | 'after' = relY < rect.height / 2 ? 'before' : 'after';

  dragState.value.targetGroupIdx = gIdx;
  dragState.value.targetItemIdx = hIdx;
  dragState.value.targetPosition = pos;
}

async function onHostDrop(targetGroupIdx: number, targetHostIdx: number | null, e: DragEvent) {
  e.preventDefault();
  e.stopPropagation();

  if (dragState.value.type !== 'host' || dragState.value.sourceGroupIdx === null || dragState.value.sourceItemIdx === null) {
    resetDragState();
    return;
  }

  const srcGIdx = dragState.value.sourceGroupIdx;
  const srcHIdx = dragState.value.sourceItemIdx;
  const srcGroup = configData.value.devices[srcGIdx];
  const tgtGroup = configData.value.devices[targetGroupIdx];

  if (!srcGroup || !tgtGroup) {
    resetDragState();
    return;
  }

  // 取出移动的主机
  const [movedHost] = srcGroup.hosts.splice(srcHIdx, 1);
  if (!movedHost) {
    resetDragState();
    return;
  }

  if (targetHostIdx === null) {
    // 拖放到分组空白或分组头上
    tgtGroup.hosts.push(movedHost);
  } else {
    // 拖放到某具体主机前后
    let insertIdx = targetHostIdx;
    // 如果同一分组且原位置在目标之前，则由于 splice(1) 原数组长度减 1，需要校准 insertIdx
    if (srcGIdx === targetGroupIdx && srcHIdx < targetHostIdx) {
      insertIdx--;
    }
    if (dragState.value.targetPosition === 'after') {
      insertIdx++;
    }
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > tgtGroup.hosts.length) insertIdx = tgtGroup.hosts.length;
    tgtGroup.hosts.splice(insertIdx, 0, movedHost);
  }

  resetDragState();
  await invoke("save_hosts_config", { config: configData.value });
}

// 2. 设备分组拖拽
function onDeviceGroupDragStart(gIdx: number, e: DragEvent) {
  dragState.value.type = 'device_group';
  dragState.value.sourceGroupIdx = gIdx;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `device_group:${gIdx}`);
  }
}

function onDeviceGroupDragOver(gIdx: number, e: DragEvent) {
  if (dragState.value.type === 'host') {
    // 允许将主机拖拽放置到分组标题头上
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
    dragState.value.targetGroupIdx = gIdx;
    dragState.value.targetItemIdx = null;
    dragState.value.targetPosition = 'inside';
    return;
  }
  if (dragState.value.type !== 'device_group') return;
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';

  const target = e.currentTarget as HTMLElement | null;
  if (!target) return;
  const rect = target.getBoundingClientRect();
  const relY = e.clientY - rect.top;
  const pos: 'before' | 'after' = relY < rect.height / 2 ? 'before' : 'after';

  dragState.value.targetGroupIdx = gIdx;
  dragState.value.targetPosition = pos;
}

async function onDeviceGroupDrop(targetGroupIdx: number, e: DragEvent) {
  e.preventDefault();
  e.stopPropagation();

  if (dragState.value.type === 'host') {
    await onHostDrop(targetGroupIdx, null, e);
    return;
  }

  if (dragState.value.type !== 'device_group' || dragState.value.sourceGroupIdx === null) {
    resetDragState();
    return;
  }

  const srcGIdx = dragState.value.sourceGroupIdx;
  if (srcGIdx === targetGroupIdx) {
    resetDragState();
    return;
  }

  const [movedGroup] = configData.value.devices.splice(srcGIdx, 1);
  if (movedGroup) {
    let insertIdx = targetGroupIdx;
    if (srcGIdx < targetGroupIdx) {
      insertIdx--;
    }
    if (dragState.value.targetPosition === 'after') {
      insertIdx++;
    }
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > configData.value.devices.length) insertIdx = configData.value.devices.length;
    configData.value.devices.splice(insertIdx, 0, movedGroup);
    await invoke("save_hosts_config", { config: configData.value });
  }

  resetDragState();
}

// 3. 命令备忘录条目拖拽
function onMemoDragStart(gIdx: number, iIdx: number, e: DragEvent) {
  dragState.value.type = 'memo_item';
  dragState.value.sourceGroupIdx = gIdx;
  dragState.value.sourceItemIdx = iIdx;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `memo_item:${gIdx}:${iIdx}`);
  }
}

function onMemoDragOver(gIdx: number, iIdx: number, e: DragEvent) {
  if (dragState.value.type !== 'memo_item') return;
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';

  const target = e.currentTarget as HTMLElement | null;
  if (!target) return;
  const rect = target.getBoundingClientRect();
  const relY = e.clientY - rect.top;
  const pos: 'before' | 'after' = relY < rect.height / 2 ? 'before' : 'after';

  dragState.value.targetGroupIdx = gIdx;
  dragState.value.targetItemIdx = iIdx;
  dragState.value.targetPosition = pos;
}

async function onMemoDrop(targetGroupIdx: number, targetItemIdx: number | null, e: DragEvent) {
  e.preventDefault();
  e.stopPropagation();

  if (dragState.value.type !== 'memo_item' || dragState.value.sourceGroupIdx === null || dragState.value.sourceItemIdx === null) {
    resetDragState();
    return;
  }

  const srcGIdx = dragState.value.sourceGroupIdx;
  const srcIIdx = dragState.value.sourceItemIdx;
  const srcGroup = configData.value.memos?.[srcGIdx];
  const tgtGroup = configData.value.memos?.[targetGroupIdx];

  if (!srcGroup || !tgtGroup) {
    resetDragState();
    return;
  }

  const [movedItem] = srcGroup.items.splice(srcIIdx, 1);
  if (!movedItem) {
    resetDragState();
    return;
  }

  if (targetItemIdx === null) {
    tgtGroup.items.push(movedItem);
  } else {
    let insertIdx = targetItemIdx;
    if (srcGIdx === targetGroupIdx && srcIIdx < targetItemIdx) {
      insertIdx--;
    }
    if (dragState.value.targetPosition === 'after') {
      insertIdx++;
    }
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > tgtGroup.items.length) insertIdx = tgtGroup.items.length;
    tgtGroup.items.splice(insertIdx, 0, movedItem);
  }

  resetDragState();
  await invoke("save_hosts_config", { config: configData.value });
}

// 4. 命令备忘录分组拖拽
function onMemoGroupDragStart(gIdx: number, e: DragEvent) {
  dragState.value.type = 'memo_group';
  dragState.value.sourceGroupIdx = gIdx;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `memo_group:${gIdx}`);
  }
}

function onMemoGroupDragOver(gIdx: number, e: DragEvent) {
  if (dragState.value.type === 'memo_item') {
    // 允许条目拖到备忘录分组头上直接推入
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
    dragState.value.targetGroupIdx = gIdx;
    dragState.value.targetItemIdx = null;
    dragState.value.targetPosition = 'inside';
    return;
  }
  if (dragState.value.type !== 'memo_group') return;
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';

  const target = e.currentTarget as HTMLElement | null;
  if (!target) return;
  const rect = target.getBoundingClientRect();
  const relY = e.clientY - rect.top;
  const pos: 'before' | 'after' = relY < rect.height / 2 ? 'before' : 'after';

  dragState.value.targetGroupIdx = gIdx;
  dragState.value.targetPosition = pos;
}

async function onMemoGroupDrop(targetGroupIdx: number, e: DragEvent) {
  e.preventDefault();
  e.stopPropagation();

  if (dragState.value.type === 'memo_item') {
    await onMemoDrop(targetGroupIdx, null, e);
    return;
  }

  if (dragState.value.type !== 'memo_group' || dragState.value.sourceGroupIdx === null) {
    resetDragState();
    return;
  }

  const srcGIdx = dragState.value.sourceGroupIdx;
  if (srcGIdx === targetGroupIdx || !configData.value.memos) {
    resetDragState();
    return;
  }

  const [movedGroup] = configData.value.memos.splice(srcGIdx, 1);
  if (movedGroup) {
    let insertIdx = targetGroupIdx;
    if (srcGIdx < targetGroupIdx) {
      insertIdx--;
    }
    if (dragState.value.targetPosition === 'after') {
      insertIdx++;
    }
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > configData.value.memos.length) insertIdx = configData.value.memos.length;
    configData.value.memos.splice(insertIdx, 0, movedGroup);
    await invoke("save_hosts_config", { config: configData.value });
  }

  resetDragState();
}

// 分组新建、重命名与删除操作
function openNewGroupModal() {
  closeContextMenu();
  promptModal.value = {
    show: true,
    title: "新建设备分组",
    label: "分组名称:",
    value: "新分组",
    action: "new_device_group",
    payload: null,
  };
}

function openRenameGroupModal(g: DeviceGroup) {
  closeContextMenu();
  promptModal.value = {
    show: true,
    title: `重命名设备分组: ${g.group}`,
    label: "新分组名称:",
    value: g.group,
    action: "rename_device_group",
    payload: { group: g },
  };
}

async function deleteGroup(g: DeviceGroup) {
  closeContextMenu();
  configData.value.devices = configData.value.devices.filter(item => item !== g);
  await invoke("save_hosts_config", { config: configData.value });
}

function openNewMemoGroupModal() {
  closeContextMenu();
  promptModal.value = {
    show: true,
    title: "新建备忘录分组",
    label: "分组名称:",
    value: "新备忘组",
    action: "new_memo_group",
    payload: null,
  };
}

function openRenameMemoGroupModal(groupIdx: number) {
  closeContextMenu();
  const group = configData.value.memos?.[groupIdx];
  if (!group) return;
  promptModal.value = {
    show: true,
    title: `重命名备忘录分组: ${group.group}`,
    label: "新分组名称:",
    value: group.group,
    action: "rename_memo_group",
    payload: { groupIdx },
  };
}

async function deleteMemoGroup(groupIdx: number) {
  closeContextMenu();
  if (!configData.value.memos) return;
  configData.value.memos.splice(groupIdx, 1);
  await invoke("save_hosts_config", { config: configData.value });
}

// --- 配置加载 (支持在浏览器直接开发预览与调试) ---
async function loadConfig() {
  try {
    let cfg: AppConfig;
    if (isTauri) {
      cfg = await invoke<AppConfig>("load_hosts_config");
    } else {
      const localStr = localStorage.getItem("qshell_mock_config");
      if (localStr) {
        cfg = JSON.parse(localStr);
      } else {
        cfg = {
          devices: [
            {
              group: "VPS",
              hosts: [
                { name: "东京 Acck", host: "192.168.1.10", port: 22, user: "root" },
                { name: "香港 Hytron", host: "192.168.1.11", port: 22, user: "root" },
                { name: "英国 Akile", host: "192.168.1.12", port: 22, user: "root" },
              ]
            },
            {
              group: "本地",
              hosts: [
                { name: "OpenWrt", host: "192.168.254.1", port: 2281, user: "root" },
                { name: "Debian(新城)", host: "192.168.1.2", port: 22, user: "root" },
              ]
            }
          ],
          managed_hosts: [],
          memos: [
            {
              group: "系统运维常用",
              items: [
                { name: "查看监听端口", cmd: "netstat -tulnp" },
                { name: "查看内存 Top", cmd: "ps aux --sort=-%mem | head -n 10" },
                { name: "系统日志", cmd: "journalctl -xe --no-pager | tail -n 20" },
                { name: "系统负载状态", cmd: "htop" },
                { name: "Docker 容器状态", cmd: "docker ps -a" },
              ]
            }
          ],
          settings: {
            font_family: "Consolas",
            font_size: 11,
            is_bold: false,
            cursor_style: "block",
            cursor_blink: true,
            terminal_fg_color: "#81C995",
          }
        };
      }
    }
    configData.value = cfg;
    if (cfg.settings) {
      if (cfg.settings.app_font_family) {
        applyAppFont(cfg.settings.app_font_family);
      }
      if (cfg.settings.font_family) terminalSettings.value.font_family = cfg.settings.font_family;
      if (cfg.settings.font_size) terminalSettings.value.font_size = cfg.settings.font_size;
      if (cfg.settings.is_bold !== undefined) terminalSettings.value.is_bold = !!cfg.settings.is_bold;
      if (cfg.settings.cursor_style) terminalSettings.value.cursor_style = cfg.settings.cursor_style as any;
      if (cfg.settings.cursor_blink !== undefined) terminalSettings.value.cursor_blink = !!cfg.settings.cursor_blink;
      if (cfg.settings.blink_interval) terminalSettings.value.blink_interval = Number(cfg.settings.blink_interval) || 530;
      if (cfg.settings.term_bg_mode) terminalSettings.value.term_bg_mode = cfg.settings.term_bg_mode as any;
      if (cfg.settings.terminal_fg_color) terminalSettings.value.terminal_fg_color = cfg.settings.terminal_fg_color;
      if (cfg.settings.terminal_bg_color) terminalSettings.value.terminal_bg_color = cfg.settings.terminal_bg_color;
      if (cfg.settings.minimize_to_tray !== undefined) terminalSettings.value.minimize_to_tray = !!cfg.settings.minimize_to_tray;
      if (cfg.settings.webdav) {
        backupModal.value.webdav_url = cfg.settings.webdav.url || "";
        backupModal.value.webdav_user = cfg.settings.webdav.user || "";
        backupModal.value.webdav_pwd = cfg.settings.webdav.pwd || "";
        backupModal.value.webdav_path = cfg.settings.webdav.path || "/qshell_backup.zip";
      }
    }
    if (!configData.value.memos || configData.value.memos.length === 0) {
      configData.value.memos = [
        {
          group: "系统运维常用",
          items: [
            { name: "查看监听端口", cmd: "netstat -tulnp" },
            { name: "查看内存 Top", cmd: "ps aux --sort=-%mem | head -n 10" },
            { name: "系统日志", cmd: "journalctl -xe --no-pager | tail -n 20" },
            { name: "系统负载状态", cmd: "htop" },
            { name: "Docker 容器状态", cmd: "docker ps -a" },
          ]
        }
      ];
    }
    evaluateHostAlerts();
  } catch (e) {
    console.error("加载配置失败:", e);
  }
}

// 1:1 对标 ssh8.py TerminalSettingsDialog: 设置终端背景预设 (黑/白)
function setTerminalBgPreset(mode: "dark" | "light") {
  terminalSettings.value.term_bg_mode = mode;
  if (mode === "dark") {
    terminalSettings.value.terminal_bg_color = "#0A0B0E";
    terminalSettings.value.terminal_fg_color = "#81C995";
  } else {
    terminalSettings.value.terminal_bg_color = "#F4F5F7";
    terminalSettings.value.terminal_fg_color = "#111318";
  }
}

// 1:1 对标 ssh8.py refresh_color_palette_buttons
const darkPresetColors = ["#81C995", "#A8C7FA", "#FDD663", "#E2E2E9"];
const lightPresetColors = ["#111318", "#0B57D0", "#15803D", "#44474E"];

function openBackupFromSettings() {
  showTerminalSettingsModal.value = false;
  backupModal.value.show = true;
}

// 1:1 对标 ssh8.py applyCursorBlinkSettings: 动态计算并在终端根容器注入闪烁动画与 CSS 变量
function applyCursorBlinkToTerminal(term: Terminal, enabled: boolean, intervalMs: number, fgColor: string, bgColor: string, cursorStyle: string) {
  if (!term.element) {
    console.warn("[cursor-blink] term.element is null!");
    return;
  }
  const phaseDuration = Math.max(200, Math.min(2000, Number(intervalMs) || 530));
  const cycleDuration = phaseDuration * 2;

  const rawEl = term.element as HTMLElement;
  console.log("[cursor-blink] rawEl:", rawEl.tagName, "classes:", rawEl.className);
  console.log("[cursor-blink] rawEl.parentElement:", rawEl.parentElement?.tagName, rawEl.parentElement?.className);

  // 查找带有 .xterm 类的元素
  const xtermEl = rawEl.classList.contains("xterm")
    ? rawEl
    : rawEl.querySelector(".xterm") as HTMLElement | null;
  const mountBox = rawEl.closest(".terminal-mount-box") || rawEl.parentElement;
  const fallbackXtermEl = mountBox?.querySelector(".xterm") as HTMLElement | null;
  const el = xtermEl || fallbackXtermEl || rawEl;

  console.log("[cursor-blink] final el:", el.tagName, "classes:", el.className);
  console.log("[cursor-blink] enabled:", enabled, "style:", cursorStyle);

  // 打印 cursor 元素的完整 DOM 路径
  const cursorNode = el.querySelector("[class*='xterm-cursor']");
  if (cursorNode) {
    const chain: string[] = [];
    let node = cursorNode as HTMLElement;
    while (node && node !== el) {
      chain.unshift(node.tagName + "." + Array.from(node.classList).join("."));
      node = node.parentElement as HTMLElement;
    }
    console.log("[cursor-blink] cursor DOM path:", chain.join(" > "));
  } else {
    console.log("[cursor-blink] cursor element NOT found yet (may render later)");
  }

  el.classList.toggle("ssh-cursor-blink-enabled", enabled);
  el.classList.toggle("ssh-cursor-blink-disabled", !enabled);
  el.style.setProperty("--ssh-cursor-blink-cycle", `${cycleDuration}ms`);
  el.style.setProperty("--ssh-cursor-color", fgColor || "#81C995");
  el.style.setProperty("--ssh-cursor-accent", bgColor || "#0A0B0E");
  el.style.setProperty("--ssh-cursor-bar-shadow", `1px 0 0 ${fgColor || '#81C995'} inset`);
  
  // 同步 xterm options
  term.options.cursorBlink = enabled;
  const normalizedStyle = (["block", "bar", "underline"].includes(cursorStyle) ? cursorStyle : "block") as "block" | "bar" | "underline";
  term.options.cursorStyle = normalizedStyle;
  term.options.cursorInactiveStyle = normalizedStyle;

  console.log("[cursor-blink] DONE - el classes now:", el.className);

  if (typeof (term as any).refresh === "function" && term.rows > 0) {
    term.refresh(0, term.rows - 1);
  }
}

// 应用终端设置到所有已激活的终端 (1:1 严格对标 ssh8.py refresh_all_terminal_appearances)
function applyTerminalSettings(closeModal: boolean | MouseEvent = true) {
  const shouldClose = typeof closeModal === "boolean" ? closeModal : true;
  const isDark = terminalSettings.value.term_bg_mode === "dark";
  const bgCol = isDark ? "#0A0B0E" : "#F4F5F7";
  const fgCol = terminalSettings.value.terminal_fg_color || (isDark ? "#81C995" : "#111318");
  terminalSettings.value.terminal_bg_color = bgCol;
  terminalSettings.value.terminal_fg_color = fgCol;

  sessions.value.forEach(s => {
    if (s.termInstance) {
      const term = s.termInstance;
      term.options.fontFamily = terminalSettings.value.font_family;
      term.options.fontSize = terminalSettings.value.font_size;
      term.options.fontWeight = terminalSettings.value.is_bold ? "bold" : "normal";
      term.options.cursorStyle = terminalSettings.value.cursor_style;
      term.options.cursorInactiveStyle = terminalSettings.value.cursor_style;
      
      // 更新 xterm 调色板
      term.options.theme = {
        background: bgCol,
        foreground: fgCol,
        cursor: fgCol,
        cursorAccent: bgCol,
        selectionBackground: isDark ? "rgba(168, 199, 250, 0.3)" : "#CBD5E1",
        black: isDark ? "#1A1D24" : "#000000",
        red: "#F28B82",
        green: "#81C995",
        yellow: "#FDD663",
        blue: isDark ? "#78D9EC" : "#1A73E8",
        magenta: "#D7AEFB",
        cyan: "#78D9EC",
        white: isDark ? "#FFFFFF" : "#1F2937",
      };

      // 同步外层挂载 DOM 的背景色
      const mountEl = document.getElementById(`term-${s.id}`);
      if (mountEl) {
        mountEl.style.backgroundColor = bgCol;
      }

      // 接管并注入精准闪烁节奏与颜色变量
      applyCursorBlinkToTerminal(
        term,
        terminalSettings.value.cursor_blink,
        terminalSettings.value.blink_interval,
        fgCol,
        bgCol,
        terminalSettings.value.cursor_style
      );

      s.fitInstance?.fit();
    }
  });

  if (!configData.value.settings) configData.value.settings = {};
  configData.value.settings.app_font_family = appFontFamily.value;
  configData.value.settings.font_family = terminalSettings.value.font_family;
  configData.value.settings.font_size = terminalSettings.value.font_size;
  configData.value.settings.is_bold = terminalSettings.value.is_bold;
  configData.value.settings.cursor_style = terminalSettings.value.cursor_style;
  configData.value.settings.cursor_blink = terminalSettings.value.cursor_blink;
  configData.value.settings.blink_interval = terminalSettings.value.blink_interval;
  configData.value.settings.term_bg_mode = terminalSettings.value.term_bg_mode;
  configData.value.settings.terminal_fg_color = fgCol;
  configData.value.settings.terminal_bg_color = bgCol;
  configData.value.settings.custom_bg_image = terminalSettings.value.custom_bg_image;
  configData.value.settings.minimize_to_tray = terminalSettings.value.minimize_to_tray;
  invoke("save_hosts_config", { config: configData.value });
  if (shouldClose) {
    showTerminalSettingsModal.value = false;
  }
}

// --- 会话连接与多会话 ---
async function openSession(h: HostItem) {
  if (currentView.value !== "workspace") {
    currentView.value = "workspace";
    await nextTick();
  }

  const sid = `sess-${Date.now()}`;
  const newTab: SessionTab = {
    id: sid,
    name: h.name,
    host: h,
    alive: false,
    is_connecting: true,
  };
  sessions.value.push(newTab);
  activeSessionId.value = sid;
  await nextTick();

  const mountEl = document.getElementById(`term-${sid}`);
  if (!mountEl) return;

  const isDark = terminalSettings.value.term_bg_mode === "dark";
  const bgCol = isDark ? "#0A0B0E" : "#F4F5F7";
  const fgCol = terminalSettings.value.terminal_fg_color || (isDark ? "#81C995" : "#111318");

  mountEl.style.backgroundColor = bgCol;

  const term = new Terminal({
    fontFamily: terminalSettings.value.font_family,
    fontSize: terminalSettings.value.font_size,
    fontWeight: terminalSettings.value.is_bold ? "bold" : "normal",
    lineHeight: 1.25,
    cursorBlink: terminalSettings.value.cursor_blink,
    cursorStyle: terminalSettings.value.cursor_style,
    cursorInactiveStyle: terminalSettings.value.cursor_style,
    allowTransparency: true,
    theme: {
      background: bgCol,
      foreground: fgCol,
      cursor: fgCol,
      cursorAccent: bgCol,
      selectionBackground: isDark ? "rgba(168, 199, 250, 0.3)" : "#CBD5E1",
      black: isDark ? "#1A1D24" : "#000000",
      red: "#F28B82",
      green: "#81C995",
      yellow: "#FDD663",
      blue: isDark ? "#78D9EC" : "#1A73E8",
      magenta: "#D7AEFB",
      cyan: "#78D9EC",
      white: isDark ? "#FFFFFF" : "#1F2937",
    }
  });

  const fit = new FitAddon();
  term.loadAddon(fit);
  term.open(mountEl);
  fit.fit();
  term.focus();
  newTab.termInstance = term;
  newTab.fitInstance = fit;

  // 1:1 对标 ssh8.py: 接管并注入精准闪烁节奏与颜色变量
  applyCursorBlinkToTerminal(
    term,
    terminalSettings.value.cursor_blink,
    terminalSettings.value.blink_interval,
    fgCol,
    bgCol,
    terminalSettings.value.cursor_style
  );
  // Ensure terminal receives focus so xterm adds .xterm-cursor-blink class
  term.focus();

  // 全量键盘快捷键捕获 (复制/粘贴/全选)
  term.attachCustomKeyEventHandler((e: KeyboardEvent) => {
    if (e.type !== "keydown") return true;
    const key = String(e.key || "").toLowerCase();
    // 复制快捷键：Ctrl+Shift+C 或 Ctrl+Insert
    if ((e.ctrlKey && e.shiftKey && key === "c") || (e.ctrlKey && key === "insert")) {
      const sel = term.getSelection();
      if (sel) navigator.clipboard.writeText(sel);
      return false;
    }
    // 粘贴快捷键：Ctrl+Shift+V 或 Shift+Insert
    if ((e.ctrlKey && e.shiftKey && key === "v") || (e.shiftKey && key === "insert")) {
      navigator.clipboard.readText().then(text => {
        if (text && newTab.alive && isTauri) invoke("write_ssh_session", { sessionId: sid, data: text });
      });
      return false;
    }
    return true;
  });

  term.writeln(`\x1b[36m[QShell]\x1b[0m 正在连接到 ${h.name} (${h.host}:${h.port})...`);

  if (isTauri) {
    // 终端输入监听：1:1 对标 ssh8.py send_to_ssh
    // 正常连接时转发到 SSH；断开状态下按回车触发 reconnectSession 重连
    term.onData((data) => {
      if (newTab.alive) {
        invoke("write_ssh_session", { sessionId: sid, data });
      } else {
        if (data.includes("\r") || data.includes("\n")) {
          reconnectSession(newTab);
        }
      }
    });

    const unlisten = await listen<string>(`ssh-data-${sid}`, (event) => {
      term.write(event.payload);
    });
    newTab.unlisten = unlisten;

    // 监听断开事件：1:1 对标 ssh8.py handle_terminal_disconnected
    listen(`ssh-closed-${sid}`, () => {
      newTab.alive = false;
      newTab.is_connecting = false;
      resetMonitorStats();
      term.writeln("\r\n\x1b[33m[终端连接已断开。按回车键重新连接...]\x1b[0m\r\n");
    });

    await doStartSsh(newTab);
  } else {
    // 浏览器预览模式 (兼容 http://localhost:1420 离线/浏览器端即时体验)
    newTab.alive = true;
    term.writeln(`\x1b[32m[QShell]\x1b[0m 连接成功 (浏览器预览模式: root@${h.host})`);
    term.write(`root@${h.host}:~# `);
    let curCmd = "";
    term.onData((data) => {
      if (data === "\r") {
        term.write("\r\n");
        if (curCmd.trim() === "clear") {
          term.clear();
        } else if (curCmd.trim()) {
          term.writeln(`\x1b[90m执行命令:\x1b[0m ${curCmd}`);
        }
        curCmd = "";
        term.write(`root@${h.host}:~# `);
      } else if (data === "\x7f") {
        if (curCmd.length > 0) {
          curCmd = curCmd.slice(0, -1);
          term.write("\b \b");
        }
      } else {
        curCmd += data;
        term.write(data);
      }
    });

    const resizeObserver = new ResizeObserver(() => {
      if (term.element) {
        requestAnimationFrame(() => {
          try { fit.fit(); } catch (_) {}
        });
      }
    });
    resizeObserver.observe(mountEl);
    newTab.resizeObserver = resizeObserver;
  }
}

// 统一的 SSH 会话启动逻辑 (支持初次连接与重连)
async function doStartSsh(tab: SessionTab) {
  const sid = tab.id;
  const h = tab.host;
  const term = tab.termInstance;
  const fit = tab.fitInstance;
  if (!term) return;

  try {
    await invoke<string>("start_ssh_session", {
      params: {
        session_id: sid,
        host: h.host,
        port: h.port,
        username: h.user,
        password: h.pwd || null,
        private_key: h.key_path || null,
        passphrase: h.passphrase || null,
        cols: term.cols || 80,
        rows: term.rows || 24,
      }
    });
    tab.alive = true;
    tab.is_connecting = false;
    fetchSftpFiles("/");

    // 监听视口尺寸变化
    if (!tab.resizeObserver && fit && (term as any).element?.parentElement) {
      const mountEl = (term as any).element.parentElement;
      const resizeObserver = new ResizeObserver(() => {
        if (tab.alive && term.element) {
          requestAnimationFrame(() => {
            try {
              fit.fit();
              if (term.cols > 0 && term.rows > 0) {
                invoke("resize_ssh_session", {
                  sessionId: sid,
                  cols: term.cols,
                  rows: term.rows,
                });
              }
            } catch (_) {}
          });
        }
      });
      resizeObserver.observe(mountEl);
      tab.resizeObserver = resizeObserver;
    }

    // 终端自带 onResize 监听兜底
    term.onResize(({ cols, rows }) => {
      if (tab.alive) {
        invoke("resize_ssh_session", { sessionId: sid, cols, rows });
      }
    });

    // 启动当前活动主机的实时监控轮询
    startMonitoringLoop(sid);
  } catch (err: any) {
    tab.alive = false;
    tab.is_connecting = false;
    term.writeln(`\x1b[31m[连接失败]\x1b[0m ${err}\r\n`);
    term.writeln("\x1b[33m[按回车键重新尝试连接...]\x1b[0m\r\n");
    resetMonitorStats();
  }
}

// 1:1 对标 ssh8.py reconnect_session: 在终端中断或连接失败后，用户按回车发起重连
async function reconnectSession(tab: SessionTab) {
  if (tab.alive || tab.is_connecting) return;
  const term = tab.termInstance;
  if (!term) return;

  tab.is_connecting = true;
  tab.alive = false;
  resetMonitorStats();

  // 1:1 对标 ssh8.py 提示文本
  term.writeln("\r\n\x1b[36m[正在尝试重新连接终端...]\x1b[0m");

  if (isTauri) {
    // 先关闭远端旧可能存在的连接资源
    try {
      await invoke("close_ssh_session", { sessionId: tab.id });
    } catch (_) {}

    await doStartSsh(tab);
  } else {
    // 浏览器预览模式重连
    setTimeout(() => {
      tab.alive = true;
      tab.is_connecting = false;
      term.writeln(`\x1b[32m[QShell]\x1b[0m 重连成功 (浏览器预览模式: root@${tab.host.host})`);
      term.write(`root@${tab.host.host}:~# `);
    }, 400);
  }
}

let latencyInterval: number | null = null;

// 独立即时测速函数：连上或切到终端时毫秒级触发，不被任何耗时的系统指标采集阻塞
async function probeSessionLatency(sid: string) {
  if (activeSessionId.value !== sid) return;
  const currentTab = sessions.value.find(s => s.id === sid);
  if (!currentTab?.host?.host) return;
  try {
    const latRes = await invoke<string>("probe_latency", {
      host: currentTab.host.host.trim(),
      port: currentTab.host.port || 22,
      mode: "icmp",
    });
    const m = latRes.match(/([0-9]+(?:\.[0-9]+)?)\s*ms/);
    let probedVal = 0;
    if (m) {
      probedVal = Math.round(parseFloat(m[1]));
    } else if (latRes.includes("<1")) {
      probedVal = 1;
    }
    if (probedVal > 0) {
      currentTab.latency = probedVal; // 会话级持久化缓存，切换标签秒出
      if (activeSessionId.value === sid) {
        monitorStats.value.latency = probedVal;
      }
    }
  } catch (_) {}
}

function startMonitoringLoop(sid: string) {
  if (monitorInterval) { clearInterval(monitorInterval); monitorInterval = null; }
  if (latencyInterval) { clearInterval(latencyInterval); latencyInterval = null; }

  // 1. 终端连上后【立刻】执行首次测速
  probeSessionLatency(sid);
  // 保持 3 秒一次心跳测速
  latencyInterval = window.setInterval(() => {
    probeSessionLatency(sid);
  }, 3000);

  // 2. 独立的系统指标采集轮询 (3秒心跳)
  const pollMetrics = async () => {
    if (activeSessionId.value !== sid) return;
    try {
      const stats = await invoke<{ cpu: number; mem: number; disk: number; net_up: string; net_down: string; net_if?: string }>(
        "fetch_system_metrics", 
        { sessionId: sid }
      );
      if (stats && activeSessionId.value === sid) {
        if (stats.cpu > 0 || monitorStats.value.cpu === 0) monitorStats.value.cpu = stats.cpu;
        if (stats.mem > 0 || monitorStats.value.mem === 0) monitorStats.value.mem = stats.mem;
        if (stats.disk > 0 || monitorStats.value.disk === 0) monitorStats.value.disk = stats.disk;
        if (stats.net_up) monitorStats.value.net_up = stats.net_up;
        if (stats.net_down) monitorStats.value.net_down = stats.net_down;
        if (stats.net_if) monitorStats.value.net_if = stats.net_if;
      }
    } catch (e) {
      console.warn("系统指标采集返回 (保留上一次快照):", e);
    }
  };
  pollMetrics();
  monitorInterval = window.setInterval(pollMetrics, 3000);
}

function switchSession(sid: string) {
  if (activeSessionId.value === sid) return;
  activeSessionId.value = sid;
  // 兜底方案：切换标签时直接无缝继承该标签此前已缓存的延迟，实现 0ms 视觉即时响应
  const cur = sessions.value.find(s => s.id === sid);
  if (cur?.latency && cur.latency > 0) {
    monitorStats.value.latency = cur.latency;
  } else {
    monitorStats.value.latency = 0;
  }
  startMonitoringLoop(sid);

  // 解决切换标签页吞字/重叠：等 DOM 切换显示并完成几何计算后执行多帧适配与刷新
  const doRefitAndRefresh = () => {
    if (activeSessionId.value !== sid) return;
    if (cur?.termInstance && cur.fitInstance) {
      try {
        cur.fitInstance.fit();
        if (cur.alive && cur.termInstance.cols > 0 && cur.termInstance.rows > 0) {
          invoke("resize_ssh_session", {
            sessionId: sid,
            cols: cur.termInstance.cols,
            rows: cur.termInstance.rows,
          });
        }
        cur.termInstance.refresh(0, cur.termInstance.rows - 1);
        cur.termInstance.focus();
      } catch (_) {}
    }
  };

  nextTick(() => {
    doRefitAndRefresh();
    requestAnimationFrame(() => {
      doRefitAndRefresh();
      setTimeout(doRefitAndRefresh, 60);
    });
  });
}

function closeSession(tab: SessionTab) {
  if (tab.is_locked) return; // 锁定状态禁止关闭
  if (tab.resizeObserver) tab.resizeObserver.disconnect();
  if (tab.unlisten) tab.unlisten();
  if (tab.termInstance) tab.termInstance.dispose();
  invoke("close_ssh_session", { sessionId: tab.id });
  sessions.value = sessions.value.filter(s => s.id !== tab.id);
  if (sessions.value.length === 0) {
    activeSessionId.value = "";
    if (monitorInterval) clearInterval(monitorInterval);
    resetMonitorStats();
  } else if (activeSessionId.value === tab.id) {
    const nextTab = sessions.value[sessions.value.length - 1];
    activeSessionId.value = nextTab.id;
    startMonitoringLoop(nextTab.id);
  }
}

const sftpErrorMsg = ref("");

function switchRightPanelTab(tab: "sftp" | "memo") {
  rightPanelTab.value = tab;
  if (tab === "sftp" && activeSessionId.value) {
    fetchSftpFiles(currentSftpPath.value || "/");
  }
}

// --- SFTP 核心逻辑 ---
async function fetchSftpFiles(path: string) {
  if (!activeSessionId.value) return;
  isSftpLoading.value = true;
  sftpErrorMsg.value = "";
  try {
    const list = await invoke<SftpFileItem[]>("list_sftp_files", {
      sessionId: activeSessionId.value,
      remotePath: path,
    });
    currentSftpPath.value = path;
    sftpFiles.value = list;
  } catch (err: any) {
    console.error("读取 SFTP 目录失败:", err);
    sftpErrorMsg.value = `SFTP 读取失败: ${err}`;
  } finally {
    isSftpLoading.value = false;
  }
}

function sftpNavigateParent() {
  if (currentSftpPath.value === "/" || !currentSftpPath.value) return;
  const parts = currentSftpPath.value.split("/").filter(Boolean);
  parts.pop();
  const parent = "/" + parts.join("/");
  fetchSftpFiles(parent || "/");
}

function sftpCd(item: SftpFileItem) {
  if (!item.is_dir) return;
  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  fetchSftpFiles(base + item.name);
}

const isSftpDragOver = ref(false);

async function uploadLocalPath(localPath: string) {
  if (!activeSessionId.value) return;
  const fname = localPath.split(/[/\\]/).pop() || "upload_file";
  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  const remotePath = base + fname;
  const taskId = `up-${Date.now()}`;

  showTransferMonitor.value = true;
  activeTransfers.value.push({
    task_id: taskId,
    filename: fname,
    is_upload: true,
    transferred: 0,
    total: 100,
    speed_bps: 0,
    status: "running",
  });

  try {
    await invoke("sftp_upload_file", {
      sessionId: activeSessionId.value,
      localPath,
      remotePath,
      taskId,
    });
    fetchSftpFiles(currentSftpPath.value);
  } catch (e: any) {
    console.error("上传错误:", e);
  }
}

// SFTP 文件上传 (按钮触发)
async function sftpTriggerUpload() {
  closeContextMenu();
  if (!activeSessionId.value) return;
  const selected = await openFileDialog({
    multiple: false,
    title: "选择要上传到远程服务器的文件",
  });
  if (!selected) return;

  const localPath = typeof selected === "string" ? selected : selected[0];
  await uploadLocalPath(localPath);
}

// SFTP 文件下载
async function sftpTriggerDownload(item: SftpFileItem) {
  closeContextMenu();
  if (!activeSessionId.value) return;
  const targetSavePath = await saveFileDialog({
    defaultPath: item.name,
    title: `下载文件: ${item.name}`,
  });
  if (!targetSavePath) return;

  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  const remotePath = base + item.name;
  const taskId = `down-${Date.now()}`;

  showTransferMonitor.value = true;
  activeTransfers.value.push({
    task_id: taskId,
    filename: item.name,
    is_upload: false,
    transferred: 0,
    total: item.size_bytes || 100,
    speed_bps: 0,
    status: "running",
  });

  try {
    await invoke("sftp_download_file", {
      sessionId: activeSessionId.value,
      remotePath,
      localPath: targetSavePath,
      taskId,
    });
  } catch (e: any) {
    console.error("下载错误:", e);
  }
}

// SFTP 查看文件属性 (SFTPPropertiesDialog)
async function sftpViewProperties(item: SftpFileItem) {
  closeContextMenu();
  if (!activeSessionId.value) return;
  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  const fullPath = base + item.name;

  try {
    const props = await invoke<any>("sftp_stat", {
      sessionId: activeSessionId.value,
      remotePath: fullPath,
    });
    sftpPropsModal.value = {
      show: true,
      name: props.name,
      full_path: props.full_path,
      is_dir: props.is_dir,
      size_bytes: props.size_bytes,
      mode_str: props.mode_str,
      mode_oct: props.mode_oct,
      mtime_str: new Date(props.mtime_str * 1000).toLocaleString(),
    };
  } catch (e) {
    console.error("获取文件属性失败:", e);
  }
}

// SFTP 修改权限 (SFTPChmodDialog)
function sftpOpenChmod(item: SftpFileItem) {
  closeContextMenu();
  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  const fullPath = base + item.name;

  let oct = parseInt(item.mode_oct || item.mode_str, 8) || 0o755;
  sftpChmodModal.value = {
    show: true,
    filePath: fullPath,
    fileName: item.name,
    u_r: !!(oct & 0o400), u_w: !!(oct & 0o200), u_x: !!(oct & 0o100),
    g_r: !!(oct & 0o040), g_w: !!(oct & 0o020), g_x: !!(oct & 0o010),
    o_r: !!(oct & 0o004), o_w: !!(oct & 0o002), o_x: !!(oct & 0o001),
  };
}

async function sftpSaveChmod() {
  const m = sftpChmodModal.value;
  let oct = 0;
  if (m.u_r) oct |= 0o400; if (m.u_w) oct |= 0o200; if (m.u_x) oct |= 0o100;
  if (m.g_r) oct |= 0o040; if (m.g_w) oct |= 0o020; if (m.g_x) oct |= 0o010;
  if (m.o_r) oct |= 0o004; if (m.o_w) oct |= 0o002; if (m.o_x) oct |= 0o001;

  const octStr = oct.toString(8).padStart(4, "0");
  try {
    await invoke("sftp_chmod", {
      sessionId: activeSessionId.value,
      remotePath: m.filePath,
      modeOct: octStr,
    });
    m.show = false;
    await fetchSftpFiles(currentSftpPath.value);
  } catch (e: any) {
    console.error("修改权限失败:", e);
    alert(`修改权限失败: ${e?.message || e}`);
  }
}

// SFTP 新建目录 / 重命名 / 删除
function sftpOpenNewFolder() {
  closeContextMenu();
  promptModal.value = {
    show: true,
    title: "新建远程文件夹",
    label: "文件夹名称:",
    value: "新建文件夹",
    action: "new_folder",
    payload: null,
  };
}

function sftpOpenRename(item: SftpFileItem) {
  closeContextMenu();
  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  promptModal.value = {
    show: true,
    title: `重命名: ${item.name}`,
    label: "新名称:",
    value: item.name,
    action: "rename_file",
    payload: { oldPath: base + item.name, base },
  };
}

async function executePromptModal() {
  const p = promptModal.value;
  const val = p.value.trim();
  if (!val) return;

  try {
    if (p.action === "new_device_group") {
      configData.value.devices.push({ group: val, hosts: [] });
      await invoke("save_hosts_config", { config: configData.value });
      p.show = false;
      return;
    } else if (p.action === "rename_device_group") {
      if (p.payload?.group) {
        p.payload.group.group = val;
        await invoke("save_hosts_config", { config: configData.value });
      }
      p.show = false;
      return;
    } else if (p.action === "new_memo_group") {
      if (!configData.value.memos) configData.value.memos = [];
      configData.value.memos.push({ group: val, items: [] });
      await invoke("save_hosts_config", { config: configData.value });
      p.show = false;
      return;
    } else if (p.action === "rename_memo_group") {
      const idx = p.payload?.groupIdx;
      if (idx !== undefined && configData.value.memos?.[idx]) {
        configData.value.memos[idx].group = val;
        await invoke("save_hosts_config", { config: configData.value });
      }
      p.show = false;
      return;
    }

    // 以下为 SFTP 文件操作 (依赖活动会话)
    if (!activeSessionId.value) return;

    if (p.action === "new_folder") {
      const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
      await invoke("sftp_mkdir", {
        sessionId: activeSessionId.value,
        remotePath: base + val,
      });
    } else if (p.action === "rename_file") {
      await invoke("sftp_rename", {
        sessionId: activeSessionId.value,
        oldPath: p.payload.oldPath,
        newPath: p.payload.base + val,
      });
    }
    p.show = false;
    fetchSftpFiles(currentSftpPath.value);
  } catch (e) {
    console.error("操作失败:", e);
  }
}

async function sftpDeleteItem(item: SftpFileItem) {
  closeContextMenu();
  if (!activeSessionId.value) return;
  const base = currentSftpPath.value.endsWith("/") ? currentSftpPath.value : currentSftpPath.value + "/";
  try {
    await invoke("sftp_remove", {
      sessionId: activeSessionId.value,
      remotePath: base + item.name,
      isDir: item.is_dir,
    });
    await fetchSftpFiles(currentSftpPath.value);
  } catch (e: any) {
    console.error("删除失败:", e);
    alert(`删除失败: ${e?.message || e}`);
  }
}

// 格式化网络速度
function formatSpeed(bps: number) {
  if (bps < 1024) return `${bps} B/s`;
  if (bps < 1024 * 1024) return `${(bps / 1024).toFixed(1)} KB/s`;
  return `${(bps / (1024 * 1024)).toFixed(2)} MB/s`;
}

// --- 备忘录管理 ---
function sendMemoCommand(cmd: string) {
  const cur = sessions.value.find(s => s.id === activeSessionId.value);
  if (cur && cur.alive) {
    invoke("write_ssh_session", { sessionId: cur.id, data: cmd + "\n" });
  } else {
    navigator.clipboard.writeText(cmd);
  }
}

function openAddMemoModal(groupIdx: number) {
  memoEditModal.value = {
    show: true,
    isEdit: false,
    groupIndex: groupIdx,
    itemIndex: -1,
    form: { name: "", cmd: "" }
  };
}

function openEditMemoModal(groupIdx: number, itemIdx: number, item: MemoItem) {
  memoEditModal.value = {
    show: true,
    isEdit: true,
    groupIndex: groupIdx,
    itemIndex: itemIdx,
    form: { name: item.name, cmd: item.cmd }
  };
}

async function saveMemo() {
  const m = memoEditModal.value;
  if (!configData.value.memos) configData.value.memos = [];
  const group = configData.value.memos[m.groupIndex];
  if (!group) return;

  if (m.isEdit && m.itemIndex >= 0) {
    group.items[m.itemIndex] = { ...m.form };
  } else {
    group.items.push({ ...m.form });
  }

  await invoke("save_hosts_config", { config: configData.value });
  m.show = false;
}

async function deleteMemo(groupIdx: number, itemIdx: number) {
  if (!configData.value.memos) return;
  configData.value.memos[groupIdx].items.splice(itemIdx, 1);
  await invoke("save_hosts_config", { config: configData.value });
}

// --- 延迟测速 ---
async function testLatency(h: HostItem, mode: 'tcp' | 'icmp' = 'tcp') {
  h.latency_text = `${mode.toUpperCase()} 测速中...`;
  try {
    const portNum = Number(h.port) || 22;
    const res = await invoke<string>("probe_latency", {
      host: h.host.trim(),
      port: portNum,
      mode: mode,
    });
    h.latency_text = res;
    // 异步同步到配置文件中以便持久化上次测速状态
    invoke("save_hosts_config", { config: configData.value }).catch(() => {});
  } catch (e: any) {
    h.latency_text = `${mode.toUpperCase()} 失败`;
  }
}

// --- 终端剪贴板辅助 ---
function copySelection() {
  const cur = sessions.value.find(s => s.id === activeSessionId.value);
  if (cur?.termInstance) {
    const sel = cur.termInstance.getSelection();
    if (sel) navigator.clipboard.writeText(sel);
  }
  closeContextMenu();
}

async function pasteClipboard() {
  const cur = sessions.value.find(s => s.id === activeSessionId.value);
  if (cur && cur.alive) {
    const text = await navigator.clipboard.readText();
    if (text) invoke("write_ssh_session", { sessionId: cur.id, data: text });
  }
  closeContextMenu();
}

function clearCurrentTerminal() {
  const cur = sessions.value.find(s => s.id === activeSessionId.value);
  if (cur?.termInstance) cur.termInstance.clear();
  closeContextMenu();
}

function selectAllTerminal() {
  const cur = sessions.value.find(s => s.id === activeSessionId.value);
  if (cur?.termInstance) {
    cur.termInstance.selectAll();
    cur.termInstance.focus();
  }
  closeContextMenu();
}

// --- 本地与 WebDAV 备份业务逻辑 ---
let webdavSaveTimer: number | null = null;

function applyWebdavSettingsToConfig() {
  if (!configData.value.settings) configData.value.settings = {};
  configData.value.settings.webdav = {
    url: backupModal.value.webdav_url,
    user: backupModal.value.webdav_user,
    pwd: backupModal.value.webdav_pwd,
    path: backupModal.value.webdav_path,
  };
}

function scheduleWebdavSettingsSave() {
  applyWebdavSettingsToConfig();
  if (webdavSaveTimer !== null) {
    clearTimeout(webdavSaveTimer);
  }
  webdavSaveTimer = window.setTimeout(() => {
    webdavSaveTimer = null;
    void invoke("save_hosts_config", { config: configData.value }).catch((error) => {
      console.warn("[webdav] 保存连接配置失败:", error);
    });
  }, 500);
}

async function persistWebdavSettings() {
  applyWebdavSettingsToConfig();
  if (webdavSaveTimer !== null) {
    clearTimeout(webdavSaveTimer);
    webdavSaveTimer = null;
  }
  await invoke("save_hosts_config", { config: configData.value });
}

async function handleExportLocal() {
  const savePath = await saveFileDialog({
    defaultPath: "QShell_Backup.zip",
    title: "导出完整配置备份包",
    filters: [
      { name: "ZIP 压缩备份 (*.zip)", extensions: ["zip"] },
      { name: "JSON 配置 (*.json)", extensions: ["json"] }
    ]
  });
  if (!savePath) return;
  try {
    await persistWebdavSettings();
    const res = await invoke<{ success: boolean; message: string }>("export_local_backup", { targetPath: savePath });
    backupModal.value.status_msg = res.message;
  } catch (e: any) {
    backupModal.value.status_msg = `导出失败: ${e}`;
  }
}

async function handleImportLocal() {
  const openPath = await openFileDialog({
    multiple: false,
    title: "选择导入的备份文件",
    filters: [
      { name: "备份文件 (*.zip, *.json)", extensions: ["zip", "json"] },
      { name: "ZIP 压缩备份 (*.zip)", extensions: ["zip"] },
      { name: "JSON 配置 (*.json)", extensions: ["json"] }
    ]
  });
  if (!openPath) return;
  const pathStr = typeof openPath === "string" ? openPath : openPath[0];
  try {
    await persistWebdavSettings();
    const res = await invoke<{ success: boolean; message: string }>("import_local_backup", { sourcePath: pathStr });
    backupModal.value.status_msg = res.message;
    await loadConfig();
  } catch (e: any) {
    backupModal.value.status_msg = `导入失败: ${e}`;
  }
}

async function handleWebdavTest() {
  backupModal.value.is_busy = true;
  backupModal.value.status_msg = "正在测试连接 WebDAV...";
  try {
    await persistWebdavSettings();
    const res = await invoke<{ success: boolean; message: string }>("test_webdav_connection", {
      cfg: {
        url: backupModal.value.webdav_url,
        user: backupModal.value.webdav_user,
        pwd: backupModal.value.webdav_pwd || null,
        path: backupModal.value.webdav_path,
      }
    });
    backupModal.value.status_msg = res.message;
  } catch (e: any) {
    backupModal.value.status_msg = `连接失败: ${e}`;
  } finally {
    backupModal.value.is_busy = false;
  }
}

async function handleWebdavUpload() {
  backupModal.value.is_busy = true;
  backupModal.value.status_msg = "正在上传备份至 WebDAV 云端...";
  try {
    await persistWebdavSettings();
    const res = await invoke<{ success: boolean; message: string }>("webdav_upload_backup", {
      cfg: {
        url: backupModal.value.webdav_url,
        user: backupModal.value.webdav_user,
        pwd: backupModal.value.webdav_pwd || null,
        path: backupModal.value.webdav_path,
      }
    });
    backupModal.value.status_msg = res.message;
  } catch (e: any) {
    backupModal.value.status_msg = `上传失败: ${e}`;
  } finally {
    backupModal.value.is_busy = false;
  }
}

async function handleWebdavDownload() {
  backupModal.value.is_busy = true;
  backupModal.value.status_msg = "正在从云端拉取备份恢复...";
  try {
    await persistWebdavSettings();
    const res = await invoke<{ success: boolean; message: string }>("webdav_download_backup", {
      cfg: {
        url: backupModal.value.webdav_url,
        user: backupModal.value.webdav_user,
        pwd: backupModal.value.webdav_pwd || null,
        path: backupModal.value.webdav_path,
      }
    });
    backupModal.value.status_msg = res.message;
    await loadConfig();
  } catch (e: any) {
    backupModal.value.status_msg = `恢复失败: ${e}`;
  } finally {
    backupModal.value.is_busy = false;
  }
}

// 批量从设备树导入到主机管理
function openImportSelectModal() {
  const allTreeHosts: HostItem[] = [];
  configData.value.devices.forEach(g => {
    g.hosts.forEach(h => {
      if (!configData.value.managed_hosts.some(m => m.host === h.host && m.port === h.port)) {
        allTreeHosts.push(h);
      }
    });
  });
  importSelectModal.value = {
    show: true,
    candidates: allTreeHosts,
    selectedIndexes: allTreeHosts.map((_, i) => i),
  };
}

async function confirmImportSelected() {
  const { candidates, selectedIndexes } = importSelectModal.value;
  selectedIndexes.forEach(idx => {
    configData.value.managed_hosts.push(candidates[idx]);
  });
  await invoke("save_hosts_config", { config: configData.value });
  importSelectModal.value.show = false;
}

// --- 生命周期 ---
let unlistenTransfer: UnlistenFn | null = null;
let unlistenCloseRequested: UnlistenFn | null = null;

onMounted(async () => {
  await loadConfig();
  startTrafficAuditScheduler();
  window.addEventListener("focus", handleTrafficSchedulerWake);
  document.addEventListener("visibilitychange", handleTrafficSchedulerWake);
  window.addEventListener("click", handleGlobalClick);
  window.addEventListener("resize", () => {
    sessions.value.forEach(s => s.fitInstance?.fit());
  });

  // 监听 SFTP 文件传输进度广播 (仅在 Tauri 运行环境下监听)
  if (isTauri) {
    unlistenTransfer = await listen<TransferTask>("sftp-transfer-progress", (event) => {
      const payload = event.payload;
      const existing = activeTransfers.value.find(t => t.task_id === payload.task_id);
      if (existing) {
        Object.assign(existing, payload);
      } else {
        activeTransfers.value.push(payload);
      }
    });
  }

  // 监听 Tauri 原生拖拽文件到窗口释放事件
  if (appWindow) {
    await appWindow.onDragDropEvent((event) => {
      if (event.payload.type === "over") {
        if (rightPanelTab.value === "sftp" && activeSessionId.value) {
          isSftpDragOver.value = true;
        }
      } else if (event.payload.type === "drop") {
        isSftpDragOver.value = false;
        if (rightPanelTab.value === "sftp" && activeSessionId.value && event.payload.paths) {
          event.payload.paths.forEach((p: string) => {
            uploadLocalPath(p);
          });
        }
      } else {
        isSftpDragOver.value = false;
      }
    });

    // 关闭按钮行为：开启“隐藏到托盘”时阻止真正退出，只隐藏窗口
    unlistenCloseRequested = await appWindow.onCloseRequested(async (event) => {
      event.preventDefault();
      if (terminalSettings.value.minimize_to_tray) {
        await appWindow?.hide();
        try {
          await invoke("notify_tray", {
            body: "QShell 已隐藏到系统托盘，点击托盘图标可重新打开。",
          });
        } catch (notifyError) {
          console.warn("[tray] 发送系统通知失败:", notifyError);
        }
      } else {
        // 让 WebView2 正常销毁窗口，Rust 侧在窗口销毁后再退出进程
        await appWindow?.destroy();
      }
    });
  }

  // 读取上次窗口状态
  try {
    const savedState = localStorage.getItem("qshell_window_state");
    if (savedState) {
      const parsed = JSON.parse(savedState);
      if (parsed.isRightPanelOpen !== undefined) isRightPanelOpen.value = parsed.isRightPanelOpen;
      if (parsed.currentView) currentView.value = parsed.currentView;
    }
  } catch (e) {}
});

onUnmounted(() => {
  window.removeEventListener("click", handleGlobalClick);
  window.removeEventListener("focus", handleTrafficSchedulerWake);
  document.removeEventListener("visibilitychange", handleTrafficSchedulerWake);
  if (unlistenCloseRequested) unlistenCloseRequested();
  stopTrafficAuditScheduler();
  if (unlistenTransfer) unlistenTransfer();
  sessions.value.forEach(s => s.termInstance?.dispose());
  try {
    localStorage.setItem("qshell_window_state", JSON.stringify({
      isRightPanelOpen: isRightPanelOpen.value,
      currentView: currentView.value,
    }));
  } catch (e) {}
});
</script>

<template>
  <div class="app-root" @contextmenu.prevent>
    <!-- 顶部标题栏 (1:1 像素级复刻原版设计) -->
    <header class="title-bar" @mousedown="startDragging">
      <div class="brand">
        <span class="logo-title">QShell</span>
        <div class="tag-version-wrapper">
          <div class="version-badge">
            <span class="badge-dot">●</span>
            <span class="badge-text">v0.99.6</span>
          </div>
        </div>
      </div>

      <!-- 右侧控制区：主机管理药丸按钮 + 平铺矢量图标操作栏 + 窗口控制 -->
      <div class="top-right-group">
        <button 
          :class="['btn-mgmt-pill', currentView === 'mgmt' ? 'active' : '']"
          @click="currentView = currentView === 'workspace' ? 'mgmt' : 'workspace'"
        >
          {{ currentView === 'mgmt' ? '返回主页' : '主机管理' }}
        </button>

        <button class="top-icon-btn" :title="themeMode === 'dark' ? '切换为浅色模式' : '切换为深色模式'" @click="toggleTheme($event)">
          <Icons :name="themeMode === 'dark' ? 'moon' : 'sun'" size="24" />
        </button>
        
        <button 
          :class="['top-icon-btn', 'btn-toggle-alert', hostAlertList.length > 0 ? 'has-alert' : '', showAlertPopover ? 'active' : '']"
          @click="toggleAlertPopover($event)"
          title="通知 / 到期与流量预警"
        >
          <Icons name="bell" size="24" />
          <span v-if="hostAlertList.length > 0" class="alert-dot"></span>
        </button>

        <button 
          :class="['top-icon-btn', 'btn-toggle-transfer', activeTransfers.length > 0 ? 'active' : '', showTransferMonitor ? 'active' : '']"
          @click="toggleTransferMonitor($event)"
          title="SFTP 文件传输任务"
        >
          <Icons name="arrows" size="24" />
        </button>

        <button 
          class="top-icon-btn"
          @click="showTerminalSettingsModal = true"
          title="首选项与终端设置"
        >
          <Icons name="settings" size="24" />
        </button>

        <button 
          class="top-icon-btn"
          @click="isRightPanelOpen = !isRightPanelOpen"
          :title="isRightPanelOpen ? '折叠右侧栏' : '展开右侧栏'"
        >
          <Icons name="panel" size="24" />
        </button>

        <!-- 窗口原生控制按钮 (34px × 30px，1.6px 饱满线宽) -->
        <div class="window-controls">
          <button class="win-btn" title="最小化" @click.stop="minimizeWindow">
            <Icons name="win-min" size="14" />
          </button>
          <button class="win-btn" title="最大化" @click.stop="toggleMaximizeWindow">
            <Icons name="win-max" size="14" />
          </button>
          <button class="win-btn close" title="关闭" @click.stop="closeWindow">
            <Icons name="win-close" size="14" />
          </button>
        </div>
      </div>
    </header>

    <!-- 主工作区：经典三栏架构 (左系统监控与设备树 / 中终端多标签 / 右SFTP与备忘录) -->
    <div class="main-body">
      <!-- 视图 1：工作区 (使用不可见定位层隐藏，彻底避免 display:none 导致 xterm 几何尺寸归零与字符吞并) -->
      <div :class="['workspace-layout', currentView !== 'workspace' ? 'view-hidden' : '']">
        
        <!-- 【左栏】：系统监控卡片 + 设备列表卡片 (独立圆角卡片，支持拖拽调节宽度) -->
        <aside class="left-panel" :style="{ width: leftPanelWidth + 'px', minWidth: leftPanelWidth + 'px' }">
          <!-- 上卡片：系统监控卡片 (自适应自然内容高度，严丝合缝无死板空隙) -->
          <div class="card-container monitor-card" :style="{ minHeight: leftMonitorCardHeight + 'px' }">
            <div class="card-header-title">系统监控</div>
            
            <div class="gauge-group">
              <div class="gauge-item">
                <div class="gauge-label">
                  <span class="g-name">CPU 使用率</span>
                  <span class="g-val">{{ monitorStats.cpu }}%</span>
                </div>
                <div class="gauge-track">
                  <div class="gauge-fill cpu" :style="{ width: monitorStats.cpu + '%' }"></div>
                </div>
              </div>

              <div class="gauge-item">
                <div class="gauge-label">
                  <span class="g-name">内存占用</span>
                  <span class="g-val">{{ monitorStats.mem }}%</span>
                </div>
                <div class="gauge-track">
                  <div class="gauge-fill mem" :style="{ width: monitorStats.mem + '%' }"></div>
                </div>
              </div>

              <div class="gauge-item">
                <div class="gauge-label">
                  <span class="g-name">硬盘总占用</span>
                  <span class="g-val">{{ monitorStats.disk }}%</span>
                </div>
                <div class="gauge-track">
                  <div class="gauge-fill disk" :style="{ width: monitorStats.disk + '%' }"></div>
                </div>
              </div>
            </div>

            <!-- 网络接口状态标签 (仿版本号 Tag 质感，圆角矩形，醒目翡翠绿/科技蓝微渐变微光) -->
            <div class="net-if-status-row">
              <div :class="['net-if-badge', monitorStats.net_if ? 'connected' : 'idle']">
                <span class="if-dot">●</span>
                <span class="if-text">{{ monitorStats.net_if ? `已连接: ${monitorStats.net_if}` : (sessions.length > 0 ? '检测网卡中...' : '网络未连接') }}</span>
              </div>
            </div>

            <!-- 网络发送/接收点阵对称卡片 (SVG 矢量绝对等宽灯阵 + 单珠正向流光) -->
            <div class="net-traffic-grid">
              <div class="net-sub-card">
                <div class="net-header">
                  <span class="net-arrow up">↑</span>
                  <div class="net-text">
                    <span class="dir">发送</span>
                    <span class="spd">{{ monitorStats.net_up }}</span>
                  </div>
                </div>
                <div class="led-svg-wrap">
                  <svg viewBox="0 0 150 54" class="led-matrix-svg" preserveAspectRatio="none">
                    <template v-for="row in 6" :key="'up-row-' + row">
                      <rect
                        v-for="col in 15"
                        :key="'up-rect-' + ((row - 1) * 15 + col)"
                        :x="(col - 1) * 10 + 1"
                        :y="(row - 1) * 9 + 1.5"
                        width="8"
                        height="6"
                        rx="1.5"
                        :class="[
                          'svg-led',
                          ((row - 1) * 15 + col) <= activeUpLedCount ? 'active-up' : '',
                          getRunnerLevel((row - 1) * 15 + col, upRunnerIdx, activeUpLedCount) === 0 ? 'runner-head-up' : '',
                          getRunnerLevel((row - 1) * 15 + col, upRunnerIdx, activeUpLedCount) === 1 ? 'runner-tail-1-up' : '',
                          getRunnerLevel((row - 1) * 15 + col, upRunnerIdx, activeUpLedCount) === 2 ? 'runner-tail-2-up' : '',
                          getRunnerLevel((row - 1) * 15 + col, upRunnerIdx, activeUpLedCount) === 3 ? 'runner-tail-3-up' : ''
                        ]"
                      />
                    </template>
                  </svg>
                </div>
              </div>

              <div class="net-sub-card">
                <div class="net-header">
                  <span class="net-arrow down">↓</span>
                  <div class="net-text">
                    <span class="dir">接收</span>
                    <span class="spd">{{ monitorStats.net_down }}</span>
                  </div>
                </div>
                <div class="led-svg-wrap">
                  <svg viewBox="0 0 150 54" class="led-matrix-svg" preserveAspectRatio="none">
                    <template v-for="row in 6" :key="'down-row-' + row">
                      <rect
                        v-for="col in 15"
                        :key="'down-rect-' + ((row - 1) * 15 + col)"
                        :x="(col - 1) * 10 + 1"
                        :y="(row - 1) * 9 + 1.5"
                        width="8"
                        height="6"
                        rx="1.5"
                        :class="[
                          'svg-led',
                          ((row - 1) * 15 + col) <= activeDownLedCount ? 'active-down' : '',
                          getRunnerLevel((row - 1) * 15 + col, downRunnerIdx, activeDownLedCount) === 0 ? 'runner-head-down' : '',
                          getRunnerLevel((row - 1) * 15 + col, downRunnerIdx, activeDownLedCount) === 1 ? 'runner-tail-1-down' : '',
                          getRunnerLevel((row - 1) * 15 + col, downRunnerIdx, activeDownLedCount) === 2 ? 'runner-tail-2-down' : '',
                          getRunnerLevel((row - 1) * 15 + col, downRunnerIdx, activeDownLedCount) === 3 ? 'runner-tail-3-down' : ''
                        ]"
                      />
                    </template>
                  </svg>
                </div>
              </div>
            </div>
          </div>

          <!-- 左栏上下垂直调节手柄 (1:1 对标 ssh8.py self.left_splitter) -->
          <div class="splitter-handle-v" @mousedown="onLeftVerticalSplitterDown"></div>

          <!-- 下卡片：设备列表独立卡片 -->
          <div class="card-container device-list-card" @contextmenu.prevent="openContextMenu($event, 'group')">
            <div class="card-header-title">设备列表</div>

            <!-- 实时过滤搜索条 (高清晰矢量镜 + 居中防裁切) -->
            <div class="search-box-row">
              <span class="search-icon-slot">
                <Icons name="search" size="14" />
              </span>
              <input 
                v-model="searchKeyword" 
                class="device-search-input" 
                placeholder="搜索主机名/IP..." 
              />
              <span v-if="searchKeyword" class="search-clear" @click="searchKeyword = ''">✕</span>
            </div>
            
            <div class="tree-scroll">
              <div 
                v-for="(g, gIdx) in configData.devices" 
                :key="g.group" 
                class="group-wrapper"
              >
                <!-- 分组标题行：可拖拽调整分组顺序，也可以接收从其他分组拖过来的主机 -->
                <div 
                  class="group-header" 
                  draggable="true"
                  :class="{
                    'drag-target-before': dragState.type === 'device_group' && dragState.targetGroupIdx === gIdx && dragState.targetPosition === 'before',
                    'drag-target-after': dragState.type === 'device_group' && dragState.targetGroupIdx === gIdx && dragState.targetPosition === 'after',
                    'drag-target-inside': dragState.type === 'host' && dragState.targetGroupIdx === gIdx && dragState.targetPosition === 'inside',
                    'is-dragging': dragState.type === 'device_group' && dragState.sourceGroupIdx === gIdx
                  }"
                  @dragstart="onDeviceGroupDragStart(gIdx, $event)"
                  @dragover="onDeviceGroupDragOver(gIdx, $event)"
                  @drop="onDeviceGroupDrop(gIdx, $event)"
                  @click="g.collapsed = !g.collapsed" 
                  @contextmenu.prevent="openContextMenu($event, 'group', undefined, g)"
                >
                  <Icons name="chevron" :expanded="!g.collapsed" size="12" class="group-chevron" />
                  <Icons name="folder" size="20" class="group-folder-icon" />
                  <span class="group-name">{{ g.group }}</span>
                  <span class="group-badge">({{ g.hosts?.length || 0 }})</span>
                </div>

                <!-- 分组内容列表：支持主机条目排序与跨分组插入 -->
                <div 
                  v-show="!g.collapsed" 
                  class="group-body"
                  @dragover.prevent="dragState.type === 'host' && (dragState.targetGroupIdx = gIdx, dragState.targetItemIdx = null, dragState.targetPosition = 'inside')"
                  @drop="onHostDrop(gIdx, null, $event)"
                >
                  <div 
                    v-for="(h, hIdx) in g.hosts" 
                    v-show="!searchKeyword || h.name.toLowerCase().includes(searchKeyword.toLowerCase()) || h.host.includes(searchKeyword)"
                    :key="h.host + h.port"
                    class="host-capsule-item"
                    :class="{
                      'drag-target-before': dragState.type === 'host' && dragState.targetGroupIdx === gIdx && dragState.targetItemIdx === hIdx && dragState.targetPosition === 'before',
                      'drag-target-after': dragState.type === 'host' && dragState.targetGroupIdx === gIdx && dragState.targetItemIdx === hIdx && dragState.targetPosition === 'after',
                      'is-dragging': dragState.type === 'host' && dragState.sourceGroupIdx === gIdx && dragState.sourceItemIdx === hIdx
                    }"
                    draggable="true"
                    @dragstart="onHostDragStart(gIdx, hIdx, $event)"
                    @dragover.stop="onHostDragOver(gIdx, hIdx, $event)"
                    @drop.stop="onHostDrop(gIdx, hIdx, $event)"
                    @dblclick="openSession(h)"
                    @contextmenu.prevent="openContextMenu($event, 'host', h, g)"
                  >
                    <!-- 左侧彩色胶囊指示条 -->
                    <span class="capsule-pillar"></span>
                    <Icons name="host" size="16" class="capsule-icon" />
                    <span class="capsule-title">{{ h.name }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </aside>

        <!-- 左侧拖拽分割调节手柄 -->
        <div class="splitter-handle" @mousedown="onLeftSplitterDown"></div>

        <!-- 【中栏】：独立圆角大卡片 (包含多标签与终端渲染区) -->
        <main class="center-terminal-card">
          <div class="terminal-tab-bar" v-if="sessions.length > 0">
            <div class="tab-list">
              <div 
                v-for="(tab, tIdx) in sessions" 
                :key="tab.id"
                :class="[
                  'term-tab', 
                  activeSessionId === tab.id ? 'active' : '', 
                  tab.is_locked ? 'locked' : '',
                  draggingTabIndex === tIdx ? 'is-tab-dragging' : '',
                  dragOverTabIndex === tIdx && draggingTabIndex !== tIdx ? 'is-tab-drag-over' : ''
                ]"
                draggable="true"
                @dragstart="handleTabDragStart(tIdx, $event)"
                @dragover="handleTabDragOver(tIdx, $event)"
                @dragleave="handleTabDragLeave(tIdx)"
                @drop="handleTabDrop(tIdx, $event)"
                @dragend="handleTabDragEnd"
                @click="switchSession(tab.id)"
                @contextmenu.prevent="openContextMenu($event, 'tab', undefined, undefined, undefined, undefined, undefined, undefined, tab)"
              >
                <span :class="['tab-dot', tab.alive ? 'online' : 'offline']"></span>
                <span class="tab-title">{{ tab.name }}</span>
                <!-- 1:1 对标 ssh8.py CustomTabCloseButton: 锁定显示锁，未锁定显示关闭叉号 (右键可切换锁定) -->
                <span 
                  :class="['custom-tab-btn', tab.is_locked ? 'btn-lock' : 'btn-close']"
                  :title="tab.is_locked ? '此标签已锁定保护 (双击或右键解锁)' : '关闭标签页'"
                  @click.stop="tab.is_locked ? toggleTabLock(tab) : closeSession(tab)"
                >
                  <Icons v-if="tab.is_locked" name="lock" size="15" />
                  <span v-else class="btn-close-x">✕</span>
                </span>
              </div>
            </div>

            <div class="tab-actions">
              <div 
                v-if="activeSession"
                :class="['terminal-latency-badge', latencyStatusClass]"
                :title="latencyDisplayText"
              >
                <span class="badge-dot"></span>
                <span class="badge-text">{{ latencyDisplayText }}</span>
              </div>
              <button 
                v-if="activeSession"
                class="btn-danger-disconnect" 
                @click="closeSession(activeSession)"
              >
                断开连接
              </button>
            </div>
          </div>

          <div 
            class="terminal-viewport"
            @contextmenu.prevent="openContextMenu($event, 'terminal')"
          >
            <div v-if="sessions.length === 0" class="empty-state">
              <div class="empty-icon-wrap">
                <svg class="empty-desktop-icon" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <!-- 显示器外框 -->
                  <rect x="6" y="8" width="52" height="36" rx="5" class="svg-stroke" stroke-width="2.5" />
                  <!-- 屏幕内显示区 -->
                  <rect x="10" y="12" width="44" height="28" rx="2.5" class="svg-screen" />
                  <!-- 终端指示符 >_ -->
                  <path d="M16 21L21 26L16 31" class="svg-symbol" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                  <line x1="25" y1="31" x2="33" y2="31" class="svg-symbol" stroke-width="2" stroke-linecap="round" />
                  <!-- 支架立柱 -->
                  <path d="M27 44V51C27 51.5 27.5 52 28 52H36C36.5 52 37 51.5 37 51V44" class="svg-stroke" stroke-width="2.5" stroke-linejoin="round" />
                  <!-- 底座 -->
                  <path d="M19 56H45" class="svg-stroke" stroke-width="2.5" stroke-linecap="round" />
                </svg>
              </div>
              <div class="empty-title">终端空闲</div>
              <div class="empty-hint">双击左侧设备列表以连接</div>
            </div>

            <div 
              v-for="tab in sessions" 
              :key="tab.id"
              :id="'term-' + tab.id"
              :class="['terminal-mount-box', { 'is-active': activeSessionId === tab.id }]"
            ></div>
          </div>
        </main>

        <!-- 右侧拖拽分割调节手柄 -->
        <div v-show="isRightPanelOpen" class="splitter-handle" @mousedown="onRightSplitterDown"></div>

        <!-- 【右栏】：独立圆角大卡片 (SFTP与备忘录，支持拖拽调节宽度) -->
        <aside v-show="isRightPanelOpen" class="card-container right-panel-card" :style="{ width: rightPanelWidth + 'px', minWidth: rightPanelWidth + 'px' }">
          <div class="right-card-header">
            <span class="right-card-title">{{ rightPanelTab === 'memo' ? '命令备忘录' : 'SFTP 远程文件' }}</span>
            <button 
              class="btn-switch-white-pill"
              @click="switchRightPanelTab(rightPanelTab === 'memo' ? 'sftp' : 'memo')"
            >
              {{ rightPanelTab === 'memo' ? 'SFTP 传输' : '关闭' }}
            </button>
          </div>

          <!-- SFTP 视图 (1:1 复刻原版 ssh8.py 设计) -->
          <div v-if="rightPanelTab === 'sftp'" class="sftp-container" @contextmenu.prevent="openContextMenu($event, 'sftp_bg')">
            <!-- 顶部快捷路径导航栏 -->
            <div class="sftp-nav-bar">
              <button class="btn-sftp-action" @click="sftpNavigateParent" title="返回上一级">上一级</button>
              <input class="sftp-path-box" v-model="currentSftpPath" @keyup.enter="fetchSftpFiles(currentSftpPath)" />
              <button class="btn-sftp-action" @click="fetchSftpFiles(currentSftpPath)" title="跳转/刷新">跳转</button>
            </div>

            <!-- 表头：名称 | 大小 | 权限 (支持拖拽调节宽度) -->
            <div class="sftp-table-header">
              <div class="col-name" :style="{ width: sftpColWidths.name + 'px' }">
                <span>名称</span>
                <span class="col-resizer" @mousedown="onSftpColResizeDown('name', $event)" title="按住拖拽调节列宽">
                  <span class="resizer-dots"></span>
                </span>
              </div>
              <div class="col-size" :style="{ width: sftpColWidths.size + 'px' }">
                <span>大小</span>
                <span class="col-resizer" @mousedown="onSftpColResizeDown('size', $event)" title="按住拖拽调节列宽">
                  <span class="resizer-dots"></span>
                </span>
              </div>
              <div class="col-perm">
                <span>权限</span>
              </div>
            </div>
            
            <div :class="['sftp-file-list', isSftpDragOver ? 'drag-over' : '']" :style="{ opacity: isSftpLoading ? 0.6 : 1, transition: 'opacity 0.2s' }">
              <div v-if="isSftpDragOver" class="sftp-drop-overlay">
                释放文件立即上传到当前目录
              </div>
              <div v-if="isSftpLoading && sftpFiles.length === 0" class="sftp-loading">读取目录中...</div>
              <div v-else-if="sftpErrorMsg" class="sftp-empty" style="color: #EF4444;">
                {{ sftpErrorMsg }}
              </div>
              <div v-else-if="sftpFiles.length === 0" class="sftp-empty">
                {{ activeSessionId ? '目录为空或无权限' : '请先在左侧双击连接主机' }}
              </div>
              <div 
                v-for="f in sftpFiles" 
                :key="f.name"
                :class="['file-item', f.is_dir ? 'dir' : 'file', selectedSftpFile?.name === f.name ? 'selected' : '']"
                @click="selectedSftpFile = f"
                @dblclick="sftpCd(f)"
                @contextmenu.prevent="openContextMenu($event, 'sftp_item', undefined, undefined, f)"
              >
                <div class="f-info" :style="{ width: sftpColWidths.name + 'px' }">
                  <Icons :name="f.is_dir ? 'folder' : 'file'" size="20" class="flex-shrink-0" />
                  <span class="f-name" :title="f.name">{{ f.name }}</span>
                </div>
                <div class="f-meta">
                  <span class="f-size" :style="{ width: sftpColWidths.size + 'px' }">{{ f.size }}</span>
                  <span class="f-perm">{{ f.mode_str }}</span>
                </div>
              </div>
            </div>

            <!-- 底部常驻双按钮: 上传文件 与 下载选中 (矢量图标替换) -->
            <div class="sftp-bottom-bar">
              <button class="btn-sftp-footer" @click="sftpTriggerUpload">
                <Icons name="arrow-up" size="14" />
                <span>上传文件</span>
              </button>
              <button class="btn-sftp-footer" :disabled="!selectedSftpFile || selectedSftpFile.is_dir" @click="selectedSftpFile && sftpTriggerDownload(selectedSftpFile)">
                <Icons name="arrow-down" size="14" />
                <span>下载选中</span>
              </button>
            </div>
          </div>

          <!-- 备忘录视图 (复刻原版圆角胶囊条与底部浅蓝添加按钮) -->
          <div v-else class="memo-container" @contextmenu.prevent="openContextMenu($event, 'memo_bg')">
            <div 
              v-for="(g, gIdx) in configData.memos" 
              :key="g.group" 
              class="memo-group-section"
            >
              <!-- 备忘录分组头：可拖拽调整分组顺序，也可以接收从其他分组拖过来的备忘录条目 -->
              <div 
                class="memo-group-header" 
                draggable="true"
                :class="{
                  'drag-target-before': dragState.type === 'memo_group' && dragState.targetGroupIdx === gIdx && dragState.targetPosition === 'before',
                  'drag-target-after': dragState.type === 'memo_group' && dragState.targetGroupIdx === gIdx && dragState.targetPosition === 'after',
                  'drag-target-inside': dragState.type === 'memo_item' && dragState.targetGroupIdx === gIdx && dragState.targetPosition === 'inside',
                  'is-dragging': dragState.type === 'memo_group' && dragState.sourceGroupIdx === gIdx
                }"
                @dragstart="onMemoGroupDragStart(gIdx, $event)"
                @dragover="onMemoGroupDragOver(gIdx, $event)"
                @drop="onMemoGroupDrop(gIdx, $event)"
                @click="g.collapsed = !g.collapsed"
                @contextmenu.prevent="openContextMenu($event, 'memo_group', undefined, undefined, undefined, gIdx)"
              >
                <Icons name="chevron" :expanded="!g.collapsed" size="12" class="group-chevron" />
                <Icons name="folder" size="20" class="memo-folder-icon" />
                <span class="memo-group-title">{{ g.group }}</span>
              </div>

              <!-- 备忘录列表：支持条目拖拽排序与跨组插入 -->
              <div 
                v-show="!g.collapsed"
                class="memo-list"
                @dragover.prevent="dragState.type === 'memo_item' && (dragState.targetGroupIdx = gIdx, dragState.targetItemIdx = null, dragState.targetPosition = 'inside')"
                @drop="onMemoDrop(gIdx, null, $event)"
              >
                <div 
                  v-for="(item, iIdx) in g.items" 
                  :key="item.name + item.cmd" 
                  class="memo-capsule-item"
                  :class="{
                    'drag-target-before': dragState.type === 'memo_item' && dragState.targetGroupIdx === gIdx && dragState.targetItemIdx === iIdx && dragState.targetPosition === 'before',
                    'drag-target-after': dragState.type === 'memo_item' && dragState.targetGroupIdx === gIdx && dragState.targetItemIdx === iIdx && dragState.targetPosition === 'after',
                    'is-dragging': dragState.type === 'memo_item' && dragState.sourceGroupIdx === gIdx && dragState.sourceItemIdx === iIdx
                  }"
                  draggable="true"
                  @dragstart="onMemoDragStart(gIdx, iIdx, $event)"
                  @dragover.stop="onMemoDragOver(gIdx, iIdx, $event)"
                  @drop.stop="onMemoDrop(gIdx, iIdx, $event)"
                  @contextmenu.prevent="openContextMenu($event, 'memo_item', undefined, undefined, undefined, gIdx, iIdx, item)"
                  :title="'右键菜单操作: ' + item.cmd"
                >
                  <span class="memo-pillar"></span>
                  <Icons name="doc" size="14" class="memo-icon" />
                  <span class="memo-name">{{ item.name }}</span>
                  <span class="memo-del-icon" @click.stop="deleteMemo(gIdx, iIdx)" title="删除">✕</span>
                </div>
              </div>
            </div>

            <!-- 底部吸底浅蓝大胶囊按钮 -->
            <div class="memo-bottom-action">
              <button class="btn-bottom-add-pill" @click="openAddMemoModal(0)">
                <Icons name="plus" size="14" />
                <span>添加命令项</span>
              </button>
            </div>
          </div>
        </aside>

      </div>

      <!-- 视图 2：主机管理大盘视图 (120帧流光条 + 流量统计/校准交互) -->
      <div v-show="currentView === 'mgmt'" class="mgmt-view">
        <div class="mgmt-header">
          <div>
            <h2 class="mgmt-title">综合主机管理</h2>
            <span class="mgmt-sub">支持实时流量审计、结算日重置与莫比乌斯微光轨道展示</span>
          </div>
          <div class="mgmt-actions-row">
            <!-- 每行卡片数选择器 (1-3 列) -->
            <div class="mgmt-cols-picker" title="选择每行显示的卡片列数 (1 - 3 列)">
              <span class="cols-label">排列:</span>
              <button 
                v-for="col in [1, 2, 3]" 
                :key="col"
                :class="['btn-col-choice', mgmtGridColumns === col ? 'active' : '']"
                @click="setMgmtGridColumns(col)"
              >
                {{ col }}列
              </button>
            </div>

            <button class="btn-sec-act" @click="openImportSelectModal">从设备列表导入</button>
            <button class="btn-add-host" @click="openAddHostModal('all')">
              <Icons name="plus" size="14" />
              <span>添加新主机</span>
            </button>
          </div>
        </div>

        <div class="cards-grid" :class="'cols-' + mgmtGridColumns">
          <div 
            v-for="(h, idx) in configData.managed_hosts.filter(item => !searchKeyword || item.name.toLowerCase().includes(searchKeyword.toLowerCase()) || item.host.includes(searchKeyword))" 
            :key="h.host + h.port" 
            :id="`host-card-${h.host}-${h.port}`"
            :class="[
              'host-card', 
              highlightedHostKey === `${h.host}:${h.port}` ? 'breathing-highlight' : '',
              draggingHostIndex === idx ? 'is-dragging' : '',
              dragOverHostIndex === idx && draggingHostIndex !== idx ? 'is-drag-over' : ''
            ]"
            draggable="true"
            @dragstart="handleCardDragStart(idx, $event)"
            @dragover="handleCardDragOver(idx, $event)"
            @dragleave="handleCardDragLeave(idx)"
            @drop="handleCardDrop(idx, $event)"
            @dragend="handleCardDragEnd"
          >
            <div class="card-pillar"></div>
            <div class="card-body">
              <div class="card-row1">
                <span class="card-name">{{ h.name }}</span>
                <span 
                  class="card-latency" 
                  :class="{
                    'is-tcp': (h.latency_text || '').startsWith('TCP'),
                    'is-icmp': (h.latency_text || '').startsWith('ICMP'),
                    'is-err': (h.latency_text || '').includes('超时') || (h.latency_text || '').includes('拒绝') || (h.latency_text || '').includes('失败')
                  }"
                >
                  {{ h.latency_text || '待测速' }}
                </span>
              </div>
              <div class="card-addr">{{ h.host }}:{{ h.port }}</div>

              <div class="card-meta">
                <span>备注: {{ h.details?.memo || '无' }}</span>
                <span>到期: {{ h.details?.expire_date || '无限' }}</span>
                <span>结算日: 每月 {{ h.details?.reset_day || 1 }} 日 {{ String(h.details?.reset_hour || 0).padStart(2, '0') }}:{{ String(h.details?.reset_min || 0).padStart(2, '0') }}</span>
                <span>价格: {{ h.details?.price || '0.00' }} {{ h.details?.currency || 'CNY' }}</span>
              </div>

              <!-- 流量展示行与右上角独立的"统计详情"交互标签 -->
              <div class="traffic-section">
                <div class="traffic-label">
                  <span class="traffic-text-main">流量: {{ h.details?.traffic_used || '0' }}{{ h.details?.traffic_used_unit || 'GB' }} / {{ h.details?.traffic_total_infinite ? '无限 (∞)' : `${h.details?.traffic_total || '0'}${h.details?.traffic_total_unit || 'GB'}` }}</span>
                  <button 
                    type="button" 
                    class="traffic-audit-btn" 
                    @click.stop="openTrafficStatsModal(h)" 
                    title="点击打开流量详细统计与校准窗口"
                  >
                    <span class="audit-icon">⚙</span>
                    <span class="audit-text">统计详情</span>
                  </button>
                </div>

                <!-- 无限流量：优雅呼吸流光条 -->
                <div v-if="h.details?.traffic_total_infinite" class="unified-traffic-bar infinite">
                  <div class="infinite-flow"></div>
                  <div class="infinity-badge">∞ 无限流量</div>
                </div>
                <!-- 有限流量：真实百分比流光进度条 -->
                <div v-else class="unified-traffic-bar">
                  <div 
                    class="unified-traffic-fill" 
                    :class="{ 'warn': getTrafficProgress(h) >= 80, 'danger': getTrafficProgress(h) >= 95 }"
                    :style="{ width: getTrafficProgress(h) + '%' }"
                  ></div>
                  <span class="unified-traffic-pct">{{ getTrafficProgress(h).toFixed(1) }}%</span>
                </div>
              </div>

              <div class="card-actions">
                <div class="card-actions-left">
                  <button class="btn-card-act btn-primary btn-ssh" @click="openSession(h)">打开 SSH</button>
                  <button class="btn-card-act btn-tcp" @click="testLatency(h, 'tcp')">TCP</button>
                  <button class="btn-card-act btn-icmp" @click="testLatency(h, 'icmp')">ICMP</button>
                  <button class="btn-card-act btn-reset" @click="resetTrafficCounter(h)" title="重置已用流量为 0">清零</button>
                  <button class="btn-card-act btn-edit" @click="openEditHostModal(h, 'asset')">编辑</button>
                </div>
                <div class="card-actions-right">
                  <button class="btn-card-act btn-danger btn-del" @click="confirmDeleteHost(h)" title="删除此主机">删除</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 告警与事件提醒下拉卡片 (NotificationMonitorPopover 1:1 对标 ssh8.py) -->
    <div 
      v-if="showAlertPopover" 
      class="transfer-monitor-popover alert-popover" 
      :style="{ '--arrow-right': (alertPopoverTargetRight - 8) + 'px' }"
    >
      <div class="transfer-popover-header alert-head">
        <span class="alert-head-title">告警与事件提醒</span>
        <div class="alert-head-actions">
          <button 
            v-if="hostAlertList.length > 0" 
            class="btn-popover-ignore" 
            @click="clearAllAlerts"
          >
            全部忽略
          </button>
          <span class="popover-close" @click="showAlertPopover = false">✕</span>
        </div>
      </div>
      <div class="transfer-task-list alert-scroll-list">
        <div v-if="hostAlertList.length === 0" class="alert-empty-state">
          当前所有主机状态良好，无待处理告警
        </div>
        <div 
          v-else 
          v-for="(al, idx) in hostAlertList" 
          :key="idx" 
          class="alert-card-item"
          @click="handleAlertClick(al)"
          title="点击跳转至该主机详情"
        >
          <div class="alert-item-dot-col">
            <span :class="['alert-indicator-dot', al.type]"></span>
          </div>
          <div class="alert-item-content">
            <div class="alert-item-msg">
              <span class="alert-item-hname">[{{ al.hostName }}]</span>
              {{ al.msg }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 悬浮传输监视器 (SFTPTransferMonitorPopover) -->
    <div 
      v-if="showTransferMonitor" 
      class="transfer-monitor-popover" 
      :style="{ '--arrow-right': (transferPopoverTargetRight - 8) + 'px' }"
    >
      <div class="transfer-popover-header">
        <span>SFTP 传输监视队列 ({{ activeTransfers.length }})</span>
        <div class="popover-header-actions">
          <button 
            class="btn-popover-clear" 
            :disabled="activeTransfers.length === 0"
            @click="clearTransferHistory"
            title="清除传输记录"
          >
            清除历史
          </button>
          <span class="popover-close" @click="showTransferMonitor = false">✕</span>
        </div>
      </div>
      <div class="transfer-task-list">
        <div v-if="activeTransfers.length === 0" class="no-task">暂无传输任务</div>
        <div v-for="t in activeTransfers" :key="t.task_id" class="transfer-task-item">
          <div class="task-info">
            <span class="task-badge" :class="t.is_upload ? 'up' : 'down'">{{ t.is_upload ? '↑ 上传' : '↓ 下载' }}</span>
            <span class="task-name">{{ t.filename }}</span>
            <span class="task-speed">{{ formatSpeed(t.speed_bps) }}</span>
          </div>
          <div class="task-progress-bar">
            <div 
              class="task-progress-fill" 
              :style="{ width: Math.min(100, (t.transferred / (t.total || 1)) * 100) + '%' }"
            ></div>
          </div>
          <div class="task-status-row">
            <span>{{ Math.round((t.transferred / (t.total || 1)) * 100) }}%</span>
            <span :class="['status-tag', t.status]">{{ t.status === 'completed' ? '完成' : t.status === 'failed' ? '失败' : '传输中' }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 全局 Material You 拟态原生右键菜单 -->
    <div 
      v-if="contextMenu.show" 
      class="context-menu"
      :style="{ left: contextMenu.x + 'px', top: contextMenu.y + 'px' }"
    >
      <!-- 设备树主机右键选项 (轻量纯净：连接、编辑、复制IP、删除) -->
      <template v-if="contextMenu.targetType === 'host'">
        <div class="menu-item" @click="openSession(contextMenu.targetHost!)">连接此主机</div>
        <div class="menu-item" @click="openEditHostModal(contextMenu.targetHost!, 'connection')">编辑主机配置</div>
        <div class="menu-item" @click="copyText(contextMenu.targetHost!.host)">复制主机 IP 地址</div>
        <div class="menu-divider"></div>
        <div class="menu-item danger" @click="deleteHost(contextMenu.targetHost!)">删除主机</div>
      </template>

      <!-- 设备树分组与空白处右键选项 -->
      <template v-else-if="contextMenu.targetType === 'group'">
        <div v-if="contextMenu.targetGroup" class="menu-item" @click="openAddHostModal">在此组新建主机</div>
        <div v-else class="menu-item" @click="openAddHostModal">新建主机</div>
        <div v-if="contextMenu.targetGroup" class="menu-item" @click="openRenameGroupModal(contextMenu.targetGroup)">重命名分组</div>
        <div class="menu-item" @click="openNewGroupModal">新建分组</div>
        <div v-if="contextMenu.targetGroup" class="menu-divider"></div>
        <div v-if="contextMenu.targetGroup" class="menu-item danger" @click="deleteGroup(contextMenu.targetGroup)">删除分组</div>
      </template>

      <!-- 备忘录条目右键选项 -->
      <template v-else-if="contextMenu.targetType === 'memo_item'">
        <div class="menu-item" @click="sendMemoCommand(contextMenu.targetMemoItem!.cmd); closeContextMenu()">立即执行此命令</div>
        <div class="menu-item" @click="openEditMemoModal(contextMenu.targetMemoGroupIdx!, contextMenu.targetMemoItemIdx!, contextMenu.targetMemoItem!)">编辑此命令</div>
        <div class="menu-item" @click="copyText(contextMenu.targetMemoItem!.cmd)">复制命令文本</div>
        <div class="menu-divider"></div>
        <div class="menu-item danger" @click="deleteMemo(contextMenu.targetMemoGroupIdx!, contextMenu.targetMemoItemIdx!)">删除命令</div>
      </template>

      <!-- 备忘录分组与空白处右键选项 -->
      <template v-else-if="contextMenu.targetType === 'memo_group' || contextMenu.targetType === 'memo_bg'">
        <div v-if="contextMenu.targetType === 'memo_group' && contextMenu.targetMemoGroupIdx !== null" class="menu-item" @click="openAddMemoModal(contextMenu.targetMemoGroupIdx)">在此组新建命令</div>
        <div v-else class="menu-item" @click="openAddMemoModal(0)">新建命令</div>
        <div v-if="contextMenu.targetType === 'memo_group' && contextMenu.targetMemoGroupIdx !== null" class="menu-item" @click="openRenameMemoGroupModal(contextMenu.targetMemoGroupIdx)">重命名分组</div>
        <div class="menu-item" @click="openNewMemoGroupModal">新建命令分组</div>
        <div v-if="contextMenu.targetType === 'memo_group' && contextMenu.targetMemoGroupIdx !== null" class="menu-divider"></div>
        <div v-if="contextMenu.targetType === 'memo_group' && contextMenu.targetMemoGroupIdx !== null" class="menu-item danger" @click="deleteMemoGroup(contextMenu.targetMemoGroupIdx)">删除分组</div>
      </template>

      <!-- 终端标签页右键菜单 (1:1 复刻 ssh8.py CustomTabItemWidget.show_context_menu) -->
      <template v-else-if="contextMenu.targetType === 'tab'">
        <div class="menu-item" @click="contextMenu.targetTab && toggleTabLock(contextMenu.targetTab); closeContextMenu()">
          {{ contextMenu.targetTab?.is_locked ? '解锁标签页' : '锁定标签页' }}
        </div>
        <div class="menu-item" @click="clearCurrentTerminal">清屏终端</div>
        <div class="menu-divider"></div>
        <div 
          :class="['menu-item', contextMenu.targetTab?.is_locked ? 'disabled' : 'danger']" 
          @click="!contextMenu.targetTab?.is_locked && contextMenu.targetTab && (closeSession(contextMenu.targetTab), closeContextMenu())"
        >
          关闭标签页
        </div>
      </template>

      <!-- 终端内容区右键选项 -->
      <template v-else-if="contextMenu.targetType === 'terminal'">
        <div class="menu-item" @click="copySelection">复制选中 (Ctrl+Shift+C)</div>
        <div class="menu-item" @click="pasteClipboard">粘贴内容 (Ctrl+Shift+V)</div>
        <div class="menu-divider"></div>
        <div class="menu-item" @click="selectAllTerminal">全选终端 (Select All)</div>
        <div class="menu-item" @click="clearCurrentTerminal">清空屏幕 (Clear)</div>
      </template>

      <!-- SFTP 文件条目右键选项 -->
      <template v-else-if="contextMenu.targetType === 'sftp_item'">
        <div v-if="!contextMenu.targetSftpItem?.is_dir" class="menu-item" @click="sftpTriggerDownload(contextMenu.targetSftpItem!)">下载文件到本地</div>
        <div class="menu-item" @click="sftpOpenRename(contextMenu.targetSftpItem!)">重命名</div>
        <div class="menu-item" @click="sftpOpenChmod(contextMenu.targetSftpItem!)">修改权限 (chmod)</div>
        <div class="menu-item" @click="sftpViewProperties(contextMenu.targetSftpItem!)">查看文件属性</div>
        <div class="menu-divider"></div>
        <div class="menu-item danger" @click="sftpDeleteItem(contextMenu.targetSftpItem!)">删除文件</div>
      </template>

      <!-- SFTP 空白区右键选项 -->
      <template v-else-if="contextMenu.targetType === 'sftp_bg'">
        <div class="menu-item" @click="sftpTriggerUpload">上传文件到此目录</div>
        <div class="menu-item" @click="sftpOpenNewFolder">新建文件夹</div>
        <div class="menu-item" @click="fetchSftpFiles(currentSftpPath)">刷新目录</div>
      </template>
    </div>

    <!-- 弹窗 1：主机配置编辑模态弹窗 (结构化优雅排版) -->
    <div v-if="hostModal.show" class="modal-overlay" @mousedown.self="hostModal.show = false">
      <div class="modal-card modal-host-edit">
        <div class="modal-header">
          <span class="modal-title">
            {{ hostModal.mode === 'asset' ? '编辑资产与配额' : (hostModal.mode === 'connection' ? (hostModal.isEdit ? '编辑主机配置' : '新建远程主机') : (hostModal.isEdit ? '编辑主机配置' : '新建远程主机')) }}
          </span>
          <span class="modal-close" @click="hostModal.show = false">✕</span>
        </div>

        <div class="modal-body modal-scrollable">
          <!-- 区块 1：基本连接信息 (仅在 connection 或 all 模式展示) -->
          <div v-if="hostModal.mode === 'connection' || hostModal.mode === 'all'" class="form-section-card">
            <div class="modal-section-title">
              <span class="section-title-icon">●</span>
              <span>连接与认证</span>
            </div>
            
            <div class="form-row">
              <label>显示名称</label>
              <input v-model="hostModal.form.name" class="modal-input" placeholder="例如：东京-SoftBank" />
            </div>

            <div class="form-row grid-host-port">
              <div class="field-col">
                <label>主机地址 (IP / 域名)</label>
                <input v-model="hostModal.form.host" class="modal-input" placeholder="192.168.1.1 或 domain.com" />
              </div>
              <div class="field-col">
                <label>SSH 端口</label>
                <input v-model.number="hostModal.form.port" type="number" class="modal-input text-center" />
              </div>
            </div>

            <div class="form-row grid-2">
              <div class="field-col">
                <label>登录用户名</label>
                <input v-model="hostModal.form.user" class="modal-input" placeholder="root" />
              </div>
              <div class="field-col">
                <label>登录密码 (可选)</label>
                <input v-model="hostModal.form.pwd" type="password" class="modal-input" placeholder="密码（或私钥密码）" />
              </div>
            </div>

            <div class="form-row">
              <label>私钥证书 (支持 .pem / id_rsa)</label>
              <div class="traffic-input-box">
                <input v-model="hostModal.form.key_path" class="modal-input flex-1" placeholder="留空则使用密码认证" />
                <button class="btn-sec-act btn-browse" type="button" @click="browseKeyFile">浏览选择...</button>
              </div>
            </div>
          </div>

          <!-- 区块 2：服务器资产与计费配额 (仅在 asset 或 all 模式展示) -->
          <div v-if="hostModal.mode === 'asset' || hostModal.mode === 'all'" class="form-section-card">
            <div class="modal-section-title">
              <span class="section-title-icon">●</span>
              <span>资产与计费配额</span>
            </div>

            <!-- 行 1：机器价格与到期时间 (精确到分) -->
            <div class="form-row grid-2">
              <div class="field-col">
                <label>机器价格与货币</label>
                <div class="input-combined-row">
                  <input v-model="hostModal.form.price" class="modal-input flex-1" placeholder="0.00" />
                  <CustomSelect 
                    v-model="hostModal.form.currency" 
                    :options="[
                      { label: 'CNY (￥)', value: 'CNY' },
                      { label: 'USD ($)', value: 'USD' },
                      { label: 'EUR (€)', value: 'EUR' },
                      { label: 'HKD (HK$)', value: 'HKD' },
                      { label: 'JPY (JP¥)', value: 'JPY' },
                      { label: 'GBP (£)', value: 'GBP' }
                    ]"
                    customClass="w-28 text-center"
                  />
                </div>
              </div>
              <div class="field-col">
                <label>到期时间 (精确到分)</label>
                <div class="input-combined-row">
                  <CustomDateTimePicker 
                    v-model="hostModal.form.expire_date" 
                    :disabled="hostModal.form.expire_infinite"
                    customClass="flex-1"
                  />
                  <label class="checkbox-label infinite-addon-check" title="永久无限期">
                    <input type="checkbox" v-model="hostModal.form.expire_infinite" />
                    无限期
                  </label>
                </div>
              </div>
            </div>

            <!-- 行 2：总计流量配额 + 已用流量 (基准已用) -->
            <div class="form-row grid-2">
              <div class="field-col">
                <label>总计流量配额</label>
                <div class="input-combined-row">
                  <input 
                    v-model="hostModal.form.traffic_total" 
                    :disabled="hostModal.form.traffic_total_infinite"
                    class="modal-input flex-1" 
                    placeholder="例如 1000"
                  />
                  <CustomSelect 
                    v-model="hostModal.form.traffic_total_unit"
                    :disabled="hostModal.form.traffic_total_infinite"
                    :options="[{ label: 'MB', value: 'MB' }, { label: 'GB', value: 'GB' }, { label: 'TB', value: 'TB' }]"
                    customClass="w-20 text-center"
                  />
                  <label class="checkbox-label infinite-addon-check" title="无限流量模式">
                    <input type="checkbox" v-model="hostModal.form.traffic_total_infinite" />
                    无限
                  </label>
                </div>
              </div>
              <div class="field-col">
                <label>已用流量 (基准已用)</label>
                <div class="input-combined-row">
                  <input 
                    v-model="hostModal.form.traffic_used" 
                    class="modal-input flex-1" 
                    placeholder="0"
                  />
                  <CustomSelect 
                    v-model="hostModal.form.traffic_used_unit"
                    :options="[{ label: 'MB', value: 'MB' }, { label: 'GB', value: 'GB' }, { label: 'TB', value: 'TB' }]"
                    customClass="w-24 text-center"
                  />
                </div>
              </div>
            </div>

            <!-- 行 3：流量重置时间 (每月几号 + 精确到分) -->
            <div class="form-row">
              <label>流量重置时间 (每月结算重置时刻，精确到分)</label>
              <div class="reset-time-row">
                <span class="time-prefix">每月</span>
                <CustomNumberStepper 
                  v-model="hostModal.form.reset_day" 
                  :min="1" 
                  :max="31" 
                  customClass="reset-day-stepper"
                />
                <span class="time-suffix">号</span>
                <CustomNumberStepper 
                  v-model="hostModal.form.reset_hour" 
                  :min="0" 
                  :max="23" 
                  :padZero="true" 
                  customClass="reset-digit-stepper"
                />
                <span class="time-colon">:</span>
                <CustomNumberStepper 
                  v-model="hostModal.form.reset_min" 
                  :min="0" 
                  :max="59" 
                  :padZero="true" 
                  customClass="reset-digit-stepper"
                />
                <span class="time-hint">(时 : 分)</span>
              </div>
            </div>

            <!-- 行 4：流量检测网卡名称 + 流量统计方向 -->
            <div class="form-row grid-2">
              <div class="field-col">
                <label>流量检测网卡名称</label>
                <input 
                  v-model="hostModal.form.target_interface" 
                  class="modal-input" 
                  placeholder="留空自动（默认路由 / eth0）"
                />
                <div class="field-hint">
                  支持多个网卡：用逗号分隔，如 <code>eth0,eth1</code>；填 <code>*</code> 统计所有物理网卡；支持 <code>eth*</code> 通配。多个网卡会累加；桥接/虚拟网卡请勿和物理网卡同时填写，避免重复计数。
                </div>
              </div>
              <div class="field-col">
                <label>流量统计方向</label>
                <CustomSelect 
                  v-model="hostModal.form.traffic_direction" 
                  :options="[
                    { label: '双向流量统计 (Tx + Rx)', value: 'both' },
                    { label: '仅计出站流量 (Tx)', value: 'tx' },
                    { label: '仅计入站流量 (Rx)', value: 'rx' }
                  ]"
                  customClass="w-full"
                />
              </div>
            </div>

            <!-- 行 5：流量价格 (超额/流量单价) -->
            <div class="form-row">
              <label>流量价格 (每 GB 价格 / 流量包费用)</label>
              <div class="input-combined-row">
                <input 
                  v-model="hostModal.form.traffic_price" 
                  class="modal-input flex-1" 
                  placeholder="0.00" 
                />
                <CustomSelect 
                  v-model="hostModal.form.traffic_currency" 
                  :options="[
                    { label: 'CNY (￥)', value: 'CNY' },
                    { label: 'USD ($)', value: 'USD' },
                    { label: 'EUR (€)', value: 'EUR' },
                    { label: 'HKD (HK$)', value: 'HKD' },
                    { label: 'JPY (JP¥)', value: 'JPY' },
                    { label: 'GBP (£)', value: 'GBP' }
                  ]"
                  customClass="w-28 text-center"
                />
              </div>
            </div>
          </div>

          <!-- 区块 3：专属备注 (仅在 asset 或 all 模式展示) -->
          <div v-if="hostModal.mode === 'asset' || hostModal.mode === 'all'" class="form-section-card">
            <div class="modal-section-title">
              <span class="section-title-icon">●</span>
              <span>备注说明</span>
            </div>
            <div class="form-row">
              <label>专属备注说明</label>
              <input v-model="hostModal.form.memo" class="modal-input" placeholder="机器用途、配置规格或购买商家等" />
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn-cancel" @click="hostModal.show = false">取消</button>
          <button class="btn-confirm" @click="saveHostForm">保存配置</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 2：流量统计与校准 (TrafficStatsDialog) -->
    <div v-if="trafficStatsModal.show" class="modal-overlay" @mousedown.self="trafficStatsModal.show = false">
      <div class="modal-card">
        <div class="modal-header">
          <span class="modal-title">流量统计 · {{ trafficStatsModal.host?.name }}</span>
          <span class="modal-close" @click="trafficStatsModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <div class="form-row">
            <label>统计方式:</label>
            <CustomSelect 
              v-model="trafficStatsModal.source" 
              :options="[
                { label: '自动 (vnstat → 本地计数器)', value: 'auto' },
                { label: 'vnstat', value: 'vnstat' },
                { label: '本地计数器 (/proc/net/dev)', value: 'proc' },
                { label: '自定义命令', value: 'custom' }
              ]"
              customClass="w-full"
            />
          </div>
          <div v-if="trafficStatsModal.source === 'custom'" class="form-row">
            <label>自定义审计命令:</label>
            <input v-model="trafficStatsModal.customCommand" class="modal-input" placeholder="输出示例：123.45 GB 或 123456789" />
          </div>
          <div class="form-row">
            <label>当前已用流量校准:</label>
            <div class="traffic-input-box">
              <input 
                v-model="trafficStatsModal.calibUsed" 
                class="modal-input flex-1" 
                @input="trafficStatsModal.manualOverride = true"
              />
              <CustomSelect 
                v-model="trafficStatsModal.calibUnit" 
                :options="[{ label: 'MB', value: 'MB' }, { label: 'GB', value: 'GB' }, { label: 'TB', value: 'TB' }]"
                customClass="w-24 text-center"
              />
            </div>
            <label class="md3-checkbox-label traffic-manual-check">
              <input type="checkbox" v-model="trafficStatsModal.manualOverride" class="md3-check-native" />
              <span>手动校准优先（自动审计不覆盖已用流量）</span>
            </label>
            <div v-if="trafficStatsModal.manualOverride" class="field-hint">
              已锁定为手工值；取消勾选后，后续自动审计会重新接管已用流量。
            </div>
          </div>
          <div class="form-row">
            <label>每月重置结算日:</label>
            <CustomNumberStepper 
              v-model="trafficStatsModal.resetDay" 
              :min="1" 
              :max="31" 
              customClass="w-32"
            />
          </div>
          <div class="traffic-sync-row">
            <button 
              class="traffic-sync-btn" 
              :disabled="trafficStatsModal.isSyncing" 
              @click="syncTrafficStatsNow"
            >
              <span v-if="trafficStatsModal.isSyncing" class="traffic-sync-spinner"></span>
              {{ trafficStatsModal.isSyncing ? '正在获取服务器信息...' : '立即获取服务器信息' }}
            </button>
          </div>
          <div 
            v-if="trafficStatsModal.syncMessage" 
            :class="['traffic-sync-status', trafficStatsModal.syncError ? 'is-error' : '']"
          >
            {{ trafficStatsModal.syncMessage }}
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="trafficStatsModal.show = false">取消</button>
          <button class="btn-confirm" @click="saveTrafficStats">保存并生效</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 3：SFTP 文件属性 (SFTPPropertiesDialog) -->
    <div v-if="sftpPropsModal.show" class="modal-overlay" @mousedown.self="sftpPropsModal.show = false">
      <div class="modal-card">
        <div class="modal-header">
          <span class="modal-title">文件属性</span>
          <span class="modal-close" @click="sftpPropsModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <div class="prop-row"><span class="k">名称:</span><span class="v">{{ sftpPropsModal.name }}</span></div>
          <div class="prop-row"><span class="k">完整路径:</span><span class="v">{{ sftpPropsModal.full_path }}</span></div>
          <div class="prop-row"><span class="k">类型:</span><span class="v">{{ sftpPropsModal.is_dir ? '目录' : '常规文件' }}</span></div>
          <div class="prop-row"><span class="k">大小:</span><span class="v">{{ sftpPropsModal.size_bytes }} 字节</span></div>
          <div class="prop-row"><span class="k">权限:</span><span class="v">{{ sftpPropsModal.mode_str }} ({{ sftpPropsModal.mode_oct }})</span></div>
          <div class="prop-row"><span class="k">修改时间:</span><span class="v">{{ sftpPropsModal.mtime_str }}</span></div>
        </div>
        <div class="modal-footer">
          <button class="btn-confirm" @click="sftpPropsModal.show = false">确定</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 4：SFTP 修改权限 (SFTPChmodDialog) -->
    <div v-if="sftpChmodModal.show" class="modal-overlay" @mousedown.self="sftpChmodModal.show = false">
      <div class="modal-card">
        <div class="modal-header">
          <span class="modal-title">修改权限 (chmod) · {{ sftpChmodModal.fileName }}</span>
          <span class="modal-close" @click="sftpChmodModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <table class="chmod-table">
            <thead>
              <tr>
                <th>身份</th>
                <th>读取 (r)</th>
                <th>写入 (w)</th>
                <th>执行 (x)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>所有者 (Owner)</td>
                <td><input type="checkbox" v-model="sftpChmodModal.u_r" /></td>
                <td><input type="checkbox" v-model="sftpChmodModal.u_w" /></td>
                <td><input type="checkbox" v-model="sftpChmodModal.u_x" /></td>
              </tr>
              <tr>
                <td>用户组 (Group)</td>
                <td><input type="checkbox" v-model="sftpChmodModal.g_r" /></td>
                <td><input type="checkbox" v-model="sftpChmodModal.g_w" /></td>
                <td><input type="checkbox" v-model="sftpChmodModal.g_x" /></td>
              </tr>
              <tr>
                <td>其他人 (Other)</td>
                <td><input type="checkbox" v-model="sftpChmodModal.o_r" /></td>
                <td><input type="checkbox" v-model="sftpChmodModal.o_w" /></td>
                <td><input type="checkbox" v-model="sftpChmodModal.o_x" /></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="sftpChmodModal.show = false">取消</button>
          <button class="btn-confirm" @click="sftpSaveChmod">应用权限</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 5：通用 Prompt 弹窗 (新建文件夹/重命名) -->
    <div v-if="promptModal.show" class="modal-overlay" @mousedown.self="promptModal.show = false">
      <div class="modal-card modal-small">
        <div class="modal-header">
          <span class="modal-title">{{ promptModal.title }}</span>
          <span class="modal-close" @click="promptModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <div class="form-row">
            <label>{{ promptModal.label }}</label>
            <input v-model="promptModal.value" class="modal-input" @keyup.enter="executePromptModal" autofocus />
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="promptModal.show = false">取消</button>
          <button class="btn-confirm" @click="executePromptModal">确定</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 5.5：通用优雅确认弹窗 (替换系统丑陋的默认 confirm 弹窗) -->
    <div v-if="customConfirmModal.show" class="modal-overlay" @mousedown.self="customConfirmModal.show = false">
      <div class="modal-card modal-small modal-confirm-card">
        <div class="modal-header">
          <span class="modal-title">{{ customConfirmModal.title }}</span>
          <span class="modal-close" @click="customConfirmModal.show = false">✕</span>
        </div>
        <div class="modal-body confirm-modal-body">
          <p class="confirm-modal-text">{{ customConfirmModal.message }}</p>
        </div>
        <div class="modal-footer">
          <button class="btn-confirm" @click="customConfirmModal.show = false">取消</button>
          <button 
            :class="customConfirmModal.danger ? 'btn-danger' : 'btn-cancel'" 
            @click="customConfirmModal.onConfirm"
          >
            {{ customConfirmModal.confirmText }}
          </button>
        </div>
      </div>
    </div>

    <!-- 弹窗 6：备忘录指令编辑弹窗 (MemoEditDialog) -->
    <div v-if="memoEditModal.show" class="modal-overlay" @mousedown.self="memoEditModal.show = false">
      <div class="modal-card modal-small">
        <div class="modal-header">
          <span class="modal-title">{{ memoEditModal.isEdit ? '编辑指令' : '新建常用指令' }}</span>
          <span class="modal-close" @click="memoEditModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <div class="form-row">
            <label>指令名称:</label>
            <input v-model="memoEditModal.form.name" class="modal-input" placeholder="例如：重启 Nginx" />
          </div>
          <div class="form-row">
            <label>执行命令:</label>
            <textarea v-model="memoEditModal.form.cmd" class="modal-input modal-textarea" placeholder="例如：systemctl restart nginx"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="memoEditModal.show = false">取消</button>
          <button class="btn-confirm" @click="saveMemo">保存</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 7：终端偏好与备份设置 (1:1 严格对标 ssh8.py TerminalSettingsDialog) -->
    <div v-if="showTerminalSettingsModal" class="modal-overlay" @mousedown.self="showTerminalSettingsModal = false">
      <div class="modal-card settings-modal-card">
        <div class="modal-header">
          <span class="modal-title">终端偏好与备份设置</span>
          <span class="modal-close" @click="showTerminalSettingsModal = false">✕</span>
        </div>
        <div class="modal-body settings-form-body">
          <!-- 0. 全局界面字体 (除 xterm 终端外统一生效) -->
          <div class="settings-form-row">
            <label class="settings-form-label">界面字体:</label>
            <div class="settings-form-field flex-row-gap">
              <span class="selected-font-preview" :title="appFontFamily">{{ getDisplayFontName(appFontFamily) }}</span>
              <button type="button" class="btn-card-act" @click="showFontSelectorModal = true">
                更换字体...
              </button>
            </div>
          </div>

          <!-- 1. 等宽字体 (xterm 终端专用) -->
          <div class="settings-form-row">
            <label class="settings-form-label">终端等宽字体:</label>
            <div class="settings-form-field">
              <CustomSelect 
                v-model="terminalSettings.font_family" 
                :options="[
                  { label: 'Consolas', value: 'Consolas' },
                  { label: 'Cascadia Code', value: 'Cascadia Code' },
                  { label: 'JetBrains Mono', value: 'JetBrains Mono' },
                  { label: 'Courier New', value: 'Courier New' },
                  { label: 'Fira Code', value: 'Fira Code' }
                ]"
                customClass="w-full"
              />
            </div>
          </div>

          <!-- 2. 字号大小 (CustomNumberStepper 步进调节) -->
          <div class="settings-form-row">
            <label class="settings-form-label">字号大小:</label>
            <div class="settings-form-field">
              <CustomNumberStepper 
                v-model="terminalSettings.font_size" 
                :min="8" 
                :max="28" 
                customClass="w-24 text-center"
              />
            </div>
          </div>

          <!-- 3. 字体加粗 -->
          <div class="settings-form-row">
            <label class="settings-form-label">字体加粗:</label>
            <div class="settings-form-field">
              <label class="md3-checkbox-label">
                <input type="checkbox" v-model="terminalSettings.is_bold" class="md3-check-native" />
                <span>加粗 (Bold)</span>
              </label>
            </div>
          </div>

          <!-- 4. 光标形状 -->
          <div class="settings-form-row">
            <label class="settings-form-label">光标形状:</label>
            <div class="settings-form-field">
              <CustomSelect 
                v-model="terminalSettings.cursor_style" 
                :options="[
                  { label: '块状光标 (Block)', value: 'block' },
                  { label: '竖线光标 (Bar)', value: 'bar' },
                  { label: '下划线光标 (Underline)', value: 'underline' }
                ]"
                customClass="w-full"
              />
            </div>
          </div>

          <!-- 5. 光标闪烁与频率 -->
          <div class="settings-form-row">
            <label class="settings-form-label">光标闪烁:</label>
            <div class="settings-form-field blink-row">
              <label class="md3-checkbox-label">
                <input type="checkbox" v-model="terminalSettings.cursor_blink" class="md3-check-native" />
                <span>启用闪烁</span>
              </label>
              <span class="blink-speed-label">频率(ms):</span>
              <CustomNumberStepper 
                v-model="terminalSettings.blink_interval" 
                :step="50" 
                :min="200" 
                :max="2000" 
                :disabled="!terminalSettings.cursor_blink"
                customClass="w-28 text-center"
              />
            </div>
          </div>

          <!-- 6. 终端背景预设 (黑/白) -->
          <div class="settings-form-row">
            <label class="settings-form-label">终端背景预设:</label>
            <div class="settings-form-field bg-preset-row">
              <button 
                type="button" 
                :class="['btn-bg-preset', terminalSettings.term_bg_mode === 'dark' ? 'active' : '']"
                @click="setTerminalBgPreset('dark')"
              >
                黑色背景 (黑底绿字)
              </button>
              <button 
                type="button" 
                :class="['btn-bg-preset', terminalSettings.term_bg_mode === 'light' ? 'active' : '']"
                @click="setTerminalBgPreset('light')"
              >
                白色背景 (浅灰黑字)
              </button>
            </div>
          </div>

          <!-- 7. 终端文字色彩 (调色块 + 自定义取色盘) -->
          <div class="settings-form-row">
            <label class="settings-form-label">终端文字色彩:</label>
            <div class="settings-form-field color-palette-row">
              <button 
                v-for="c in (terminalSettings.term_bg_mode === 'dark' ? darkPresetColors : lightPresetColors)" 
                :key="c"
                type="button"
                :class="['color-swatch-btn', terminalSettings.terminal_fg_color.toLowerCase() === c.toLowerCase() ? 'active' : '']"
                :style="{ backgroundColor: c }"
                @click="terminalSettings.terminal_fg_color = c"
                :title="c"
              ></button>
              <!-- 自定义取色按钮 -->
              <label class="rainbow-custom-color-btn" title="自定义取色盘">
                <input type="color" v-model="terminalSettings.terminal_fg_color" class="hidden-color-picker" />
                <span class="rainbow-center-dot"></span>
              </label>
            </div>
          </div>

          <!-- 8. 关闭行为 -->
          <div class="settings-form-row">
            <label class="settings-form-label">关闭窗口:</label>
            <div class="settings-form-field">
              <label class="md3-checkbox-label">
                <input type="checkbox" v-model="terminalSettings.minimize_to_tray" class="md3-check-native" />
                <span>点击关闭按钮时隐藏到系统托盘（不退出程序）</span>
              </label>
            </div>
          </div>

          <!-- 9. 备份相关入口 -->
          <div class="backup-entry-row">
            <button type="button" class="btn-backup-center" @click="openBackupFromSettings">
              备份相关 (本地备份 / WebDAV 云同步)
            </button>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="showTerminalSettingsModal = false">取消</button>
          <button class="btn-confirm" @click="applyTerminalSettings">保存</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 7.5：全局界面字体更换选择弹窗 (FontSelectorModal) -->
    <div v-if="showFontSelectorModal" class="modal-overlay" @mousedown.self="showFontSelectorModal = false">
      <div class="modal-card font-selector-modal-card">
        <div class="modal-header">
          <span class="modal-title">更换界面字体 (全局生效)</span>
          <span class="modal-close" @click="showFontSelectorModal = false">✕</span>
        </div>
        <div class="modal-body font-selector-body">
          <div class="font-selector-toolbar">
            <label class="md3-checkbox-label">
              <input 
                type="checkbox" 
                v-model="includeSystemFonts" 
                @change="handleToggleSystemFonts" 
                class="md3-check-native" 
              />
              <span>读取系统字体</span>
            </label>
            <span v-if="isReadingSystemFonts" class="font-loading-tip">正在读取系统中...</span>
          </div>

          <div class="font-list-scrollable">
            <!-- 推荐默认与精选字体 -->
            <div class="font-group-title">精选与默认界面字体</div>
            <div 
              v-for="item in presetUiFonts" 
              :key="item.value"
              :class="['font-item-row', appFontFamily === item.value ? 'active' : '']"
              @click="applyAppFont(item.value)"
            >
              <div class="font-item-left">
                <span class="font-item-name">{{ item.name }}</span>
                <span class="font-item-preview" :style="{ fontFamily: item.value }">QShell Next 快速连接终端 1234567890</span>
              </div>
              <span v-if="appFontFamily === item.value" class="font-check-mark">✓</span>
            </div>

            <!-- 读取到的系统字体 -->
            <template v-if="includeSystemFonts">
              <div class="font-group-title">系统已安装字体 ({{ systemFontList.length }})</div>
              <div 
                v-for="f in systemFontList" 
                :key="f"
                :class="['font-item-row', appFontFamily.includes(f) ? 'active' : '']"
                @click="applyAppFont(`'${f}', sans-serif`)"
              >
                <div class="font-item-left">
                  <span class="font-item-name">{{ f }}</span>
                  <span class="font-item-preview" :style="{ fontFamily: `'${f}', sans-serif` }">QShell Next 终端系统 1234567890 AaBbCc</span>
                </div>
                <span v-if="appFontFamily.includes(f)" class="font-check-mark">✓</span>
              </div>
            </template>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-confirm" @click="showFontSelectorModal = false">完成选择</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 8：备份与云同步管理 (BackupManagementDialog) -->
    <div v-if="backupModal.show" class="modal-overlay" @mousedown.self="backupModal.show = false">
      <div class="modal-card">
        <div class="modal-header">
          <span class="modal-title">配置备份与 WebDAV 云同步</span>
          <span class="modal-close" @click="backupModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <div class="backup-section-title">本地配置备份</div>
          <div class="backup-btn-row">
            <button class="btn-sec-act flex-1" @click="handleExportLocal">导出备份到本地 (.zip)</button>
            <button class="btn-sec-act flex-1" @click="handleImportLocal">从本地恢复配置 (.zip)</button>
          </div>

          <div class="backup-divider"></div>
          <div class="backup-section-title">WebDAV 云端同步</div>
          <div class="form-row">
            <label>服务器 URL:</label>
            <input v-model="backupModal.webdav_url" class="modal-input" placeholder="https://dav.example.com/dav/" @input="scheduleWebdavSettingsSave" />
          </div>
          <div class="form-row grid-2">
            <div>
              <label>用户名 / 邮箱:</label>
              <input v-model="backupModal.webdav_user" class="modal-input" @input="scheduleWebdavSettingsSave" />
            </div>
            <div>
              <label>密码 / 应用授权码:</label>
              <input v-model="backupModal.webdav_pwd" type="password" class="modal-input" @input="scheduleWebdavSettingsSave" />
            </div>
          </div>
          <div class="form-row">
            <label>云端存储文件路径:</label>
            <input v-model="backupModal.webdav_path" class="modal-input" placeholder="/qshell_backup.zip" @input="scheduleWebdavSettingsSave" />
          </div>

          <div class="backup-btn-row">
            <button class="btn-sec-act" :disabled="backupModal.is_busy" @click="handleWebdavTest">测试连接</button>
            <button class="btn-sec-act" :disabled="backupModal.is_busy" @click="handleWebdavUpload">立即上传备份</button>
            <button class="btn-sec-act" :disabled="backupModal.is_busy" @click="handleWebdavDownload">从云端恢复</button>
          </div>

          <div v-if="backupModal.status_msg" class="backup-status-text">
            {{ backupModal.status_msg }}
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="backupModal.show = false">关闭</button>
        </div>
      </div>
    </div>

    <!-- 弹窗 9：从设备列表导入主机 (HostImportSelectionDialog) -->
    <div v-if="importSelectModal.show" class="modal-overlay" @mousedown.self="importSelectModal.show = false">
      <div class="modal-card modal-small">
        <div class="modal-header">
          <span class="modal-title">导入主机到管理面板</span>
          <span class="modal-close" @click="importSelectModal.show = false">✕</span>
        </div>
        <div class="modal-body">
          <div v-if="importSelectModal.candidates.length === 0" class="no-task">
            所有设备树主机均已在主机管理中，无需重复导入。
          </div>
          <div v-else class="import-list">
            <div 
              v-for="(h, idx) in importSelectModal.candidates" 
              :key="h.host + h.port" 
              class="import-item"
            >
              <label class="checkbox-label">
                <input 
                  type="checkbox" 
                  :value="idx" 
                  v-model="importSelectModal.selectedIndexes" 
                />
                <span class="import-hname">{{ h.name }}</span>
                <span class="import-haddr">({{ h.host }}:{{ h.port }})</span>
              </label>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="importSelectModal.show = false">取消</button>
          <button 
            v-if="importSelectModal.candidates.length > 0" 
            class="btn-confirm" 
            @click="confirmImportSelected"
          >
            确认导入 ({{ importSelectModal.selectedIndexes.length }})
          </button>
        </div>
      </div>
    </div>

  </div>
</template>

<style>
/* 核心暗黑主题 Material You 设计系统 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body, html, #app {
  width: 100%;
  height: 100%;
  overflow: hidden;
  font-family: var(--app-font-family);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
  background: transparent;
}

button, input, select {
  font-family: var(--app-font-family);
}

/* --- 按钮字体设为粗体 (Bold / 600)，字号精细紧凑 (11px / 12px) --- */
button {
  font-weight: 600 !important;
}

/* 卡片操作、SFTP、列选择等按钮恢复精细 11px 粗体 */
.btn-card-act,
.btn-sftp-action,
.btn-col-choice,
.sftp-btn,
.btn-popover-ignore,
.btn-mini-tag {
  font-size: 11px !important;
  font-weight: 600 !important;
}

/* 药丸按键、弹窗确定/取消、添加主机等恢复标准 12px 粗体 */
.btn-mgmt-pill,
.btn-sec-act,
.btn-add-host,
.btn-cancel,
.btn-confirm,
.btn-backup-center,
.btn-bg-preset {
  font-size: 12px !important;
  font-weight: 600 !important;
}

:root {
  --app-font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", sans-serif;
  /* ===================== Material Design 3 (MD3) 纯中性暗色调色板 (MD3 Neutral - 零偏色、纯正中性灰层次) ===================== */
  /* MD3 Neutral Surface (基底底色): 纯粹无偏色的中性深灰 (N-10/12) */
  --bg-app: #151517;
  --bg-main: #151517;

  /* MD3 Neutral Surface Container (卡片与容器 - Elevation Level 1 & 2): 纯正中性深灰 (N-20/22) */
  --bg-card: #202024;
  --bg-capsule: #2A2A2E;
  --bg-capsule-hover: #35353A;
  --bg-sub-card: #1B1B1E;
  --bg-input: #1B1B1E;
  --bg-track: #35353A;
  --bg-modal: #2A2A2E;

  /* MD3 Neutral Outline (边界线规范): 纯正中性轮廓线 (N-50/60)，边界绝对分明 */
  --border-card: #444449;
  --border-capsule: rgba(255, 255, 255, 0.1);
  --border-input: #444449;

  /* MD3 Neutral On-Surface & On-Surface-Variant (文字规范 - 纯正象牙白与中性灰) */
  --text-main: #E3E3E6;
  --text-title: #F2F2F5;
  --text-sub: #A8A8B0;

  /* MD3 Primary (明朗科技淡蓝) */
  --btn-primary-bg: #A8C7FA;
  --btn-primary-hover: #BFD6FC;
  --btn-primary-active: #8EB7F8;
  --btn-primary-text: #042E61;

  --btn-sec-bg: #2A2A2E;
  --btn-sec-border: #444449;
  --btn-sec-text: #E3E3E6;
  --btn-sec-hover: #35353A;

  --color-primary: var(--btn-primary-bg);
  --color-primary-hover: var(--btn-primary-hover);
  --color-primary-active: var(--btn-primary-active);
  --color-on-primary: var(--btn-primary-text);
  --color-accent-gold: #F8D675;

  /* 顶栏图标与窗口按钮 */
  --nav-icon-color: #A8A8B0;
  --nav-icon-hover-bg: rgba(255, 255, 255, 0.08);
  --nav-icon-hover-color: #F2F2F5;
  --win-btn-hover-bg: rgba(255, 255, 255, 0.09);
  --win-btn-active-bg: rgba(255, 255, 255, 0.16);
  --win-btn-color: #E3E3E6;
  --term-empty-bg: #1B1B1E;

  --radius-btn: 6px;
  --radius-card: 12px;
  --radius-capsule: 8px;
}

[data-theme="light"] {
  /* ===================== 亮色模式模板 (Warm Neutral Light Theme - 温润护眼、清晰层次) ===================== */
  --bg-app: #ECECEE;
  --bg-main: #ECECEE;
  --bg-card: #FFFFFF;
  --bg-capsule: #E2E2E6;
  --bg-capsule-hover: #D6D6DB;
  --bg-sub-card: #F4F4F6;
  --bg-input: #FFFFFF;
  --bg-track: #D8D8DE;
  --bg-modal: #FFFFFF;

  --border-card: #CDCDD3;
  --border-capsule: rgba(0, 0, 0, 0.08);
  --border-input: #C4C4CA;

  --text-main: #1D1D20;
  --text-title: #111114;
  --text-sub: #5E5E66;

  --btn-primary-bg: #2057A6;
  --btn-primary-hover: #2E69BF;
  --btn-primary-active: #184587;
  --btn-primary-text: #FFFFFF;

  --btn-sec-bg: #E4E4E8;
  --btn-sec-border: #CDCDD3;
  --btn-sec-text: #1D1D20;
  --btn-sec-hover: #D8D8DE;

  --color-primary: var(--btn-primary-bg);
  --color-primary-hover: var(--btn-primary-hover);
  --color-primary-active: var(--btn-primary-active);
  --color-on-primary: var(--btn-primary-text);
  --color-accent-gold: #B45309;

  /* 顶栏图标与窗口按钮 */
  --nav-icon-color: #4B4B52;
  --nav-icon-hover-bg: rgba(0, 0, 0, 0.06);
  --nav-icon-hover-color: #1D1D20;
  --win-btn-hover-bg: rgba(0, 0, 0, 0.07);
  --win-btn-active-bg: rgba(0, 0, 0, 0.12);
  --win-btn-color: #2D2D32;
  --term-empty-bg: #FFFFFF;
}

/* =========================================================================
   全局滚动条与终端滚动条 1:1 对标 ssh8.py 设计语言 (QScrollBar & Xterm Scrollbar)
   width: 8px; transparent track; thumb: #43474E; border-radius: 4px; hover: @primary@
   ========================================================================= */
::-webkit-scrollbar,
*::-webkit-scrollbar {
  width: 8px !important;
  height: 8px !important;
  background: transparent !important;
}

::-webkit-scrollbar-track,
*::-webkit-scrollbar-track {
  background: transparent !important;
}

::-webkit-scrollbar-thumb,
*::-webkit-scrollbar-thumb {
  background: #43474E !important;
  border-radius: 4px !important;
  min-height: 24px !important;
}

::-webkit-scrollbar-thumb:hover,
*::-webkit-scrollbar-thumb:hover {
  background: var(--color-primary) !important;
}

/* 说明：xterm.js 6 使用自绘滚动条 (SmoothScrollableElement)，
   不再走 ::-webkit-scrollbar，真实样式见文件末尾的
   “终端 xterm.js 6 自绘滚动条” 规则。 */

/* 现代化 View Transitions (圆形涟漪水波扩散) 专用样式 */
::view-transition-old(root),
::view-transition-new(root) {
  animation: none;
  mix-blend-mode: normal;
}
::view-transition-old(root) {
  z-index: 1;
}
::view-transition-new(root) {
  z-index: 999999;
}

.app-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  background: var(--bg-app);
  color: var(--text-main);
  user-select: none;
}

/* 顶部极简原生拖拽顶栏 (一体化框体顶头) */
.title-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 44px;
  background: transparent;
  padding: 0 14px 0 16px;
  user-select: none;
  flex-shrink: 0;
  z-index: 20;
}

.brand {
  display: flex;
  align-items: center;
  gap: 4px;
}

.logo-title {
  font-family: "Arial Black", Gadget, sans-serif;
  font-size: 19px;
  font-weight: 900;
  color: var(--color-primary);
  letter-spacing: 1px;
  line-height: 1;
}

/* 1:1 对标 ssh8.py tag_col: QVBoxLayout 置顶上浮 8px (往上移动2px) */
.tag-version-wrapper {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  margin-bottom: 8px;
  margin-left: 2px;
  transform: translateY(-2px);
}

.version-badge {
  display: inline-flex;
  align-items: center;
  gap: 2.5px;
  height: 13px;
  padding: 0 4px;
  border-radius: 6.5px;
  background: rgba(46, 36, 18, 0.86);
  border: 1px solid #E5C158;
}

.version-badge .badge-dot {
  font-size: 5px;
  color: #E5C158;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  transform: translateY(0.5px);
}

.version-badge .badge-text {
  font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
  font-size: 8.5px;
  font-weight: 500;
  color: #FFE082;
  letter-spacing: 0.1px;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  transform: translateY(0.5px);
}

[data-theme="light"] .version-badge {
  background: rgba(254, 243, 214, 0.9);
  border: 1px solid #D9A404;
}

[data-theme="light"] .version-badge .badge-dot {
  color: #B45309;
}

[data-theme="light"] .version-badge .badge-text {
  color: #78350F;
}

.top-right-group {
  display: flex;
  align-items: center;
  gap: 6px;
}

.btn-mgmt-pill {
  height: 28px;
  padding: 0 16px;
  font-size: 12px;
  font-weight: 600;
  color: var(--color-on-primary);
  background: var(--color-primary);
  border: 1px solid var(--color-primary);
  border-radius: var(--radius-btn);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
}

.btn-mgmt-pill:hover {
  background: var(--color-primary-hover);
  border-color: var(--color-primary-hover);
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
}

.btn-mgmt-pill:active {
  background: var(--color-primary-active);
  transform: translateY(0);
}

.btn-mgmt-pill.active {
  background: var(--color-primary);
  border-color: var(--color-primary);
  color: var(--color-on-primary);
}

/* 1:1 对标 ssh8.py WindowControlButton: 固定尺寸 34px × 30px，平铺排布 */
.top-icon-btn {
  width: 34px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  border-radius: 6px;
  color: var(--nav-icon-color);
  cursor: pointer;
  position: relative;
  transition: all 0.16s cubic-bezier(0.4, 0, 0.2, 1);
}

.top-icon-btn:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #FFFFFF;
}

[data-theme="light"] .top-icon-btn:hover {
  background: rgba(0, 0, 0, 0.08);
  color: #0B57D0;
}

.top-icon-btn.active {
  color: var(--color-primary) !important;
  background: var(--nav-icon-hover-bg) !important;
}

/* =========================================================================
   1:1 对标 ssh8.py 顶栏图标互动动画 (Micro-Interactions)
   - 切换主题: 360° OutBack 弹性平滑旋转
   - 铃铛通知: 挂环支点物理级钟摆摇摆 (Swing)
   - 传输任务: 上传往上冲、下载往下沉交错冲刺 (Arrows Shift)
   - 偏好设置: 机械齿轮 60° 咬合正转 (Gear Rotate)
   - 侧边栏: 折叠指示箭头弹性横移 (Collapse Shift)
   ========================================================================= */

/* 1. 主题切换图标动效 */
.top-icon-btn:hover .icon-moon,
.top-icon-btn:hover .icon-sun,
.top-icon-btn:active .icon-moon,
.top-icon-btn:active .icon-sun {
  animation: theme-spin 0.48s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes theme-spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 2. 铃铛摇晃动效 (以顶部挂环 cx, cy-7 为支点) */
.top-icon-btn:hover .icon-bell,
.top-icon-btn.has-alert:hover .icon-bell {
  transform-origin: 12px 5px;
  animation: bell-swing 0.4s ease-in-out;
}
@keyframes bell-swing {
  0% { transform: rotate(0deg); }
  25% { transform: rotate(16deg); }
  50% { transform: rotate(-14deg); }
  75% { transform: rotate(8deg); }
  100% { transform: rotate(0deg); }
}

/* 3. 传输双向箭头交互动效 (左箭头上冲，右箭头下沉) */
.top-icon-btn:hover .icon-transfer .arrow-up-group {
  animation: arrow-up-dash 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.top-icon-btn:hover .icon-transfer .arrow-down-group {
  animation: arrow-down-dash 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes arrow-up-dash {
  0% { transform: translateY(0); }
  50% { transform: translateY(-3px); }
  100% { transform: translateY(0); }
}
@keyframes arrow-down-dash {
  0% { transform: translateY(0); }
  50% { transform: translateY(3px); }
  100% { transform: translateY(0); }
}

/* 4. 偏好设置：六齿齿轮外圈原位自转，中心轴心稳固不动，杜绝横移 */
.top-icon-btn:hover .icon-settings .gear-outer-teeth {
  transform-origin: 12px 12px;
  animation: gear-spin 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes gear-spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(60deg); }
}

/* 5. 侧边栏折叠横向横移微动效 */
.top-icon-btn:hover .icon-collapse .collapse-arrow {
  animation: collapse-arrow-nudge 0.3s ease-out;
}
@keyframes collapse-arrow-nudge {
  0% { transform: translateX(0); }
  50% { transform: translateX(2.5px); }
  100% { transform: translateX(0); }
}

.alert-dot {
  position: absolute;
  top: 5px;
  right: 6px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #EF4444;
  box-shadow: 0 0 5px rgba(239, 68, 68, 0.8);
}

.window-controls {
  display: flex;
  align-items: center;
  margin-left: 2px;
}

/* 1:1 对标 ssh8.py WindowControlButton (34px × 30px) */
.win-btn {
  width: 34px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  border-radius: 6px;
  color: var(--win-btn-color);
  cursor: pointer;
  transition: background 0.16s, color 0.16s;
}

.win-btn:hover {
  background: rgba(255, 255, 255, 0.09);
  color: #FFFFFF;
}

[data-theme="light"] .win-btn:hover {
  background: rgba(0, 0, 0, 0.08);
  color: #0F172A;
}

.win-btn.close:hover {
  background: #BA1A1A !important;
  color: #FFFFFF !important;
}

/* 主工作区布局 (一体化大框体核心内容区) */
.main-body {
  flex: 1;
  display: flex;
  overflow: hidden;
  position: relative;
  background: transparent;
  padding: 10px;
}

.workspace-layout {
  display: flex;
  width: 100%;
  height: 100%;
  position: relative;
}

/* 隐藏时保持原位与几何尺寸不变，杜绝 xterm 字符度量与行宽归零 */
.workspace-layout.view-hidden {
  position: absolute;
  top: 10px;
  left: 10px;
  right: 10px;
  bottom: 10px;
  opacity: 0;
  pointer-events: none;
  z-index: 0;
}

/* 分割拖拽手柄 */
.splitter-handle {
  width: 8px;
  margin: 0 -2px;
  cursor: col-resize;
  position: relative;
  z-index: 10;
  background: transparent !important;
}

.splitter-handle-v {
  height: 8px;
  margin: -2px 0;
  cursor: row-resize;
  position: relative;
  z-index: 10;
  background: transparent !important;
}

/* 通用圆角独立卡片设计 */
.card-container {
  background: var(--bg-card);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-card);
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4), 0 4px 16px rgba(0, 0, 0, 0.35);
  transition: background-color 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease;
}

[data-theme="light"] .card-container {
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), 0 4px 16px rgba(0, 0, 0, 0.06);
}

.card-header-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--text-title);
  padding: 12px 14px 6px 14px;
}

/* 左栏：监控卡片 + 设备列表卡片 (原版宽幅) */
.left-panel {
  display: flex;
  flex-direction: column;
  background: transparent;
  border: none;
  flex-shrink: 0;
  height: 100%;
  overflow: hidden;
}

.monitor-card {
  padding: 0 14px 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 7px;
  box-sizing: border-box;
}

.gauge-group {
  display: flex;
  flex-direction: column;
  gap: 7px;
}

.gauge-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.gauge-label {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 12px;
  color: var(--text-main);
  font-weight: 500;
}

.gauge-track {
  height: 8px;
  background: var(--bg-track);
  border-radius: 4px;
  overflow: hidden;
}

.gauge-fill {
  height: 100%;
  border-radius: 4px;
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.gauge-fill.cpu { 
  background: linear-gradient(90deg, #78D9EC 0%, #A8C7FA 100%); 
  box-shadow: 0 0 8px rgba(120, 217, 236, 0.45);
}
.gauge-fill.mem { 
  background: linear-gradient(90deg, #81C995 0%, #A8DAB5 100%); 
  box-shadow: 0 0 8px rgba(129, 201, 149, 0.45);
}
.gauge-fill.disk { 
  background: linear-gradient(90deg, #D7AEFB 0%, #E6C9FF 100%); 
  box-shadow: 0 0 8px rgba(215, 174, 251, 0.45);
}

[data-theme="light"] .gauge-fill.cpu {
  background: linear-gradient(90deg, #0284C7 0%, #2563EB 100%);
  box-shadow: none;
}
[data-theme="light"] .gauge-fill.mem {
  background: linear-gradient(90deg, #16A34A 0%, #059669 100%);
  box-shadow: none;
}
[data-theme="light"] .gauge-fill.disk {
  background: linear-gradient(90deg, #9333EA 0%, #7C3AED 100%);
  box-shadow: none;
}

/* 网络接口状态胶囊 (仿版本号 Tag 质感，优雅圆角矩形，深邃极客微光) */
.net-if-status-row {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  margin-top: 2px;
  margin-bottom: 2px;
}

.net-if-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 20px;
  padding: 0 8px;
  border-radius: 5px; /* 规整精致圆角矩形 */
  background: rgba(16, 37, 53, 0.82);
  border: 1px solid rgba(120, 217, 236, 0.45);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
  transition: all 0.25s ease;
}

.net-if-badge .if-dot {
  font-size: 7px;
  color: #78D9EC;
  line-height: 1;
}

.net-if-badge .if-text {
  font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, monospace, sans-serif;
  font-size: 11px;
  font-weight: 700;
  color: #BEEBF7;
  letter-spacing: 0.2px;
  line-height: 1;
}

/* 亮色模式适配 (清爽科技天蓝圆角矩形) */
[data-theme="light"] .net-if-badge {
  background: #E0F2FE;
  border: 1px solid #7DD3FC;
  box-shadow: 0 1px 2px rgba(2, 132, 199, 0.1);
}

[data-theme="light"] .net-if-badge .if-dot {
  color: #0284C7;
}

[data-theme="light"] .net-if-badge .if-text {
  color: #0369A1;
}

/* 未连接/闲置状态微调 */
.net-if-badge.idle {
  background: rgba(30, 34, 43, 0.6);
  border-color: rgba(255, 255, 255, 0.1);
}
.net-if-badge.idle .if-dot {
  color: #94A3B8;
}
.net-if-badge.idle .if-text {
  color: #94A3B8;
}
[data-theme="light"] .net-if-badge.idle {
  background: #F1F5F9;
  border-color: #CBD5E1;
}
[data-theme="light"] .net-if-badge.idle .if-dot,
[data-theme="light"] .net-if-badge.idle .if-text {
  color: #64748B;
}

.net-traffic-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  margin-top: 2px;
}

.net-sub-card {
  background: #1A1C22;
  border: 1px solid #2B2D33;
  border-radius: 9px;
  padding: 6px 8px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 80px;
  transition: background-color 0.2s, border-color 0.2s;
}

[data-theme="light"] .net-sub-card {
  background: #F1F4F9;
  border: 1px solid #D5DDE8;
}

.net-header {
  display: flex;
  align-items: center;
  gap: 6px;
}

.net-arrow {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
}

.net-arrow.up { 
  background: #142838; 
  color: #78D9EC; 
  border: 1px solid #1E3D59;
}
.net-arrow.down { 
  background: #142E20; 
  color: #81C995; 
  border: 1px solid #224E35;
}

[data-theme="light"] .net-arrow.up {
  background: #E1EEFF;
  color: #0B57D0;
  border: 1px solid #B6D4FE;
}

[data-theme="light"] .net-arrow.down {
  background: #E2F7E9;
  color: #15803D;
  border: 1px solid #A3E6BA;
}

.net-text {
  display: flex;
  flex-direction: column;
}

.net-text .dir { font-size: 10px; color: var(--text-sub); }
.net-text .spd { font-size: 11px; font-weight: 600; color: var(--text-main); }

.led-svg-wrap {
  width: 100%;
  padding-top: 3px;
}

.led-matrix-svg {
  width: 100%;
  height: 42px;
  display: block;
  overflow: visible;
}

/* SVG 几何灯珠 - 坐标由 SVG 视口严格锁定，每一个宽高均为标准的 8px × 6px，绝对均等 */
.svg-led {
  fill: #1C2029;
  transition: fill 0.35s ease, opacity 0.35s ease, filter 0.35s ease;
}

[data-theme="light"] .svg-led {
  fill: #D8DFEB;
}

/* 亮起基础底色 */
.svg-led.active-up {
  fill: #153248;
}

.svg-led.active-down {
  fill: #133520;
}

[data-theme="light"] .svg-led.active-up {
  fill: #BAE6FD;
}

[data-theme="light"] .svg-led.active-down {
  fill: #BBF7D0;
}

/* 头部高亮灯珠 + 尾随 3 颗渐变衰减灯珠 (使用真实计算颜色，不改变 opacity，彻底避免背景底色透出闪亮) */
.svg-led.runner-head-up {
  fill: #78D9EC !important;
  filter: drop-shadow(0 0 3px #78D9EC);
}

.svg-led.runner-tail-1-up {
  fill: #52ADC1 !important;
}

.svg-led.runner-tail-2-up {
  fill: #347B8C !important;
}

.svg-led.runner-tail-3-up {
  fill: #1E4E5A !important;
}

.svg-led.runner-head-down {
  fill: #81C995 !important;
  filter: drop-shadow(0 0 3px #81C995);
}

.svg-led.runner-tail-1-down {
  fill: #5BA36F !important;
}

.svg-led.runner-tail-2-down {
  fill: #39764B !important;
}

.svg-led.runner-tail-3-down {
  fill: #1E4B2C !important;
}

/* 亮色模式适配 (由高亮蓝/绿逐渐衰减回基底色) */
[data-theme="light"] .svg-led.runner-head-up {
  fill: #0284C7 !important;
  filter: drop-shadow(0 0 2.5px rgba(2, 132, 199, 0.7));
}
[data-theme="light"] .svg-led.runner-tail-1-up {
  fill: #38BDF8 !important;
}
[data-theme="light"] .svg-led.runner-tail-2-up {
  fill: #7DD3FC !important;
}
[data-theme="light"] .svg-led.runner-tail-3-up {
  fill: #BAE6FD !important;
}

[data-theme="light"] .svg-led.runner-head-down {
  fill: #16A34A !important;
  filter: drop-shadow(0 0 2.5px rgba(22, 163, 74, 0.7));
}
[data-theme="light"] .svg-led.runner-tail-1-down {
  fill: #4ADE80 !important;
}
[data-theme="light"] .svg-led.runner-tail-2-down {
  fill: #86EFAC !important;
}
[data-theme="light"] .svg-led.runner-tail-3-down {
  fill: #BBF7D0 !important;
}

.device-list-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-sizing: border-box;
}

.search-box-row {
  padding: 0 12px 8px 12px;
  position: relative;
  display: flex;
  align-items: center;
}

.search-icon-slot {
  position: absolute;
  left: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-sub);
  pointer-events: none;
}

.device-search-input {
  width: 100%;
  height: 32px;
  line-height: normal;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: var(--radius-btn);
  padding: 0 28px 2px 28px;
  font-size: 12px;
  color: var(--text-main);
  outline: none;
  transition: all 0.2s ease;
  box-sizing: border-box;
}

.device-search-input:focus {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15);
}

.search-clear {
  position: absolute;
  right: 20px;
  font-size: 11px;
  color: var(--text-sub);
  cursor: pointer;
  padding: 2px 4px;
}

.tree-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 4px 8px 10px 8px;
}

.group-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 7px 8px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  color: var(--text-main);
  transition: all 0.15s;
  position: relative;
  border: 1px solid transparent;
}

.group-header:hover { background: var(--bg-capsule-hover); }

/* 拖拽指示样式 */
.group-header.drag-target-before {
  border-top: 2px solid var(--color-primary) !important;
}

.group-header.drag-target-after {
  border-bottom: 2px solid var(--color-primary) !important;
}

.group-header.drag-target-inside {
  background: var(--bg-capsule-hover) !important;
  border: 1px dashed var(--color-primary) !important;
}

.group-header.is-dragging {
  opacity: 0.4;
}

.group-chevron {
  color: var(--text-sub);
  transition: transform 0.2s ease;
}

.group-folder-icon {
  color: var(--color-primary);
  margin-right: 2px;
}

.group-name { font-size: 13px; font-weight: 600; }
.group-badge { font-size: 11px; color: var(--text-sub); }

.group-body {
  padding: 3px 0 6px 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-height: 12px;
}

/* 1:1 对标 ssh8.py 胶囊卡片：高度 36px，内边距舒展 */
.host-capsule-item {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 36px;
  padding: 0 12px;
  background: var(--bg-capsule);
  border: 1px solid var(--border-capsule);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s ease;
  box-sizing: border-box;
  position: relative;
}

.host-capsule-item:hover {
  background: var(--bg-capsule-hover);
  border-color: var(--border-card);
}

.host-capsule-item.drag-target-before {
  border-top: 2px solid var(--color-primary) !important;
}

.host-capsule-item.drag-target-after {
  border-bottom: 2px solid var(--color-primary) !important;
}

.host-capsule-item.is-dragging {
  opacity: 0.4;
}

.capsule-pillar {
  width: 3px;
  height: 14px;
  border-radius: 2px;
  background: var(--color-primary);
}

.capsule-icon {
  color: var(--text-sub);
}

.capsule-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-main);
}

/* 中栏：单一纯粹终端圆角大卡片 (与主题背景与边框精准契合，强制 GPU 图层圆角裁剪) */
.center-terminal-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  background-color: var(--bg-card);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-card);
  padding: 0 !important;
  margin: 0 !important;
  gap: 0 !important;
  overflow: hidden !important;
  transform: translateZ(0); /* 强制开启 GPU 独立渲染图层，解决硬件加速穿透导致的直角闪烁 */
  isolation: isolate;
  box-sizing: border-box;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.05), 0 4px 14px rgba(15, 23, 42, 0.05);
}

[data-theme="light"] .center-terminal-card {
  background-color: var(--bg-card);
  border: 1px solid var(--border-card);
}

.terminal-tab-bar {
  height: 36px;
  min-height: 36px;
  background: var(--bg-card);
  border-bottom: 1px solid var(--border-card);
  border-top-left-radius: calc(var(--radius-card) - 1px);
  border-top-right-radius: calc(var(--radius-card) - 1px);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px;
  margin: 0;
  box-sizing: border-box;
}

[data-theme="light"] .terminal-tab-bar {
  background: var(--bg-card);
  border-bottom: 1px solid var(--border-card);
}

.tab-list {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow-x: auto;
}

.term-tab {
  height: 26px;
  min-height: 26px;
  max-height: 26px;
  padding: 0 8px 0 10px;
  background: var(--bg-capsule);
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-main);
  cursor: pointer;
  border: 1px solid var(--border-capsule);
  transition: all 0.15s ease;
  user-select: none;
}

[data-theme="light"] .term-tab {
  background: #DFE5EE;
  border: 1px solid #D2D8E4;
  color: #1A1C1E;
}

[data-theme="light"] .term-tab:hover {
  background: #D5DDE8;
  border-color: #CBD5E1;
}

.term-tab.active {
  background: var(--color-primary);
  color: var(--color-on-primary);
  border-color: var(--color-primary);
  font-weight: bold;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
}

[data-theme="light"] .term-tab.active {
  background: var(--color-primary);
  color: #FFFFFF;
  border-color: var(--color-primary);
}

.term-tab.locked {
  border-color: rgba(229, 193, 88, 0.4);
}

.term-tab.is-tab-dragging {
  opacity: 0.38;
  transform: scale(0.96);
  cursor: grabbing !important;
}

.term-tab.is-tab-drag-over {
  border-color: var(--color-primary) !important;
  box-shadow: 0 0 0 2px var(--color-primary), 0 2px 8px rgba(0, 0, 0, 0.2) !important;
  transform: translateY(-1.5px);
}

.tab-title {
  display: inline-flex;
  align-items: center;
  line-height: 1;
  transform: translateY(-1px);
}

.tab-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex-shrink: 0;
  transform: translateY(-0.5px);
}

.tab-dot.online { background: #48BB78; box-shadow: 0 0 6px #48BB78; }
.tab-dot.offline { background: #F28B82; }

/* 1:1 对标 CustomTabCloseButton: 16px × 16px 精致微型控制钮 */
.custom-tab-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  min-width: 16px;
  min-height: 16px;
  border-radius: 4px;
  color: inherit;
  font-size: 10px;
  line-height: 1;
  padding: 0;
  margin: 0;
  cursor: pointer;
  transition: all 0.15s ease;
  flex-shrink: 0;
}

.custom-tab-btn .btn-close-x {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
  font-size: 10px;
  transform: translateY(-0.5px);
}

.custom-tab-btn.btn-close:hover {
  background: #BA1A1A;
  color: #FFFFFF;
}

/* 标签页加锁：1:1 对标 ssh8.py CustomTabCloseButton 配色与交互 */
.custom-tab-btn.btn-lock {
  width: auto;
  height: auto;
  min-width: 0;
  min-height: 0;
  color: #C4C6D0; /* 暗色非激活: text_muted */
  opacity: 0.85;
  transition: all 0.15s ease;
}

.term-tab.active .custom-tab-btn.btn-lock {
  color: var(--color-on-primary) !important; /* 激活时: on_primary 高对比 */
  opacity: 1 !important;
}

/* 亮色模式适配 (Light Theme) */
[data-theme="light"] .custom-tab-btn.btn-lock {
  color: #55555A !important; /* 亮色非激活: text_muted */
  opacity: 0.85 !important;
}

[data-theme="light"] .term-tab.active .custom-tab-btn.btn-lock {
  color: #FFFFFF !important; /* 亮色激活（深蓝背景上）: 纯白高对比 */
  opacity: 1 !important;
}

.custom-tab-btn.btn-lock:hover {
  opacity: 1 !important;
  background: rgba(255, 255, 255, 0.12);
  border-radius: 4px;
}

[data-theme="light"] .custom-tab-btn.btn-lock:hover {
  background: rgba(0, 0, 0, 0.08);
}

[data-theme="light"] .term-tab.active .custom-tab-btn.btn-lock:hover {
  background: rgba(255, 255, 255, 0.18);
}

.tab-actions {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

/* 状态徽标：高度26px, 宽度94px, 圆角6px */
.terminal-latency-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 26px;
  min-height: 26px;
  max-height: 26px;
  width: 94px;
  min-width: 94px;
  max-width: 94px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  box-sizing: border-box;
  user-select: none;
  white-space: nowrap;
  flex-shrink: 0;
  transition: all 0.2s ease;
}

.terminal-latency-badge .badge-dot {
  width: 6px;
  height: 6px;
  min-width: 6px;
  min-height: 6px;
  border-radius: 50%;
  flex-shrink: 0;
  display: inline-block;
  animation: dotPulseGlow 1.8s ease-in-out infinite;
}

@keyframes dotPulseGlow {
  0%, 100% {
    transform: scale(1);
    opacity: 0.9;
  }
  50% {
    transform: scale(1.25);
    opacity: 1;
  }
}

/* --- 终端指示器配色规范 ---
   离线: 红色
   低于 150ms: 绿色
   高于 150ms 低于等于 250ms: 黄色
   高于 250ms: 橙色
   测速中: 浅蓝中性
*/

/* 1. 离线 (红色) */
.terminal-latency-badge.status-offline {
  background: rgba(64, 18, 22, 0.78);
  border: 1px solid rgba(220, 38, 38, 0.75);
  color: #FCA5A5 !important;
}
.terminal-latency-badge.status-offline .badge-dot {
  background: #EF4444;
  box-shadow: 0 0 6px #EF4444;
}
[data-theme="light"] .terminal-latency-badge.status-offline {
  background: #FEE2E2;
  border: 1px solid #FCA5A5;
  color: #B91C1C !important;
}
[data-theme="light"] .terminal-latency-badge.status-offline .badge-dot {
  background: #DC2626;
  box-shadow: 0 0 6px rgba(220, 38, 38, 0.45);
}

/* 2. 低于 150ms (绿色) */
.terminal-latency-badge.status-green {
  background: rgba(16, 50, 30, 0.78);
  border: 1px solid rgba(34, 197, 94, 0.75);
  color: #86EFAC !important;
}
.terminal-latency-badge.status-green .badge-dot {
  background: #22C55E;
  box-shadow: 0 0 6px #22C55E;
}
[data-theme="light"] .terminal-latency-badge.status-green {
  background: #DCFCE7;
  border: 1px solid #86EFAC;
  color: #15803D !important;
}
[data-theme="light"] .terminal-latency-badge.status-green .badge-dot {
  background: #16A34A;
  box-shadow: 0 0 6px rgba(22, 163, 74, 0.45);
}

/* 3. 高于 150ms 且低于等于 250ms (黄色) */
.terminal-latency-badge.status-yellow {
  background: rgba(60, 48, 12, 0.82);
  border: 1px solid rgba(234, 179, 8, 0.75);
  color: #FDE047 !important;
}
.terminal-latency-badge.status-yellow .badge-dot {
  background: #EAB308;
  box-shadow: 0 0 6px #EAB308;
}
[data-theme="light"] .terminal-latency-badge.status-yellow {
  background: #FEF9C3;
  border: 1px solid #FDE047;
  color: #A16207 !important;
}
[data-theme="light"] .terminal-latency-badge.status-yellow .badge-dot {
  background: #CA8A04;
  box-shadow: 0 0 6px rgba(202, 138, 4, 0.45);
}

/* 4. 高于 250ms (橙色) */
.terminal-latency-badge.status-orange {
  background: rgba(64, 32, 12, 0.82);
  border: 1px solid rgba(249, 115, 22, 0.75);
  color: #FDBA74 !important;
}
.terminal-latency-badge.status-orange .badge-dot {
  background: #F97316;
  box-shadow: 0 0 6px #F97316;
}
[data-theme="light"] .terminal-latency-badge.status-orange {
  background: #FFEDD5;
  border: 1px solid #FDBA74;
  color: #C2410C !important;
}
[data-theme="light"] .terminal-latency-badge.status-orange .badge-dot {
  background: #EA580C;
  box-shadow: 0 0 6px rgba(234, 88, 12, 0.45);
}

/* 5. 刚连接测速中 (中性青蓝) */
.terminal-latency-badge.status-measuring {
  background: rgba(20, 36, 48, 0.76);
  border: 1px solid rgba(56, 189, 248, 0.6);
  color: #BAE6FD !important;
}
.terminal-latency-badge.status-measuring .badge-dot {
  background: #38BDF8;
  box-shadow: 0 0 6px #38BDF8;
}
[data-theme="light"] .terminal-latency-badge.status-measuring {
  background: #E0F2FE;
  border: 1px solid #BAE6FD;
  color: #0369A1 !important;
}
[data-theme="light"] .terminal-latency-badge.status-measuring .badge-dot {
  background: #0284C7;
  box-shadow: 0 0 6px rgba(2, 132, 199, 0.45);
}

.btn-danger-disconnect {
  height: 28px;
  min-height: 28px;
  max-height: 28px;
  padding: 0 14px;
  font-size: 12px;
  font-weight: 600;
  background-color: #8C2A30 !important;
  color: #FFFFFF !important;
  border: 1px solid #A33840 !important;
  border-radius: var(--radius-btn);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(140, 42, 48, 0.2);
  white-space: nowrap;
}

.btn-danger-disconnect:hover {
  background-color: #A3343C !important;
  border-color: #B5424B !important;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(140, 42, 48, 0.3);
}

.btn-danger-disconnect:active {
  background-color: #722026 !important;
  border-color: #722026 !important;
  transform: translateY(0);
}

[data-theme="light"] .btn-danger-disconnect {
  background-color: #B83A41 !important;
  color: #FFFFFF !important;
  border: 1px solid #A82E35 !important;
  box-shadow: 0 1px 3px rgba(184, 58, 65, 0.2);
}

[data-theme="light"] .btn-danger-disconnect:hover {
  background-color: #C8464E !important;
  border-color: #B83A41 !important;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(184, 58, 65, 0.3);
}

/* =========================================================================
   1:1 对标 ssh8.py XTERM_TERMINAL_HTML: 终端容器底色直通与动态自定义背景
   ========================================================================= */
.terminal-viewport {
  flex: 1;
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden !important;
  border: none !important;
  border-radius: 0 !important;
  border-bottom-left-radius: calc(var(--radius-card) - 1px) !important;
  border-bottom-right-radius: calc(var(--radius-card) - 1px) !important;
  padding: 0 !important;
  margin: 0 !important;
  box-sizing: border-box;
  background-color: transparent !important;
  transform: translateZ(0);
}

[data-theme="light"] .terminal-viewport {
  background-color: transparent !important;
  border: none !important;
  padding: 0 !important;
}

.empty-state {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  user-select: none;
  pointer-events: none;
}

.empty-icon-wrap {
  width: 144px;
  height: 144px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 4px;
  opacity: 0.92;
  transition: opacity 0.25s ease;
}

.empty-desktop-icon {
  width: 128px;
  height: 128px;
}

.empty-desktop-icon .svg-stroke {
  stroke: var(--text-title);
  opacity: 0.65;
}

.empty-desktop-icon .svg-screen {
  fill: var(--text-title);
  opacity: 0.05;
  stroke: var(--text-title);
  stroke-width: 1.5;
  stroke-dasharray: 2 2;
}

.empty-desktop-icon .svg-symbol {
  stroke: var(--primary-accent, #38BDF8);
  opacity: 0.9;
}

.empty-title { font-size: 15px; font-weight: 600; color: var(--text-title); letter-spacing: 0.3px; }
.empty-hint { font-size: 12.5px; color: var(--text-sub); }

/* 挂载容器：绝对定位 100% 充满视口。通过 visibility/z-index 切换，杜绝 display:none 导致 PTY 尺寸塌陷吞字 */
.terminal-mount-box {
  position: absolute !important;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 0 !important;
  margin: 0 !important;
  border: none !important;
  border-radius: 0 !important;
  border-bottom-left-radius: calc(var(--radius-card) - 1px) !important;
  border-bottom-right-radius: calc(var(--radius-card) - 1px) !important;
  outline: none !important;
  box-shadow: none !important;
  overflow: hidden !important;
  box-sizing: border-box;
  background-color: #0A0B0E;
  visibility: hidden;
  opacity: 0;
  pointer-events: none;
  z-index: 1;
}

.terminal-mount-box.is-active {
  visibility: visible;
  opacity: 1;
  pointer-events: auto;
  z-index: 2;
}

/* xterm.js 核心容器：直通挂载容器底色，100% 填充满容器，继承圆角遮罩 */
.terminal-mount-box .xterm {
  height: 100% !important;
  width: 100% !important;
  padding: 4px 6px !important;
  margin: 0 !important;
  border: none !important;
  border-radius: 0 !important;
  border-bottom-left-radius: calc(var(--radius-card) - 1px) !important;
  border-bottom-right-radius: calc(var(--radius-card) - 1px) !important;
  box-sizing: border-box !important;
  background-color: transparent !important;
  position: relative;
  overflow: hidden !important;
}

.terminal-mount-box .xterm-viewport {
  background-color: transparent !important;
  overflow-y: auto !important;
  border-radius: 0 !important;
  border-bottom-left-radius: calc(var(--radius-card) - 1px) !important;
  border-bottom-right-radius: calc(var(--radius-card) - 1px) !important;
}

.terminal-mount-box .xterm-screen {
  background-color: transparent !important;
  padding: 0 !important;
  box-sizing: border-box;
}

/* =========================================================================
   1:1 对标 ssh8.py 光标闪烁关键帧动画与频率节奏接管 (xterm 6)
   - 闪烁频率由 --ssh-cursor-blink-cycle 动态变量精准驱动
   - 支持 block (背景显隐与反色) / bar (阴影交替) / underline (边框交替)
   - 强制覆盖 xterm 6 内部 !important 静态规则，且严格限定在 .xterm-cursor 节点
   ========================================================================= */
@keyframes ssh-manager-cursor-block-blink {
  0%, 49.999% {
    background-color: var(--ssh-cursor-color, #81C995);
    color: var(--ssh-cursor-accent, #0A0B0E);
  }
  50%, 100% {
    background-color: transparent;
    color: var(--ssh-cursor-color, #81C995);
  }
}

@keyframes ssh-manager-cursor-bar-blink {
  0%, 49.999% { box-shadow: var(--ssh-cursor-bar-shadow, 1px 0 0 #81C995 inset); }
  50%, 100% { box-shadow: none; }
}

@keyframes ssh-manager-cursor-underline-blink {
  0%, 49.999% { border-bottom-style: solid; }
  50%, 100% { border-bottom-style: hidden; }
}

/* 覆盖 xterm 6 的默认 1s 动画与静态 !important 规则 */
.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor {
  animation-duration: var(--ssh-cursor-blink-cycle, 1060ms) !important;
  animation-timing-function: steps(1, end) !important;
  animation-iteration-count: infinite !important;
  animation-delay: 0ms !important;
}

.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-block,
.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-block.xterm-cursor-blink,
.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-block:not(.xterm-cursor-blink) {
  animation-name: ssh-manager-cursor-block-blink !important;
}

.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-bar,
.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-bar.xterm-cursor-blink {
  animation-name: ssh-manager-cursor-bar-blink !important;
}

.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-underline,
.terminal-mount-box .xterm.ssh-cursor-blink-enabled .xterm-rows .xterm-cursor.xterm-cursor-underline.xterm-cursor-blink {
  animation-name: ssh-manager-cursor-underline-blink !important;
  border-bottom-width: 1px !important;
  transform: scale(1.333333, 1.25);
  transform-origin: left bottom;
}

.terminal-mount-box .xterm.ssh-cursor-blink-disabled .xterm-rows .xterm-cursor {
  animation: none !important;
}










/* 右栏：独立圆角大卡片 (SFTP 与 备忘录) */

/* 右栏：独立圆角大卡片 (SFTP 与 备忘录) */
.right-panel-card {
  width: 250px;
  min-width: 250px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  background: var(--bg-card);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-card);
  transition: background-color 0.25s ease;
  overflow: hidden;
  box-sizing: border-box;
}

.right-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 14px;
}

.right-card-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--text-title);
  letter-spacing: normal;
}

.sftp-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--bg-card);
}

/* 顶部快捷路径导航栏 (上一级 + 路径 + 跳转) */
.sftp-nav-bar {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 8px 10px;
  box-sizing: border-box;
  width: 100%;
}

.btn-sftp-action {
  height: 28px;
  padding: 0 8px;
  background: var(--color-primary);
  border: none;
  border-radius: var(--radius-btn);
  color: var(--color-on-primary);
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  flex-shrink: 0;
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.btn-sftp-action:hover {
  background: var(--color-primary-hover);
}

.sftp-path-box {
  flex: 1;
  min-width: 50px;
  height: 28px;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: var(--radius-btn);
  padding: 0 6px;
  font-size: 12px;
  color: var(--text-main);
  outline: none;
  box-sizing: border-box;
}

/* 表头：名称与大小与权限 (支持拖拽调节宽度) */
.sftp-table-header {
  display: flex;
  align-items: center;
  padding: 6px 10px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-sub);
  border-bottom: 1px solid var(--border-card);
  user-select: none;
}

.col-name {
  position: relative;
  display: flex;
  align-items: center;
  flex-shrink: 0;
  min-width: 40px;
}

.col-size {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex-shrink: 0;
  min-width: 35px;
  padding-right: 6px;
  text-align: right;
}

.col-perm {
  flex: 1;
  text-align: right;
  min-width: 64px;
}

.col-resizer {
  position: absolute;
  top: 0;
  right: -6px;
  width: 12px;
  bottom: 0;
  cursor: col-resize;
  z-index: 2;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent !important;
}

/* 双排点阵把手：常驻显性 2 列 × 3 行精致对齐圆点 (Double-row Grip Dots) */
.resizer-dots {
  width: 6px;
  height: 12px;
  display: block;
  background-image: radial-gradient(circle, var(--text-sub) 1px, transparent 1px);
  background-size: 3px 4px;
  background-repeat: repeat;
  background-position: center;
  opacity: 0.65;
  transition: opacity 0.15s ease, filter 0.15s ease;
  pointer-events: none;
}

.col-resizer:hover .resizer-dots,
.col-resizer:active .resizer-dots {
  opacity: 1;
  background-image: radial-gradient(circle, var(--text-main) 1px, transparent 1px);
}

.sftp-file-list {
  flex: 1;
  overflow-y: auto;
  padding: 4px 6px;
}

.sftp-loading, .sftp-empty {
  text-align: center;
  padding: 40px 10px;
  font-size: 12px;
  color: var(--text-sub);
}

.file-item {
  display: flex;
  align-items: center;
  padding: 5px 8px;
  border-radius: 4px;
  cursor: pointer;
  transition: background 0.15s ease;
}

.file-item:hover {
  background: var(--bg-capsule-hover);
}

.file-item.selected {
  background: rgba(26, 86, 219, 0.15);
  border: 1px solid rgba(26, 86, 219, 0.3);
}

.f-info {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow: hidden;
  flex-shrink: 0;
  min-width: 0;
}

.f-name {
  font-size: 12px;
  color: var(--text-main);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
  min-width: 0;
}

.f-meta {
  display: flex;
  align-items: center;
  flex: 1;
  min-width: 0;
}

.f-size {
  font-size: 11px;
  color: var(--text-sub);
  flex-shrink: 0;
  text-align: right;
  padding-right: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.f-perm {
  font-size: 10px;
  font-family: Consolas, "Cascadia Mono", monospace;
  letter-spacing: -0.2px;
  color: var(--text-sub);
  flex: 1;
  text-align: right;
  opacity: 0.7;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 底部常驻双按钮 */
.sftp-bottom-bar {
  display: flex;
  gap: 8px;
  padding: 8px 10px;
  border-top: 1px solid var(--border-card);
}

.btn-sftp-footer {
  flex: 1;
  height: 32px;
  border: none;
  border-radius: var(--radius-btn);
  background: var(--color-primary);
  color: var(--color-on-primary);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  text-align: center;
  transition: all 0.15s ease;
}

.btn-sftp-footer:hover:not(:disabled) {
  background: var(--color-primary-hover);
}

.btn-sftp-footer:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* 备忘录 */
.memo-container {
  flex: 1;
  overflow-y: auto;
  padding: 6px 12px 14px 12px;
  display: flex;
  flex-direction: column;
  position: relative;
}

.memo-group-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.memo-group-header {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-main);
  padding: 4px 6px;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  border: 1px solid transparent;
  transition: all 0.15s ease;
}

.memo-group-header:hover {
  background: var(--bg-capsule-hover);
}

.memo-group-header.drag-target-before {
  border-top: 2px solid var(--color-primary) !important;
}

.memo-group-header.drag-target-after {
  border-bottom: 2px solid var(--color-primary) !important;
}

.memo-group-header.drag-target-inside {
  background: var(--bg-capsule-hover) !important;
  border: 1px dashed var(--color-primary) !important;
}

.memo-group-header.is-dragging {
  opacity: 0.4;
}

.memo-folder-icon {
  color: var(--color-primary);
  margin-right: 2px;
}

.file-item.dir .v-icon {
  color: var(--color-primary);
}

.memo-group-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-main);
}

.memo-list {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-height: 8px;
}

/* 备忘录独立圆角胶囊条 */
.memo-capsule-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 10px;
  background: var(--bg-capsule);
  border: 1px solid var(--border-capsule);
  border-radius: var(--radius-capsule);
  cursor: pointer;
  transition: all 0.15s ease;
  position: relative;
  box-sizing: border-box;
}

.memo-capsule-item:hover {
  background: var(--bg-capsule-hover);
  border-color: var(--border-card);
}

.memo-capsule-item.drag-target-before {
  border-top: 2px solid var(--color-primary) !important;
}

.memo-capsule-item.drag-target-after {
  border-bottom: 2px solid var(--color-primary) !important;
}

.memo-capsule-item.is-dragging {
  opacity: 0.4;
}

.memo-pillar {
  width: 3px;
  height: 12px;
  border-radius: 2px;
  background: var(--color-primary);
}

.memo-icon {
  color: var(--text-sub);
}

.memo-name {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-main);
  flex: 1;
}

.memo-del-icon {
  font-size: 11px;
  color: var(--text-sub);
  opacity: 0;
  transition: opacity 0.15s ease, background 0.15s ease;
  padding: 2px 4px;
  border-radius: 3px;
}

.memo-capsule-item:hover .memo-del-icon {
  opacity: 0.8;
}

.memo-del-icon:hover {
  opacity: 1;
  color: #EF4444;
  background: rgba(239, 68, 68, 0.15);
}

.btn-switch-white-pill {
  font-family: var(--app-font-family);
  height: 26px;
  padding: 0 14px;
  font-size: 12px;
  font-weight: 600;
  color: var(--color-on-primary);
  background: var(--color-primary);
  border: none;
  border-radius: var(--radius-btn);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}

.btn-switch-white-pill:hover {
  background: var(--color-primary-hover);
  transform: translateY(-1px);
}

.btn-bottom-add-pill {
  font-family: var(--app-font-family);
  width: 100%;
  height: 32px;
  background: var(--color-primary);
  color: var(--color-on-primary);
  font-size: 12px;
  font-weight: 600;
  border: none;
  border-radius: var(--radius-capsule);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  text-align: center;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.btn-bottom-add-pill:hover {
  background: var(--color-primary-hover);
  transform: translateY(-1px);
}

.btn-bottom-add-pill:active {
  background: var(--color-primary-active);
  transform: translateY(0);
}

.memo-actions {
  display: flex;
  gap: 4px;
  margin-left: 6px;
}

.btn-memo-act {
  width: 20px;
  height: 20px;
  background: transparent;
  border: none;
  color: #8E9099;
  cursor: pointer;
  font-size: 11px;
  border-radius: 3px;
}

.btn-memo-act:hover { background: #2A303F; color: #FFF; }
.btn-memo-act.danger:hover { background: #B3261E; color: #FFF; }

/* 悬浮传输监视器 (SFTPTransferMonitorPopover) */
.transfer-monitor-popover {
  position: absolute;
  top: 48px;
  right: 15px;
  width: 320px;
  background: var(--bg-card);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-card);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  z-index: 9998;
  display: flex;
  flex-direction: column;
  overflow: visible !important;
  transition: background-color 0.25s ease, border-color 0.25s ease;
}

/* 1:1 对标 ssh8.py ARROW_HEIGHT = 9, ARROW_WIDTH = 14: 气泡顶端指示性小三角 */
.transfer-monitor-popover::before {
  content: "";
  position: absolute;
  top: -8px;
  right: var(--arrow-right, 85px);
  width: 0;
  height: 0;
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  border-bottom: 8px solid var(--border-card);
  z-index: 10000;
  pointer-events: none;
}

.transfer-monitor-popover::after {
  content: "";
  position: absolute;
  top: -7px;
  right: calc(var(--arrow-right, 85px) + 1px);
  width: 0;
  height: 0;
  border-left: 7px solid transparent;
  border-right: 7px solid transparent;
  border-bottom: 7px solid var(--bg-sub-card);
  z-index: 10001;
  pointer-events: none;
}

.transfer-popover-header {
  padding: 8px 12px;
  background: var(--bg-sub-card);
  border-bottom: 1px solid var(--border-card);
  border-top-left-radius: calc(var(--radius-card) - 1px);
  border-top-right-radius: calc(var(--radius-card) - 1px);
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  font-weight: 700;
  color: var(--text-title);
}

.popover-header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.btn-popover-clear {
  height: 22px;
  padding: 0 8px;
  font-size: 11px;
  font-weight: 600;
  color: var(--color-on-primary);
  background-color: var(--color-primary);
  border: 1px solid var(--color-primary);
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.btn-popover-clear:hover:not(:disabled) {
  background-color: var(--color-primary-hover);
}

.btn-popover-clear:disabled {
  opacity: 0.45;
  cursor: not-allowed;
  filter: grayscale(40%);
}

.popover-close { cursor: pointer; color: var(--text-sub); }
.popover-close:hover { color: var(--text-main); }

.transfer-task-list {
  max-height: 260px;
  overflow-y: auto;
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  background: var(--bg-card);
  border-bottom-left-radius: calc(var(--radius-card) - 1px);
  border-bottom-right-radius: calc(var(--radius-card) - 1px);
}

.no-task {
  text-align: center;
  padding: 16px;
  font-size: 11px;
  color: var(--text-sub);
}

.transfer-task-item {
  background: var(--bg-capsule);
  border: 1px solid var(--border-capsule);
  border-radius: var(--radius-btn);
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.task-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
}

.task-badge {
  padding: 1px 4px;
  border-radius: 3px;
  font-size: 9px;
  font-weight: 700;
}

.task-badge.up { background: rgba(120, 217, 236, 0.2); color: #78D9EC; }
.task-badge.down { background: rgba(129, 201, 149, 0.2); color: #81C995; }

.task-name {
  flex: 1;
  margin: 0 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #E2E2E9;
}

.task-speed { font-size: 10px; color: #FDD663; font-family: monospace; }

.task-progress-bar {
  height: 5px;
  background: #252A37;
  border-radius: 3px;
  overflow: hidden;
}

.task-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #78D9EC, #A8C7FA);
  border-radius: 3px;
  transition: width 0.2s;
}

.task-status-row {
  display: flex;
  justify-content: space-between;
  font-size: 10px;
  color: #8E9099;
}

.status-tag.completed { color: #81C995; font-weight: 600; }
.status-tag.failed { color: #F28B82; font-weight: 600; }
.status-tag.running { color: #78D9EC; }

/* 视图 2：主机管理大盘 */
.mgmt-view {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  background: transparent;
  position: relative;
  z-index: 1;
}

.mgmt-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.mgmt-title { font-size: 18px; font-weight: 700; color: var(--text-main); }
.mgmt-sub { font-size: 12px; color: var(--text-sub); }

.btn-add-host {
  height: 30px;
  padding: 0 16px;
  background: var(--color-primary);
  color: var(--color-on-primary);
  border: none;
  border-radius: var(--radius-btn);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  text-align: center;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.btn-add-host:hover {
  background: var(--color-primary-hover);
  transform: translateY(-1px);
}

.btn-sec-act {
  height: 30px;
  padding: 0 14px;
  background: var(--color-primary);
  color: var(--color-on-primary);
  border: 1px solid var(--color-primary);
  border-radius: var(--radius-btn);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  text-align: center;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.btn-sec-act:hover:not(:disabled) {
  background: var(--color-primary-hover);
  border-color: var(--color-primary-hover);
  transform: translateY(-1px);
}

.btn-sec-act:active:not(:disabled) {
  background: var(--color-primary-active);
  transform: translateY(0);
}

.btn-sec-act:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.mgmt-cols-picker {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: var(--bg-capsule);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-btn);
  padding: 3px 6px;
}

.cols-label {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-sub);
  margin-right: 4px;
  margin-left: 4px;
}

.btn-col-choice {
  height: 26px;
  min-width: 42px;
  padding: 0 10px;
  border-radius: 5px;
  border: none;
  background: transparent;
  color: var(--text-sub);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.btn-col-choice:hover {
  color: var(--text-main);
  background: var(--bg-capsule-hover);
}

.btn-col-choice.active {
  background: var(--color-primary);
  color: var(--color-on-primary);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
}

.cards-grid {
  display: grid;
  gap: 16px;
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.cards-grid.cols-1 {
  grid-template-columns: 1fr;
}

.cards-grid.cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.cards-grid.cols-3 {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.cards-grid.cols-4 {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

/* 响应式兜底适配 */
@media (max-width: 1400px) {
  .cards-grid.cols-4 {
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  }
}

.host-card {
  position: relative;
  background: var(--bg-card);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-card);
  overflow: hidden;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4), 0 8px 24px rgba(0, 0, 0, 0.35);
  transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.2s, box-shadow 0.2s;
}

[data-theme="light"] .host-card {
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06), 0 3px 12px rgba(0, 0, 0, 0.05);
}

.host-card:hover {
  transform: translateY(-2px);
  border-color: #79747E;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.45), 0 12px 32px rgba(0, 0, 0, 0.4);
}

[data-theme="light"] .host-card:hover {
  border-color: #85858E;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.09);
}

/* 拖拽排序交互视觉反馈 */
.host-card.is-dragging {
  opacity: 0.45;
  transform: scale(0.98);
  border-style: dashed;
  border-color: var(--color-primary);
  cursor: grabbing;
}

.host-card.is-drag-over {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px var(--color-primary), 0 8px 20px rgba(0, 0, 0, 0.25);
  transform: translateY(-4px);
}

/* 通知点击高亮：边框平缓呼吸灯，循环3次 (每轮 1.6s，总计 4.8s) */
.host-card.breathing-highlight {
  animation: cardBreathingGlow 1.6s cubic-bezier(0.4, 0, 0.2, 1) 3;
  z-index: 10;
  position: relative;
}

@keyframes cardBreathingGlow {
  0% {
    border-color: var(--border-card);
    box-shadow: 0 0 0 0 rgba(32, 87, 166, 0), 0 2px 6px rgba(0, 0, 0, 0.08);
    transform: translateY(0);
  }
  50% {
    border-color: var(--color-primary);
    box-shadow: 
      0 0 0 3px color-mix(in srgb, var(--color-primary) 55%, transparent),
      0 0 22px 6px color-mix(in srgb, var(--color-primary) 40%, transparent),
      0 8px 24px rgba(0, 0, 0, 0.16);
    transform: translateY(-2px);
  }
  100% {
    border-color: var(--border-card);
    box-shadow: 0 0 0 0 rgba(32, 87, 166, 0), 0 2px 6px rgba(0, 0, 0, 0.08);
    transform: translateY(0);
  }
}

.card-pillar {
  position: absolute;
  top: 0; left: 0; bottom: 0;
  width: 4px;
  background: var(--color-primary);
}

.card-body {
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.card-row1 {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-name { font-size: 14px; font-weight: 700; color: var(--text-title); }
.card-latency {
  font-size: 11px;
  font-family: monospace;
  color: #48BB78;
  background: rgba(72, 187, 120, 0.12);
  padding: 2px 6px;
  border-radius: 4px;
}

.card-addr { font-size: 12px; color: var(--text-sub); }

.card-meta {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4px;
  font-size: 11px;
  color: var(--text-sub);
}

.traffic-section {
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin-top: 4px;
}

.traffic-label {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  color: var(--text-main);
  line-height: 1.2;
}

.traffic-text-main {
  font-size: 11px;
  font-weight: 500;
  color: var(--text-main);
}

.traffic-audit-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  height: 22px;
  padding: 0 8px;
  border-radius: var(--radius-btn, 6px);
  border: 1px solid rgba(56, 189, 248, 0.3);
  background: rgba(56, 189, 248, 0.08);
  color: #38BDF8;
  font-size: 11px;
  font-weight: 600;
  font-family: inherit;
  line-height: 1;
  letter-spacing: 0.2px;
  cursor: pointer;
  box-sizing: border-box;
  white-space: nowrap;
  outline: none;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  -webkit-font-smoothing: antialiased;
}

.traffic-audit-btn .audit-icon {
  font-size: 11px;
  line-height: 1;
  opacity: 0.9;
  transition: transform 0.25s ease;
}

.traffic-audit-btn:hover {
  background: rgba(56, 189, 248, 0.18);
  border-color: rgba(56, 189, 248, 0.55);
  color: #7DD3FC;
  transform: translateY(-1px);
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.25);
}

.traffic-audit-btn:hover .audit-icon {
  transform: rotate(45deg);
}

.traffic-audit-btn:active {
  transform: translateY(0);
  background: rgba(56, 189, 248, 0.25);
}

/* 日间模式：精细微立体胶囊按钮，深蓝字样与微描边，杜绝发虚并与卡片整体质感呼应 */
[data-theme="light"] .traffic-audit-btn {
  background: #EFF6FF;
  border-color: #BFDBFE;
  color: #1D4ED8;
  box-shadow: 0 1px 2px rgba(29, 78, 216, 0.06);
}

[data-theme="light"] .traffic-audit-btn:hover {
  background: #DBEAFE;
  border-color: #93C5FD;
  color: #1E40AF;
  box-shadow: 0 2px 4px rgba(29, 78, 216, 0.12);
}

[data-theme="light"] .traffic-audit-btn:active {
  background: #BFDBFE;
}

.card-latency.is-tcp {
  color: #60A5FA;
  background: rgba(96, 165, 250, 0.15);
  border: 1px solid rgba(96, 165, 250, 0.3);
}

.card-latency.is-icmp {
  color: #38BDF8;
  background: rgba(56, 189, 248, 0.15);
  border: 1px solid rgba(56, 189, 248, 0.3);
}

.card-latency.is-err {
  color: #F87171;
  background: rgba(248, 113, 113, 0.15);
  border: 1px solid rgba(248, 113, 113, 0.3);
}

/* 统一设计规范的进度条系统 (高度 16px、圆角 8px、文字居中清晰) */
.unified-traffic-bar {
  position: relative;
  height: 16px;
  border-radius: 8px;
  background: var(--bg-track);
  border: 1px solid var(--border-card);
  overflow: hidden;
  display: flex;
  align-items: center;
}

.unified-traffic-fill {
  height: 100%;
  border-radius: 7px;
  background: linear-gradient(90deg, #0284C7, #38BDF8);
  transition: width 0.35s ease;
}

.unified-traffic-fill.warn {
  background: linear-gradient(90deg, #D97706, #FBBF24);
}

.unified-traffic-fill.danger {
  background: linear-gradient(90deg, #DC2626, #F87171);
}

.unified-traffic-pct {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 700;
  font-family: Consolas, monospace;
  color: #FFFFFF;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.85);
  line-height: 1;
  pointer-events: none;
  z-index: 2;
}

/* 无限流量流光条 (平滑无限循环、自适应日间/夜间配色) */
.unified-traffic-bar.infinite {
  background: #181C26;
  justify-content: center;
  border-color: rgba(56, 189, 248, 0.25);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.2);
}

.infinite-flow {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  width: 100%;
  height: 100%;
  background-image: repeating-linear-gradient(
    45deg,
    rgba(56, 189, 248, 0.22) 0,
    rgba(56, 189, 248, 0.22) 10px,
    transparent 10px,
    transparent 20px
  );
  background-size: 28.284px 28.284px;
  animation: seamlessStripe 1s linear infinite;
}

@keyframes seamlessStripe {
  0% {
    background-position: 0 0;
  }
  100% {
    background-position: 28.284px 0;
  }
}

.infinity-badge {
  position: relative;
  z-index: 2;
  font-size: 10px;
  font-weight: 700;
  color: #38BDF8;
  letter-spacing: 0.5px;
  line-height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.85);
}

/* 日间模式：内嵌式微凹灰底槽，搭配雅致中性斜纹流动，色彩沉稳且不与白卡片突兀冲撞 */
[data-theme="light"] .unified-traffic-bar.infinite {
  background: #E8E8ED;
  border-color: #D2D2D8;
  box-shadow: inset 0 1px 2.5px rgba(0, 0, 0, 0.08);
}

[data-theme="light"] .infinite-flow {
  background-image: repeating-linear-gradient(
    45deg,
    rgba(140, 145, 160, 0.18) 0,
    rgba(140, 145, 160, 0.18) 10px,
    transparent 10px,
    transparent 20px
  );
}

[data-theme="light"] .infinity-badge {
  color: #3C4252;
  text-shadow: none;
  font-weight: 700;
}

.card-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 10px;
}

.card-actions-left {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
  flex: 1;
  min-width: 0;
}

.card-actions-right {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex-shrink: 0;
  margin-left: auto;
}

/* 统一卡片操作按钮：以 SFTP 传输按钮为模板的统一视觉设计，统一宽度与厚度 */
.btn-card-act {
  height: 28px;
  min-width: 68px;
  padding: 0 10px;
  font-size: 11px;
  font-weight: 600;
  border-radius: var(--radius-btn);
  border: 1px solid var(--color-primary);
  background: var(--color-primary);
  color: var(--color-on-primary);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  white-space: nowrap;
  gap: 4px;
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
}

.btn-card-act:hover {
  background: var(--color-primary-hover);
  border-color: var(--color-primary-hover);
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
}

.btn-card-act:active {
  background: var(--color-primary-active);
  transform: translateY(0);
}

/* 打开 SSH: 突出主操作 */
.btn-card-act.btn-ssh {
  font-weight: 700;
}

/* 危险删除按钮：克制雅致的非鲜红配色，同时适配深浅主题 */
.btn-card-act.btn-del,
.btn-del,
.btn-danger {
  height: 28px;
  padding: 0 16px;
  border-radius: var(--radius-btn);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  background: #933339 !important;
  border: 1px solid #A33D44 !important;
  color: #FFFFFF !important;
  box-shadow: 0 1px 3px rgba(147, 51, 57, 0.2);
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

.btn-card-act.btn-del:hover,
.btn-del:hover,
.btn-danger:hover {
  background: #A83C44 !important;
  border-color: #B8474F !important;
  transform: translateY(-1px);
}

.btn-card-act.btn-del:active,
.btn-del:active,
.btn-danger:active {
  background: #7D292E !important;
  border-color: #7D292E !important;
  transform: translateY(0);
}

[data-theme="light"] .btn-card-act.btn-del,
[data-theme="light"] .btn-del,
[data-theme="light"] .btn-danger {
  background: #C24148 !important;
  border-color: #B3343B !important;
  color: #FFFFFF !important;
}

[data-theme="light"] .btn-card-act.btn-del:hover,
[data-theme="light"] .btn-del:hover,
[data-theme="light"] .btn-danger:hover {
  background: #D14D54 !important;
  border-color: #C24148 !important;
}

/* 编辑主机弹窗专有排版样式 */
.modal-host-edit {
  width: 560px !important;
  max-height: 85vh;
}

.modal-scrollable {
  overflow-y: auto;
  max-height: calc(85vh - 100px);
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.form-section-card {
  background: rgba(255, 255, 255, 0.025);
  border: 1px solid var(--border-card);
  border-radius: 8px;
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

[data-theme="light"] .form-section-card {
  background: #F8F9FC;
  border-color: #E2E4E9;
}

.modal-section-title {
  font-size: 12px;
  font-weight: 700;
  color: var(--color-primary);
  display: flex;
  align-items: center;
  gap: 6px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
  padding-bottom: 6px;
  margin-bottom: 2px;
  letter-spacing: 0.5px;
}

.section-title-icon {
  font-size: 8px;
  color: var(--color-primary);
}

.field-col {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 0;
}

.grid-host-port {
  display: grid;
  grid-template-columns: 1fr 75px;
  gap: 12px;
  align-items: start;
}

.grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  align-items: start;
}

.grid-3 {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 12px;
  align-items: start;
}

.text-center {
  text-align: center;
}

.label-with-addon {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.input-combined-row {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
}

.w-28 {
  width: 110px !important;
  flex-shrink: 0;
}

.w-24 {
  width: 85px !important;
  flex-shrink: 0;
}

.w-20 {
  width: 72px !important;
  flex-shrink: 0;
}

.infinite-addon-check {
  margin-left: 2px;
  flex-shrink: 0;
  white-space: nowrap;
  font-size: 12px;
  cursor: pointer;
  user-select: none;
}

.reset-time-row {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: var(--radius-btn);
  padding: 4px 10px;
}

.reset-day-input {
  width: 60px !important;
  height: 28px !important;
  padding: 0 4px !important;
}

.reset-digit-input {
  width: 50px !important;
  height: 28px !important;
  padding: 0 4px !important;
}

.time-prefix, .time-suffix, .time-colon {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-main);
}

.time-hint {
  font-size: 11px;
  color: var(--text-sub);
  margin-left: 4px;
}

.btn-sec-act.btn-browse {
  height: 32px;
  padding: 0 14px;
  font-size: 12px;
  font-weight: 600;
  background: var(--bg-capsule);
  border: 1px solid var(--border-input);
  border-radius: var(--radius-btn);
  color: var(--text-main);
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.15s ease;
  flex-shrink: 0;
}

.btn-sec-act.btn-browse:hover {
  background: var(--bg-capsule-hover);
  color: #FFFFFF;
  border-color: var(--color-primary);
}

/* 全局拟态右键菜单 */
.context-menu {
  position: fixed;
  z-index: 9999;
  background: #1E212B;
  border: 1px solid #333846;
  border-radius: 8px;
  padding: 4px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
  min-width: 170px;
}

.menu-item {
  padding: 6px 12px;
  font-size: 12px;
  color: #E2E2E9;
  border-radius: 4px;
  cursor: pointer;
  transition: background 0.15s;
}

.menu-item:hover { background: #2D3342; color: #78D9EC; }
.menu-item.danger:hover { background: #B3261E; color: #FFF; }
.menu-item.disabled {
  color: #555A68 !important;
  cursor: not-allowed !important;
}
.menu-item.disabled:hover {
  background: transparent !important;
  color: #555A68 !important;
}
.menu-divider { height: 1px; background: #2E3340; margin: 4px 0; }

/* 模态弹窗系统 (完全绑定 Dark / Light 模板) */
.modal-overlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

.modal-card {
  width: 480px;
  background: var(--bg-modal);
  border: 1px solid var(--border-card);
  border-radius: var(--radius-card);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.4);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  transition: background-color 0.25s ease, border-color 0.25s ease;
}

.modal-card.modal-small {
  width: 380px;
}

.confirm-modal-body {
  padding: 20px 18px !important;
}

.confirm-modal-text {
  margin: 0;
  font-size: 13px;
  line-height: 1.6;
  color: var(--text-main);
  word-break: break-word;
}

.modal-header {
  height: 44px;
  padding: 0 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: var(--bg-card);
  border-bottom: 1px solid var(--border-card);
}

.modal-title { font-size: 13px; font-weight: 700; color: var(--text-title); }
.modal-close { font-size: 14px; color: var(--text-sub); cursor: pointer; padding: 4px; transition: color 0.15s; }
.modal-close:hover { color: var(--text-main); }

.modal-body {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: var(--bg-modal);
}

.form-row { display: flex; flex-direction: column; gap: 5px; }
.form-row.grid-host-port {
  display: grid !important;
  grid-template-columns: 1fr 75px !important;
  gap: 12px;
  align-items: start;
}
.form-row.grid-2 {
  display: grid !important;
  grid-template-columns: 1fr 1fr !important;
  gap: 12px;
  align-items: start;
}
.form-row.grid-3 {
  display: grid !important;
  grid-template-columns: 1fr 1fr 1fr !important;
  gap: 12px;
  align-items: start;
}
.form-row label { font-size: 11px; color: var(--text-sub); }

.field-hint {
  font-size: 10px;
  line-height: 1.55;
  color: var(--text-sub);
  opacity: 0.9;
}

.field-hint code {
  font-family: Consolas, monospace;
  color: var(--color-primary);
  background: rgba(120, 217, 236, 0.08);
  padding: 0 3px;
  border-radius: 3px;
}

.traffic-manual-check {
  margin-top: 2px;
  font-size: 11px;
  line-height: 1.5;
}

.modal-input {
  height: 32px;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: var(--radius-btn);
  padding: 0 10px;
  font-size: 12px;
  color: var(--text-main);
  outline: none;
  width: 100%;
  box-sizing: border-box;
  transition: border-color 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease;
}

select,
select.modal-input,
select.sftp-quick-select {
  appearance: none !important;
  -webkit-appearance: none !important;
  -moz-appearance: none !important;
  background-color: var(--bg-input) !important;
  border: 1px solid var(--border-input) !important;
  border-radius: var(--radius-btn) !important;
  color: var(--text-main) !important;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2378D9EC' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E") !important;
  background-repeat: no-repeat !important;
  background-position: right 10px center !important;
  padding-right: 28px !important;
  cursor: pointer;
  outline: none !important;
  transition: border-color 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease;
}

[data-theme="light"] select,
[data-theme="light"] select.modal-input,
[data-theme="light"] select.sftp-quick-select {
  background-color: var(--bg-input) !important;
  border-color: var(--border-input) !important;
  color: var(--text-main) !important;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%231A56DB' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E") !important;
}

select:focus,
select.modal-input:focus,
select.sftp-quick-select:focus {
  border-color: var(--color-primary) !important;
  box-shadow: 0 0 0 2px rgba(120, 217, 236, 0.15) !important;
}

select option {
  background-color: #181B22 !important;
  color: #E2E2E9 !important;
  padding: 8px 12px !important;
}

[data-theme="light"] select option {
  background-color: #FFFFFF !important;
  color: #0F172A !important;
}

input[type="checkbox"] {
  appearance: none;
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  border: 1.5px solid var(--border-input);
  background-color: var(--bg-input);
  cursor: pointer;
  vertical-align: middle;
  position: relative;
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  margin: 0;
}

input[type="checkbox"]:hover {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(120, 217, 236, 0.12);
}

input[type="checkbox"]:checked {
  background-color: var(--color-primary);
  border-color: var(--color-primary);
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%230E1626' stroke-width='3.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='20 6 9 17 4 12'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: center;
}

[data-theme="light"] input[type="checkbox"]:checked {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%23FFFFFF' stroke-width='3.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='20 6 9 17 4 12'/%3E%3C/svg%3E");
}

.modal-input:focus {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(120, 217, 236, 0.15);
}

.modal-textarea {
  height: 70px;
  padding: 6px 8px;
  resize: vertical;
  font-family: Consolas, monospace;
}

.traffic-input-box {
  display: flex;
  gap: 8px;
  align-items: center;
  width: 100%;
}
.traffic-input-box .flex-1 {
  flex: 1;
  min-width: 0;
}
.traffic-input-box .w-24 {
  width: 78px;
  flex-shrink: 0;
}

.checkbox-label {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  color: var(--text-main);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  flex-shrink: 0;
}

.prop-row {
  display: flex;
  justify-content: space-between;
  padding: 4px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.04);
  font-size: 12px;
}

.prop-row .k { color: #8E9099; }
.prop-row .v { color: #E2E2E9; font-weight: 600; }

.chmod-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}

.chmod-table th, .chmod-table td {
  padding: 8px;
  text-align: center;
  border: 1px solid #2B2F3D;
}

.chmod-table th { background: #222631; color: #C4C6D0; }

.modal-footer {
  height: 48px;
  padding: 0 16px;
  background: var(--bg-card);
  border-top: 1px solid var(--border-card);
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 10px;
}

.btn-cancel {
  height: 28px;
  padding: 0 14px;
  background: #7D292E;
  border: 1px solid #8C2F35;
  border-radius: var(--radius-btn);
  color: #FFFFFF;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
}

.btn-cancel:hover {
  background: #8E3036;
  border-color: #A33A42;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(125, 41, 46, 0.3);
}

.btn-cancel:active {
  background: #682024;
  border-color: #682024;
  transform: translateY(0);
}

[data-theme="light"] .btn-cancel {
  background: #B83A41;
  border: 1px solid #A82E35;
  color: #FFFFFF;
  box-shadow: 0 1px 3px rgba(184, 58, 65, 0.15);
}

[data-theme="light"] .btn-cancel:hover {
  background: #C8464E;
  border-color: #B83A41;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(184, 58, 65, 0.25);
}

.btn-confirm {
  height: 28px;
  padding: 0 16px;
  background: var(--btn-primary-bg);
  border: 1px solid var(--btn-primary-bg);
  border-radius: var(--radius-btn);
  color: var(--btn-primary-text);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
}

.btn-confirm:hover {
  background: var(--btn-primary-hover);
  border-color: var(--btn-primary-hover);
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
}

/* 流量统计弹窗：立即获取服务器信息 */
.traffic-sync-row {
  display: flex;
  justify-content: center;
  padding-top: 2px;
}

.traffic-sync-btn {
  height: 32px;
  min-width: 190px;
  padding: 0 22px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  background: var(--btn-primary-bg);
  border: 1px solid var(--btn-primary-bg);
  border-radius: var(--radius-btn);
  color: var(--btn-primary-text);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
}

.traffic-sync-btn:hover:not(:disabled) {
  background: var(--btn-primary-hover);
  border-color: var(--btn-primary-hover);
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
}

.traffic-sync-btn:active:not(:disabled) {
  transform: translateY(0);
}

.traffic-sync-btn:disabled {
  opacity: 0.62;
  cursor: wait;
  transform: none;
}

.traffic-sync-spinner {
  width: 12px;
  height: 12px;
  border: 2px solid currentColor;
  border-top-color: transparent;
  border-radius: 50%;
  animation: traffic-sync-spin 0.75s linear infinite;
  box-sizing: border-box;
}

@keyframes traffic-sync-spin {
  to { transform: rotate(360deg); }
}

.traffic-sync-status {
  font-size: 11px;
  line-height: 1.55;
  color: var(--text-sub);
  text-align: center;
  word-break: break-word;
}

.traffic-sync-status.is-error {
  color: #F28B82;
}

[data-theme="light"] .traffic-sync-status.is-error {
  color: #B3261E;
}

/* 偏好、备份与导入对话框扩展样式 */
.mgmt-actions-row { display: flex; align-items: center; gap: 8px; }
.btn-sec-act.flex-1 { flex: 1; text-align: center; }

.backup-section-title {
  font-size: 12px;
  font-weight: 700;
  color: var(--color-primary);
  margin-top: 4px;
}
.backup-btn-row {
  display: flex;
  gap: 8px;
}
.backup-divider {
  height: 1px;
  background: var(--border-card);
  margin: 6px 0;
}
.backup-status-text {
  padding: 8px;
  background: var(--bg-capsule);
  border-radius: var(--radius-btn);
  font-size: 11px;
  color: #48BB78;
  border: 1px solid rgba(72, 187, 120, 0.25);
  line-height: 1.4;
}

.import-list {
  max-height: 260px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 4px;
}
.import-item {
  padding: 8px 10px;
  background: var(--bg-capsule);
  border: 1px solid var(--border-capsule);
  border-radius: var(--radius-btn);
}
.import-hname { font-weight: 600; color: var(--text-main); }
.import-haddr { font-size: 11px; color: var(--text-sub); }

.search-clear {
  position: absolute;
  right: 18px;
  font-size: 11px;
  color: var(--text-sub);
  cursor: pointer;
}
.search-clear:hover { color: var(--text-main); }

/* =========================================================================
   1:1 对标 ssh8.py TerminalSettingsDialog MD3 偏好设置专用表单样式
   ========================================================================= */
.settings-modal-card {
  width: 490px;
  max-width: 95vw;
}

.settings-form-body {
  padding: 18px 24px;
  gap: 12px;
}

.settings-form-row {
  display: flex;
  align-items: center;
  min-height: 32px;
  gap: 12px;
}

.settings-form-label {
  width: 100px;
  min-width: 100px;
  font-size: 12px;
  color: var(--text-main);
  font-weight: 500;
  text-align: right;
  flex-shrink: 0;
  user-select: none;
}

.settings-form-field {
  flex: 1;
  display: flex;
  align-items: center;
}

.settings-form-field.flex-row-gap {
  gap: 10px;
}

.selected-font-preview {
  flex: 1;
  font-size: 12px;
  color: var(--color-primary);
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: var(--radius-btn);
  padding: 5px 10px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 600;
}

.w-full {
  width: 100%;
}

/* 1:1 对标 ssh8.py MD3StepSpinBox & MD3BlinkFreqSpinBox */
.md3-step-spinbox {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.md3-step-spinbox.disabled {
  opacity: 0.45;
  pointer-events: none;
}

.spin-btn {
  width: 26px;
  height: 26px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-capsule);
  color: var(--color-primary);
  border: 1px solid var(--border-input);
  border-radius: 6px;
  font-size: 14px;
  font-weight: bold;
  cursor: pointer;
  padding: 0;
  transition: all 0.15s ease;
}

.spin-btn:hover:not(:disabled) {
  background: var(--bg-capsule-hover);
  border-color: var(--color-primary);
}

.spin-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.spin-input {
  width: 56px;
  height: 26px;
  text-align: center;
  background: var(--bg-input);
  border: 1px solid var(--border-input);
  border-radius: 6px;
  color: var(--text-main);
  font-size: 12px;
  font-weight: bold;
  outline: none;
  padding: 0;
}

/* 消除浏览器原生丑陋的上下双三角加减按钮 (针对所有 number 输入框) */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

input[type="number"] {
  -moz-appearance: textfield;
}

/* 针对独立 number 输入框（如时间重置框、端口框），赋予符合 QShell 视觉语言的自绘双向调节微指示标 */
input.modal-input[type="number"]:not(.spin-input) {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='12' viewBox='0 0 10 16' fill='none'%3E%3Cpath d='M5 1L9 6H1L5 1Z' fill='%2378D9EC' opacity='0.7'/%3E%3Cpath d='M5 15L1 10H9L5 15Z' fill='%2378D9EC' opacity='0.7'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 6px center;
  padding-right: 18px !important;
}

[data-theme="light"] input.modal-input[type="number"]:not(.spin-input) {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='12' viewBox='0 0 10 16' fill='none'%3E%3Cpath d='M5 1L9 6H1L5 1Z' fill='%231A56DB' opacity='0.7'/%3E%3Cpath d='M5 15L1 10H9L5 15Z' fill='%231A56DB' opacity='0.7'/%3E%3C/svg%3E");
}

.spin-input.spin-input-wide {
  width: 66px;
}

.spin-input:focus {
  border-color: var(--color-primary);
}

/* 1:1 对标 MD3 复选框 */
.md3-checkbox-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-main);
  cursor: pointer;
  user-select: none;
}

.md3-check-native {
  width: 15px;
  height: 15px;
  accent-color: var(--color-primary);
  cursor: pointer;
}

/* 闪烁行排布 */
.blink-row {
  display: flex;
  align-items: center;
  gap: 12px;
}

.blink-speed-label {
  font-size: 12px;
  color: var(--text-sub);
}

/* 1:1 对标 ssh8.py 终端背景预设切换按钮 */
.bg-preset-row {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
}

.btn-bg-preset {
  flex: 1;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  border-radius: 8px;
  cursor: pointer;
  background: transparent;
  border: 1px solid var(--border-input);
  color: var(--text-sub);
  transition: all 0.18s ease;
}

.btn-bg-preset.active {
  background: var(--color-primary) !important;
  color: var(--color-on-primary) !important;
  border-color: var(--color-primary) !important;
  font-weight: bold;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
}

.btn-bg-preset:hover:not(.active) {
  background: var(--bg-capsule-hover);
  color: var(--text-main);
}

/* 1:1 对标 ssh8.py color_btn_box 调色块 */
.color-palette-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-swatch-btn {
  width: 28px;
  height: 28px;
  border-radius: 14px;
  border: 2px solid transparent;
  cursor: pointer;
  transition: transform 0.15s ease, border-color 0.15s ease;
  padding: 0;
}

.color-swatch-btn.active {
  border-color: var(--color-primary) !important;
  transform: scale(1.1);
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.25);
}

.color-swatch-btn:hover:not(.active) {
  transform: scale(1.08);
}

/* 1:1 对标 ssh8.py RainbowCustomColorButton */
.rainbow-custom-color-btn {
  width: 28px;
  height: 28px;
  border-radius: 14px;
  border: 2px solid var(--border-input);
  background: conic-gradient(from 0deg, #EA4335, #FBBC05, #34A853, #4285F4, #EA4335);
  cursor: pointer;
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: border-color 0.15s ease, transform 0.15s ease;
}

.rainbow-custom-color-btn:hover {
  border-color: var(--color-primary);
  transform: scale(1.08);
}

.rainbow-center-dot {
  width: 10px;
  height: 10px;
  background: #FFFFFF;
  border-radius: 50%;
  box-shadow: 0 0 2px rgba(0, 0, 0, 0.4);
}

.hidden-color-picker {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

/* 1:1 对标 ssh8.py btn_backup_center */
.backup-entry-row {
  margin-top: 6px;
  padding-top: 8px;
  border-top: 1px dashed var(--border-card);
  width: 100%;
}

.btn-backup-center {
  width: 100%;
  height: 32px;
  background: var(--color-primary);
  border: 1px solid var(--color-primary);
  border-radius: var(--radius-btn);
  color: var(--color-on-primary);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
  transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
}

.btn-backup-center:hover {
  background: var(--color-primary-hover);
  border-color: var(--color-primary-hover);
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
}

.btn-backup-center:active {
  background: var(--color-primary-active);
  transform: translateY(0);
}

.sftp-quick-select {
  height: 26px;
  padding: 0 24px 0 8px !important;
  font-size: 11px;
}

/* 预警徽标与下拉样式 */
.nav-pill.alert-pill {
  color: #F28B82;
  background: rgba(242, 139, 130, 0.12);
  border-color: rgba(242, 139, 130, 0.3);
}
/* 预警徽标与下拉样式 (适配深浅主题 1:1 对标 ssh8.py) */
.alert-popover {
  width: 360px !important;
  max-width: 90vw;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.45);
}

.alert-head {
  padding: 10px 14px !important;
  border-top-left-radius: calc(var(--radius-card) - 1px);
  border-top-right-radius: calc(var(--radius-card) - 1px);
  background: var(--bg-sub-card) !important;
  border-bottom: 1px solid var(--border-card) !important;
}

.alert-scroll-list {
  border-bottom-left-radius: calc(var(--radius-card) - 1px);
  border-bottom-right-radius: calc(var(--radius-card) - 1px);
}

.alert-head-title {
  font-size: 13px !important;
  font-weight: 700 !important;
  color: var(--text-title) !important;
}

.alert-head-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.btn-popover-ignore {
  height: 24px;
  padding: 0 10px;
  font-size: 11px;
  font-weight: 600;
  color: var(--color-on-primary);
  background-color: var(--color-primary);
  border: 1px solid var(--color-primary);
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.btn-popover-ignore:hover {
  background-color: var(--color-primary-hover);
}

.alert-scroll-list {
  max-height: 320px !important;
  padding: 10px 12px !important;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.alert-empty-state {
  text-align: center;
  padding: 38px 12px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-sub);
  user-select: none;
}

.alert-card-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  background: var(--bg-capsule);
  border: 1px solid var(--border-capsule);
  border-radius: 9px;
  cursor: pointer;
  transition: all 0.15s ease;
  user-select: none;
}

[data-theme="light"] .alert-card-item {
  background: #FAFAFC;
  border: 1px solid #D2D8E4;
}

.alert-card-item:hover {
  background: var(--bg-capsule-hover);
  border-color: var(--color-primary);
}

[data-theme="light"] .alert-card-item:hover {
  background: #EDEFF4;
  border-color: var(--color-primary);
}

.alert-item-dot-col {
  display: flex;
  padding-top: 5px;
  flex-shrink: 0;
}

.alert-indicator-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
}

.alert-indicator-dot.traffic {
  background-color: #B3261E;
  box-shadow: 0 0 6px rgba(179, 38, 30, 0.4);
}

.alert-indicator-dot.expire {
  background-color: #D97706;
  box-shadow: 0 0 6px rgba(217, 119, 6, 0.4);
}

.alert-item-content {
  flex: 1;
  min-width: 0;
}

.alert-item-msg {
  font-size: 12px;
  line-height: 1.45;
  font-weight: 600;
  color: var(--text-main);
  word-break: break-word;
}

.alert-item-hname {
  color: var(--text-title);
  margin-right: 4px;
}

/* SFTP 拖放上传悬浮提示遮罩 */
.sftp-file-list.drag-over {
  border: 2px dashed #78D9EC;
  background: rgba(120, 217, 236, 0.05);
}
.sftp-drop-overlay {
  padding: 12px;
  text-align: center;
  font-size: 11px;
  font-weight: 700;
  color: #78D9EC;
  background: rgba(120, 217, 236, 0.1);
  border-radius: 6px;
  margin-bottom: 8px;
}

.flex-center {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.tree-host-icon {
  color: #A8C7FA;
}

/* =========================================================================
   终端 xterm.js 6 自绘滚动条 (SmoothScrollableElement) 胶囊化
   xterm 6 不再使用原生 ::-webkit-scrollbar，而是渲染
   .xterm-scrollable-element > .scrollbar.vertical > .slider，
   这里强制其与 SFTP 栏滚动条 1:1 一致：
   8px 宽、透明轨道、#43474E 胶囊滑块、悬停/拖拽为主色。
   ========================================================================= */
.center-terminal-card .xterm .xterm-scrollable-element > .scrollbar.vertical,
div.terminal-mount-box .xterm .xterm-scrollable-element > .scrollbar.vertical {
  width: 8px !important;
  right: 0 !important;
  background: transparent !important;
}

.center-terminal-card .xterm .xterm-scrollable-element > .scrollbar.horizontal,
div.terminal-mount-box .xterm .xterm-scrollable-element > .scrollbar.horizontal {
  height: 8px !important;
  bottom: 0 !important;
  background: transparent !important;
}

.center-terminal-card .xterm .xterm-scrollable-element > .scrollbar.vertical > .slider,
div.terminal-mount-box .xterm .xterm-scrollable-element > .scrollbar.vertical > .slider {
  width: 8px !important;
  left: 0 !important;
  min-height: 24px !important;
  border: none !important;
  border-radius: 9999px !important;
  background-color: #43474E !important;
}

.center-terminal-card .xterm .xterm-scrollable-element > .scrollbar.horizontal > .slider,
div.terminal-mount-box .xterm .xterm-scrollable-element > .scrollbar.horizontal > .slider {
  height: 8px !important;
  bottom: 0 !important;
  min-width: 24px !important;
  border: none !important;
  border-radius: 9999px !important;
  background-color: #43474E !important;
}

.center-terminal-card .xterm .xterm-scrollable-element > .scrollbar > .slider:hover,
div.terminal-mount-box .xterm .xterm-scrollable-element > .scrollbar > .slider:hover,
.center-terminal-card .xterm .xterm-scrollable-element > .scrollbar > .slider.active,
div.terminal-mount-box .xterm .xterm-scrollable-element > .scrollbar > .slider.active {
  background-color: var(--color-primary) !important;
}

/* 字体选择专用弹窗样式 */
.font-selector-modal-card {
  width: 520px;
  max-width: 95vw;
}

.font-selector-body {
  padding: 14px 18px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.font-selector-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 4px;
}

.font-loading-tip {
  font-size: 11px;
  color: var(--color-primary);
}

.font-list-scrollable {
  max-height: 380px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-right: 4px;
}

.font-group-title {
  font-size: 11px;
  font-weight: 700;
  color: var(--text-sub);
  margin-top: 6px;
  margin-bottom: 2px;
  padding-left: 2px;
}

.font-item-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  border-radius: var(--radius-btn);
  background: var(--bg-capsule);
  border: 1px solid var(--border-capsule);
  cursor: pointer;
  transition: all 0.15s ease;
}

.font-item-row:hover {
  background: var(--bg-capsule-hover);
  border-color: var(--color-primary);
}

.font-item-row.active {
  background: rgba(120, 217, 236, 0.12);
  border-color: var(--color-primary);
}

[data-theme="light"] .font-item-row.active {
  background: rgba(26, 86, 219, 0.1);
  border-color: var(--color-primary);
}

.font-item-left {
  display: flex;
  flex-direction: column;
  gap: 3px;
  min-width: 0;
}

.font-item-name {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-main);
}

.font-item-preview {
  font-size: 11px;
  color: var(--text-sub);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.font-check-mark {
  color: var(--color-primary);
  font-size: 14px;
  font-weight: bold;
  padding-left: 8px;
}
</style>